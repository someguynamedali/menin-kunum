# Менин күнүм

Mobile-first offline personal planner PWA. Russian is the default interface language; Kyrgyz and English are supported.

## Development

- `npm install`
- `npm run dev`
- `npm test`
- `npm run typecheck`
- `npm run build`

Read `docs/menin-kunum-design-spec.md`, `docs/superpowers/plans/2026-10-15-menin-kunum.md` and `docs/qa-status.md` before making architectural changes.

## Development status

- Stage 1: project skeleton, domain types, locale basics and validation.
- Stage 3: versioned IndexedDB schema and typed repository adapters.
- Stage 4: responsive Midnight app shell, five-item navigation, language selector, PWA manifest/icon, and app-shell service worker.
- Stage 5: task, note and diary screens now call typed service-layer operations; validation, searching, editing, completion, favorites and deletion are covered by unit tests.
- Stage 6 implementation slice: project creation and task assignment, task subtasks/dependency-cycle checks/time tracking/carry-forward, habit targets and daily/weekly progress, recurring weekday calendar entries, and local productivity statistics. These screens are reachable from “Ещё”.
- Stage 7 implementation slice: AES-256-GCM content encryption for notes/diary, PBKDF2 PIN wrapper, one-time recovery code/HKDF wrapper, startup PIN gate, safe atomic migration, manual lock, PIN change and recovery flows. No inactivity auto-lock is implemented by user choice.
- Stage 8 implementation slice: passphrase-encrypted backup export and validated preview-before-restore, atomic restore preserving the current PIN/key, encrypted attachment storage and previews, local weekly/monthly summaries, opt-in generic reminders, and persistent reminder settings. Reminder delivery while the app is closed is not guaranteed.
- Stage 12 hardening: PIN unlock guard rejects invalid cooldown configuration (including NaN/infinity) and invalid attempt limits; regression test added.
- Stage 13 hardening: backup restore revalidates preview metadata, schema version, allowed metadata fields and safe-integer record counts immediately before writing. Tests prove malformed preview metadata is rejected without storage writes. Backup passphrase byte buffers are cleared after key derivation.
- Stage 14 build gate diagnosis: source was not changed to mask missing dependencies. The current environment cannot resolve npm registry DNS, so a production build is still blocked; see `docs/qa-status.md` for exact commands and results.
- Backup hardening: strict nested record validation, bounded fields and attachments, cross-record reference checks, iterative dependency-cycle detection, and regression coverage for malformed imports. Keyring loading also rejects malformed KDF parameters and invalid wrapped-key metadata before unlock.
- Still pending: rendered React/browser tests, actual IndexedDB persistence/reopen tests on Android, full production build/typecheck, and final security review. The security gate is **not passed** until those checks are completed.

## Important privacy and storage notes

**Do not enter real sensitive diary entries or other confidential information until the final security gate passes.** Encryption, PIN/recovery, migration and encrypted backup flows now exist in code, but full production build, rendered browser tests, real IndexedDB behavior and Android acceptance have not been verified. Notes and diary contents plus attachments are encrypted at rest; titles, dates and tags intentionally remain visible for search. Tasks, projects and habits are not encrypted by this design. Data stays in this browser profile's IndexedDB and is not synced to another device; browser/OS storage cleanup can remove it. If both the PIN and one-time recovery code are lost, encrypted records cannot be recovered.

The service worker caches only the app shell and same-origin static build assets; it does not cache API responses or personal records. Repository unit tests currently use an in-memory test adapter; actual IndexedDB persistence/reopen behavior still needs browser integration tests on Android.

## Current verification limits

`npm test` uses Node's built-in test runner; the latest run passed **94/94 tests**. Strict typechecking passes for the non-React domain/security/storage/service modules, and syntax transpilation of 49 TS/TSX source files reports zero syntax diagnostics. Full `npm run typecheck` / `npm run build` and rendered React tests are **not confirmed**: React/Vite/Vitest packages are unavailable, and installation attempts against both the npm registry and its mirror failed with DNS error `EAI_AGAIN`. The build fails in `tsc -b` on unresolved dependency imports before Vite can run; cascading type errors cannot be assessed until dependencies are available. Do not treat this as a production-ready release until those checks and Android browser acceptance are completed.
