# «Менин күнүм» Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build an installable, mobile-first offline PWA for planning, notes, habits and a private diary, with Russian/Kyrgyz/English UI and encrypted local personal data.

**Architecture:** React + TypeScript provides the UI; domain services validate operations and use IndexedDB rather than allowing components to access storage directly. A service worker caches the application shell. Personal data is encrypted with Web Crypto before persistence, and versioned encrypted backups support manual recovery.

**Tech Stack:** React, TypeScript, Vite, IndexedDB (native API or a small typed wrapper), Web Crypto API, Service Worker/PWA manifest, Vitest, React Testing Library, Playwright for browser-level checks, GitHub.

**Spec:** `/mnt/data/menin_kunum_design_spec.md` (companion downloadable specification; copy into the repository as `docs/menin-kunum-design-spec.md` once a repository is created).

## Global Constraints

- First release is a PWA, not a native APK.
- App name: «Менин күнүм»; visual style: Midnight (dark navy, purple accents, restrained glow).
- Default language: Russian; supported UI languages: Russian, Kyrgyz and English.
- Primary navigation: Главная, Планы, Заметки, Дневник, Ещё.
- Local-first: IndexedDB, no account, no server, no cloud sync, no external AI processing of diary entries.
- App shell and essential assets must launch offline after successful initial load/install.
- Components must use typed domain/storage services; UI components must not access IndexedDB directly.
- Personal data selected for protection and all diary attachments must be encrypted before persistence.
- Never store a plaintext encryption key or plaintext recovery code. Do not claim encrypted-data recovery is possible if both PIN and recovery code are lost.
- Do not put real personal entries into the app until key-management and recovery tests pass.
- Notifications and background execution are browser-dependent; the UI must explain limitations and must not imply guaranteed exact-time delivery.
- Manual backups only in the first version; backup files containing protected data must be encrypted and versioned.
- Keep each task independently testable; run tests before committing each task.

## Review Focus

1. **Interrupted or malformed restore:** invalid, truncated, wrong-version or tampered backup must be rejected without changing existing data. Test in Task 8.
2. **PIN/recovery lifecycle:** wrong PIN/code, PIN change, lock/unlock and recovery must never expose data or strand valid data unexpectedly. Test in Task 7.
3. **Storage exhaustion or browser storage failure:** show a recoverable error and never silently report a failed write as saved. Test in Tasks 3 and 10.
4. **Offline reload and app update:** after an initial online load, a reload without network must render the shell and retain local records; cache updates must not erase records. Test in Tasks 4 and 10.
5. **Localization and small-screen usability:** all user-facing UI strings must come from dictionaries, language choice must persist, and bottom navigation/forms must remain usable on a narrow Android viewport. Test in Tasks 2, 4 and 10.

---

## Repository layout

Create the following structure; keep modules small and grouped by feature.

- `index.html` — app entry HTML and theme metadata.
- `public/manifest.webmanifest` — install metadata, icons and app display mode.
- `public/icons/` — app icons in required PWA sizes.
- `src/main.tsx` — React entry point.
- `src/app/App.tsx` — top-level app shell and route composition.
- `src/app/routes.tsx` — route definitions.
- `src/app/navigation/BottomNavigation.tsx` — five-item bottom navigation.
- `src/app/components/` — reusable buttons, fields, cards, dialogs, empty/error states.
- `src/styles/tokens.css` — colors, spacing, radii, focus and motion tokens.
- `src/styles/global.css` — global layout, responsive styles and accessibility defaults.
- `src/i18n/index.ts` — locale selection and formatting helpers.
- `src/i18n/locales/{ru,ky,en}.ts` — complete interface dictionaries.
- `src/domain/models.ts` — shared entities and enums.
- `src/domain/validation.ts` — input validation and invariant checks.
- `src/storage/db.ts` — IndexedDB schema, open/close and migrations.
- `src/storage/repositories/` — typed persistence adapters.
- `src/services/` — domain operations, reminders, summaries and backup orchestration.
- `src/security/crypto.ts` — Web Crypto primitives and versioned encrypted payload format.
- `src/security/key-management.ts` — PIN/recovery wrapping, unlock, lock and PIN change.
- `src/security/session.ts` — in-memory session state and inactivity lock.
- `src/pwa/register-service-worker.ts` — service-worker registration and update state.
- `src/features/home/`, `plans/`, `notes/`, `diary/`, `habits/`, `calendar/`, `stats/`, `settings/` — feature screens and components.
- `src/test/` — test setup and shared fixtures.
- `tests/e2e/` — browser-level offline, responsive and main-flow tests.
- `docs/menin-kunum-design-spec.md` — approved design specification.
- `docs/superpowers/plans/2026-10-15-menin-kunum.md` — this plan.

## Task 1: Bootstrap the project and test pipeline

**Files**
- Create: `package.json`, `index.html`, `vite.config.ts`, `tsconfig.json`, `tsconfig.app.json`, `tsconfig.node.json`, `vitest.config.ts`
- Create: `src/main.tsx`, `src/app/App.tsx`, `src/test/setup.ts`
- Create: `.gitignore`, `README.md`
- Test: `src/app/App.test.tsx`

**Interfaces**
- `App` exports the root React component.
- Test scripts: `npm run dev`, `npm run build`, `npm run test`, `npm run typecheck`.
- Use strict TypeScript; do not disable strictness to silence errors.

- [ ] **Step 1: Scaffold a Vite React + TypeScript application and install the test tools.**
- [ ] **Step 2: Write a failing smoke test** asserting the root renders the app title «Менин күнүм».
- [ ] **Step 3: Run the smoke test and confirm it fails** because the title is not yet rendered.
- [ ] **Step 4: Implement the minimal root component and test setup.**
- [ ] **Step 5: Run verification:** `npm run test -- --run`, `npm run typecheck`, `npm run build`. Expected: all pass.
- [ ] **Step 6: Commit:** `chore: bootstrap app and test pipeline`.

## Task 2: Domain types, localization and Midnight design tokens

**Files**
- Create: `src/domain/models.ts`, `src/domain/validation.ts`
- Create: `src/i18n/index.ts`, `src/i18n/locales/ru.ts`, `src/i18n/locales/ky.ts`, `src/i18n/locales/en.ts`
- Create: `src/styles/tokens.css`, `src/styles/global.css`
- Test: `src/i18n/index.test.ts`, `src/domain/validation.test.ts`

**Interfaces**
- `Locale = 'ru' | 'ky' | 'en'`.
- `TaskStatus = 'planned' | 'completed' | 'deferred'`.
- `Priority = 'low' | 'medium' | 'high'`.
- Define typed entities `Task`, `Project`, `Subtask`, `Note`, `DiaryEntry`, `Habit`, `HabitLog`, `AttachmentMetadata`, and `AppSettings` with stable string IDs, ISO date strings and schema version fields where appropriate.
- `t(locale, key)` returns a translated UI string; `formatDate(date, locale)` and `formatTime(date, locale)` use `Intl`.
- Validation returns structured errors; it must not silently coerce invalid dates or empty required titles.

- [ ] **Step 1: Write tests** for locale fallback, missing-key detection in tests, date/time formatting, required titles and invalid dates.
- [ ] **Step 2: Run tests and confirm they fail** before implementations exist.
- [ ] **Step 3: Implement models, validation and complete RU/KY/EN dictionaries** for the current shell and shared controls.
- [ ] **Step 4: Add Midnight design tokens and accessible focus/contrast defaults**, including `prefers-reduced-motion`.
- [ ] **Step 5: Run verification:** `npm run test -- --run`, `npm run typecheck`, `npm run build`. Expected: all pass; test must fail if a locale dictionary is incomplete.
- [ ] **Step 6: Commit:** `feat: add domain types localization and design tokens`.

## Task 3: IndexedDB foundation and typed repositories

**Files**
- Create: `src/storage/db.ts`, `src/storage/errors.ts`
- Create: `src/storage/repositories/tasks.ts`, `notes.ts`, `diary.ts`, `habits.ts`, `settings.ts`
- Create: `src/storage/db.test.ts`, `src/storage/repositories/repositories.test.ts`

**Interfaces**
- `openAppDatabase(): Promise<IDBDatabase>` opens a versioned database and runs explicit migrations.
- Repositories expose typed `create`, `getById`, `list`, `update` and `delete` operations; domain services call repositories, while UI components do not.
- Storage errors use stable categories such as `STORAGE_UNAVAILABLE`, `QUOTA_EXCEEDED`, `MIGRATION_FAILED` and `NOT_FOUND`.
- Keep the repository boundary ready for encrypted payloads; never log personal record bodies.

- [ ] **Step 1: Write failing tests** for database creation, CRUD, missing records, migration and rejected writes.
- [ ] **Step 2: Run the tests and confirm expected failures.**
- [ ] **Step 3: Implement the database schema, versioning and repository interfaces** using test-only fixtures.
- [ ] **Step 4: Implement safe error mapping** for unavailable storage and quota errors; a failed write must reject rather than report success.
- [ ] **Step 5: Run verification:** `npm run test -- --run`, `npm run typecheck`, `npm run build`. Expected: CRUD persists across database reopen; migration errors are surfaced and do not trigger silent deletion.
- [ ] **Step 6: Commit:** `feat: add versioned IndexedDB repositories`.

## Task 4: App shell, navigation and offline PWA foundation

**Files**
- Create: `src/app/routes.tsx`, `src/app/navigation/BottomNavigation.tsx`
- Create: `src/app/components/EmptyState.tsx`, `ErrorState.tsx`, `LoadingState.tsx`
- Create: `public/manifest.webmanifest`, `public/icons/*`
- Create: `src/pwa/register-service-worker.ts`, service-worker configuration and tests
- Modify: `src/app/App.tsx`, `index.html`, `vite.config.ts`
- Test: `src/app/navigation/BottomNavigation.test.tsx`, `tests/e2e/offline-shell.spec.ts`

**Interfaces**
- Five primary destinations: Home, Plans, Notes, Diary, More; Habit, Calendar, Stats and Settings are reached from More.
- App-level states include loading, storage error and update available.
- The PWA must cache the application shell and required static assets, not plaintext user data.

- [ ] **Step 1: Write failing navigation and manifest tests** for all five items, selected-state semantics, app name and display mode.
- [ ] **Step 2: Run tests and confirm they fail.**
- [x] **Step 3: Implement the responsive Midnight shell**, bottom navigation, initial feature placeholders and settings screen. Dedicated reusable loading/error/empty-state components remain to be added where actual data flows are wired.
- [x] **Step 4: Add manifest, icons and service-worker caching** for the shell and static assets.
- [ ] **Step 5: Run browser tests** for online first load followed by offline reload. Static checks pass; real browser/Android offline acceptance is still outstanding because dependencies and browser test tooling are unavailable in this environment.
- [ ] **Step 6: Commit:** `feat: add responsive app shell and offline PWA`.

## Task 5: Main screen and core record flows (tasks, notes, diary)

**Files**
- Create: `src/services/tasks.ts`, `src/services/notes.ts`, `src/services/diary.ts`
- Create: `src/features/home/HomePage.tsx`
- Create: `src/features/plans/PlansPage.tsx`, task editor/list components
- Create: `src/features/notes/NotesPage.tsx`, note editor/list components
- Create: `src/features/diary/DiaryPage.tsx`, diary editor/list components
- Create: feature-level unit tests and component tests.

**Interfaces**
- Services expose typed create/update/delete/list/search operations and return domain records or structured errors.
- A task supports title, optional description/date/time, category, priority, status, reminder and recurrence.
- A note supports title/body, tags and favorite state.
- A diary entry supports date, title/body, optional mood, good events, concerns, gratitude, tags and attachment references.
- Components use services and show saving/error state; they do not call IndexedDB directly.

- [x] **Step 1: Write failing service tests** for task/note/diary create, edit, delete, search and validation; repository/browser persistence-after-reload remains an integration test.
- [x] **Step 2: Run the tests and confirm expected failures.**
- [x] **Step 3: Implement service-layer operations** and keep all data as test fixtures until the security gate in Task 7 is passed.
- [x] **Step 4: Implement mobile-first forms and lists**, with saved/error feedback and confirmation before destructive deletion. Dedicated service layer remains pending.
- [x] **Step 5: Build the Home screen** with localized greeting/date, daily quote, task progress, upcoming tasks, mood quick action, “Мысли сегодня” shortcut and previous diary memory when available.
- [ ] **Step 6: Run unit/component tests and verify keyboard use, empty states and search.** Service tests pass; rendered component/browser tests remain blocked until dependencies are installed.
- [ ] **Step 7: Commit:** `feat: add task note diary and home flows`.

## Task 6: Projects, recurrence, habits, calendar and statistics

**Files**
- Create: `src/services/projects.ts`, `src/services/habits.ts`, `src/services/calendar.ts`, `src/services/statistics.ts`
- Create: `src/features/habits/HabitsPage.tsx`, `src/features/calendar/CalendarPage.tsx`, `src/features/stats/StatsPage.tsx`
- Modify: plans feature for projects, subtasks, dependencies and time tracking.
- Test: service tests for recurrence, carry-forward, dependencies, habit targets and statistics.

**Interfaces**
- Recurrence is represented by a typed rule, initially supporting selected weekdays.
- `carryForwardUnfinishedTasks(sourceDate, targetDate)` changes dates only for unfinished tasks and must not duplicate completed tasks.
- `recordHabitProgress(habitId, date, value)` validates checkbox, minutes, pages and repetitions according to the habit’s measurement type.
- Statistics are derived locally from stored records; mood statistics must not claim medical meaning.

- [x] **Step 1: Write failing tests** for weekday recurrence, carrying unfinished tasks forward, dependency validation, planned-vs-actual time, daily/weekly habit goals and statistics with empty data.
- [x] **Step 2: Run tests and confirm they fail.**
- [x] **Step 3: Implement project/subtask/dependency rules and time tracking.** Dependency cycles are rejected; deleting a prerequisite removes references from dependent tasks.
- [x] **Step 4: Implement habit logs, streak calculation, calendar views and local statistics.**
- [x] **Step 5: Add the screens. Static and syntax checks pass; rendered browser/localization/small-screen acceptance remains outstanding.
- [ ] **Step 6: Run verification:** `npm run test -- --run`, `npm run typecheck`, `npm run build`. Service/domain strict typecheck and 40 unit tests pass; full app build/typecheck remains blocked because React/Vite/Vitest dependencies are unavailable in this environment.
- [ ] **Step 7: Commit:** `feat: add projects habits calendar and statistics`.

## Task 7: Security design gate, encryption, PIN, recovery and auto-lock

**Files**
- Create: `src/security/crypto.ts`, `src/security/key-management.ts`, `src/security/session.ts`
- Create: `src/security/crypto.test.ts`, `src/security/key-management.test.ts`, `src/security/session.test.ts`
- Modify: repository layer to persist versioned encrypted payloads for protected data.
- Modify: settings flow to explain recovery limitations before setup completes.

**Interfaces**
- `encryptPayload(plaintext, key, associatedData)` and `decryptPayload(ciphertext, key, associatedData)` use authenticated encryption through Web Crypto; payloads carry a format version and required nonce/algorithm metadata.
- `initializeKeyring(pin, recoveryCode)` creates a random data-encryption key and wraps it separately for PIN and recovery; the plaintext data key exists only in memory while unlocked.
- `unlockWithPin(pin)`, `recoverWithCode(code, newPin)`, `changePin(oldPin, newPin)` and `lockSession()` have explicit success/error outcomes. By user decision, do not implement an inactivity timer or background auto-lock; session ends on manual lock or page close/reload.
- Use a reviewed, browser-supported password-based key derivation approach with explicit parameters; never use a fast general-purpose hash as a PIN KDF.
- Rate-limit repeated failed PIN attempts for the active app session and explain that this is not hardware-backed protection.
- Recovery code is shown once and never persisted as plaintext. Never log PINs, recovery codes, keys, plaintext entries or decrypted attachment bytes.

- [x] **Step 1: Document the key hierarchy and threat model** in `docs/superpowers/specs/2026-10-15-menin-kunum-security-design.md`; approved by the user with decisions recorded in the spec.
- [x] **Step 2: Write failing crypto tests** for successful round-trip, altered ciphertext/AAD rejection, wrong key rejection and payload version mismatch.
- [x] **Step 3: Write failing key-management tests** for wrong PIN, wrong recovery code, PIN change, valid recovery, manual lock and no plaintext key persistence. Auto-lock tests replaced with a no-auto-lock decision test per user approval.
- [x] **Step 4: Implement the cryptographic primitives and key wrapping** with secure random values and authenticated encryption; do not invent custom cryptography.
- [x] **Step 5: Implement in-memory session locking and best-effort reference clearing. No inactivity timeout is implemented by user choice.
- [x] **Step 6 (unit/integration code layer): Run all security tests and review repository/migration code.** Tests cover ciphertext storage, missing-keyring refusal, wrong keys, tampering, recovery, atomic migration and attachment keyring checks. Actual IndexedDB persistence inspection in a browser remains pending.
- [ ] **Step 7: Security gate:** not passed yet. The UI and migration are integrated, but real IndexedDB/browser tests, full production build and Android acceptance remain required. Do not use real personal data or declare the diary private until these checks are complete.
- [ ] **Step 8: Commit:** `feat: add encrypted local data and PIN recovery`.

## Task 8: Encrypted backups, attachments, local summaries and notifications

**Files**
- Create: `src/services/backup.ts`, `src/services/attachments.ts`, `src/services/reminders.ts`, `src/services/local-summaries.ts`
- Create: `src/features/settings/SettingsPage.tsx`, backup/restore and security settings components
- Modify: diary editor for attachment selection and preview.
- Test: backup, attachment, summary and reminder service tests.

**Interfaces**
- Backup format has a version, export timestamp, schema version, encrypted payload and integrity/authentication metadata.
- `exportEncryptedBackup(passphraseOrApprovedRecoveryMechanism)` returns a downloadable encrypted file.
- `previewBackup(file)` validates size, format, version and integrity without mutating the database.
- `restoreBackup(file, mode)` only applies after successful validation and explicit user confirmation; modes and replacement/merge semantics must be explained before execution.
- Attachment import validates MIME type and size, then encrypts content before storage.
- Local weekly/monthly summaries are rule-based and operate only on unlocked local data.
- Reminder service distinguishes in-app reminders from supported system notifications and reports unsupported/background-limited behavior.

- [x] **Step 1: Write backup tests** for valid encrypted export/restore, wrong passphrase, corrupted/truncated file, unsupported version and unchanged data after rejected restore.
- [x] **Step 2: Write tests** for oversized/invalid attachments, summary generation with no entries and reminder permission denied.
- [x] **Step 3: Implement encrypted, versioned backup export and preview-first restore.** Arbitrary object structures are validated before restore.
- [x] **Step 4: Implement attachment size/type checks and encryption before persistence.**
- [x] **Step 5: Implement local summaries and opt-in generic reminders.** No external AI calls; UI states that background delivery is not guaranteed.
- [x] **Step 6: Add settings UI for PIN change, recovery, manual lock, hidden notification content, export/restore, language and reminders.** No inactivity timer is implemented by user choice.
- [x] **Step 7: Run unit tests.** Invalid or wrong-passphrase backups do not reach restore; attachment validation and permission-denial behavior are covered. Browser/Android verification remains pending.
- [ ] **Step 8: Commit:** `feat: add encrypted backups attachments and reminders`.

## Task 9: Final quality, accessibility and Android acceptance

**Files**
- Create: `tests/e2e/core-flows.spec.ts`, `tests/e2e/security-lock.spec.ts`, `tests/e2e/restore.spec.ts`, `tests/e2e/localization.spec.ts`
- Modify: relevant app files to fix defects found by tests.
- Create/update: `README.md`, `docs/privacy-and-browser-limitations.md`

- [ ] **Step 1: Write end-to-end tests** for task/note/diary flows, language switching, lock/unlock, backup preview/restore and offline reload.
- [ ] **Step 2: Run the full automated suite** and record any failures before fixing them.
- [ ] **Step 3: Fix defects and re-run** `npm run test -- --run`, `npm run typecheck`, `npm run build`, and the Playwright suite.
- [ ] **Step 4: Test a narrow mobile viewport** for navigation, form controls, keyboard overlap, contrast, focus and reduced-motion behavior.
- [ ] **Step 5: Test on Android 16 in the selected browser:** install PWA, launch after install, reload offline, create/edit sample records, lock/unlock, export and restore a sample backup, and check actual notification behavior.
- [ ] **Step 6: Document verified browser limitations**, storage-loss risks and recovery consequences. Do not describe unsupported features as guaranteed.
- [ ] **Step 7: Final review** for accidental network requests, plaintext personal-data logs, missing translations, unsafe restore paths and silent data loss.
- [ ] **Step 8: Commit:** `test: verify offline security and Android acceptance`.

## Task 10: GitHub delivery and project handoff

**Files**
- Create/update: `README.md`, `.gitignore`, `docs/menin-kunum-design-spec.md`, `docs/superpowers/plans/2026-10-15-menin-kunum.md`

- [ ] **Step 1: Verify no secrets, local databases, real diary entries or generated backup files are staged.**
- [ ] **Step 2: Run the final test/typecheck/build commands and confirm clean output.**
- [ ] **Step 3: Commit the approved plan, specification and final implementation in meaningful increments.**
- [ ] **Step 4: Push to the user-selected GitHub repository only after the repository and access method are confirmed.**
- [ ] **Step 5: Configure Replit import/run only if the user’s account permits it; otherwise use a compatible alternative without claiming Replit setup succeeded.**
- [ ] **Step 6: Deliver the repository/run instructions, known browser limitations and a short manual test checklist.**

## Self-review against the approved specification

- **Coverage:** app shell, five-item navigation, home, plans/projects, notes, diary, habits, calendar, statistics, three languages, local storage, migrations, encryption, PIN/recovery, auto-lock, hidden notification text, encrypted manual backups, attachments, local summaries, reminders, offline PWA, Android checks and documentation are each assigned to a task.
- **Ordering:** no real personal content is used before Task 7’s security gate. Core feature work can use test fixtures before that gate. Encrypted backups follow the reviewed key-management interface.
- **Interface consistency:** all feature services use shared domain types and typed repositories; UI does not access IndexedDB directly. Backup restore uses preview and explicit confirmation.
- **Known external constraint:** PWA background notifications and Replit availability are not assumed; both are verified and documented rather than promised.
- **No silent scope expansion:** no cloud sync, accounts, external AI, native APK or automatic cloud backup is included in this first release.
