# QA status — Менин күнүм

**Status:** implementation review in progress; not a production release.

## Verified in this environment

- Node unit suite: **94/94 passed** (`npm test`, freshly rerun after stage 13).
- Strict TypeScript check: domain, security, storage and service modules passed with the installed global TypeScript compiler.
- Syntax transpilation: **49 TypeScript/TSX files, 0 syntax diagnostics**.
- Whitespace diff check: not available in the extracted delivery workspace (no Git metadata).
- `node --check public/sw.js`: passed.
- `public/manifest.webmanifest`: parses as valid JSON.
- Security tests cover AES-GCM round-trip/tamper/AAD failures, PIN/recovery lifecycle, PIN changes, manual lock, missing keyring with encrypted records, encrypted note/diary persistence, migration rollback and forward-compatible private fields, backup passphrase/corruption validation, deep validation of restored records and references (including task dependency cycles), encrypted attachments and reminder permission handling.

## Stage 13 — Backup restore preview hardening

- `restoreBackupPreview` now validates the preview metadata shape, exact backup format/version/schema version, timestamp, known metadata keys, known count keys, and safe-integer counts immediately before any restore write.
- Added two regression tests: an altered schema version and malformed record counts are rejected without invoking the storage adapter. The focused backup suite passes **10/10**.
- Backup passphrase UTF-8 bytes are now cleared in a `finally` block after PBKDF2 key derivation, matching the existing PIN-byte cleanup approach.
- Full Node suite after this stage: **94/94 passed**.

## Stage 12 — PIN guard configuration hardening

- The session-local PIN unlock guard now rejects non-finite cooldown values (`NaN`, positive infinity) and requires a safe-integer attempt limit. Previously, `NaN` passed the less-than-zero check and made the cooldown comparison ineffective.
- Regression test was observed failing first on `cooldownMs: NaN`; after the guard validation fix, the focused key-management suite passed **9/9** and the complete Node suite passed **92/92**.
- Strict TypeScript check of domain, security, storage and service modules passed after this change.

## Latest hardening pass

- Keyring storage now validates decoded salt lengths, PBKDF2 iteration bounds, AES-GCM algorithm/version, nonce length and wrapped-ciphertext bounds before accepting a saved keyring. Corrupt key metadata is rejected with a recovery-oriented error instead of being treated as a valid setup.
- Added a regression test for malformed KDF parameters and a malformed recovery nonce. The focused keyring-store suite passes **3/3**. The full suite later reached 92/92 after stage 12 and 94/94 after stage 13.

- Backup import now validates nested task/subtask structures, optional field types and bounds, dates/timestamps, attachment sizes, and cross-record references before any restore write.
- Dependency graphs are checked iteratively for cycles, avoiding recursion-depth failure on unusually large crafted backups.
- Temporary decoded attachment bytes are cleared after size validation.
- Added regression tests for malformed nested task fields, invalid diary dates, oversized note bodies, dangling references and dependency cycles.

## Stage 14 — Production build gate diagnosis (2026-10-16)

- Fresh full Node suite: **94/94 passed**.
- Strict TypeScript check for `src/domain`, `src/security`, `src/storage`, and `src/services`: passed.
- Syntax transpilation for **49 TS/TSX source files** (excluding declaration files): 0 syntax diagnostics.
- `node --check public/sw.js`: passed; `public/manifest.webmanifest` parses as valid JSON.
- `npm run build`: **blocked before Vite runs** because project dependencies are absent. `tsc -b` reports unresolved `react`, `react-dom/client`, `react/jsx-runtime`, `vite`, `@vitejs/plugin-react`, `vitest`, and `@testing-library/react`. Some additional type errors are cascading from those missing packages; they cannot be reliably graded until the real dependencies are installed.
- Dependency installation was attempted against both `https://registry.npmjs.org/` and `https://registry.npmmirror.com/`; both failed with DNS `EAI_AGAIN`. Offline installation also failed because the required packages are not in the available npm cache.
- No production-code change was made to hide these failures. A successful production bundle remains unverified; browser and Android acceptance must wait until dependencies can be installed in a network-enabled build environment.

## Blocked / not yet verified

- Full `npm run typecheck` and `npm run build`: React, Vite, Vitest and React Testing Library dependencies are absent. On 2026-10-16, installation failed with DNS `EAI_AGAIN` against both the npm registry and its mirror; offline installation also failed because required packages are not cached. `tsc -b` therefore fails on unresolved imports and cascading type errors before Vite can run. A full production bundle cannot be claimed.
- Rendered React component tests and browser end-to-end tests.
- Actual IndexedDB persistence/reopen and transaction rollback in a real browser.
- Android installation, offline reload, PIN/recovery, backup restore and notification behavior.

## Manual acceptance checklist for the first browser with dependencies installed

1. Install dependencies and confirm `npm run typecheck`, `npm run build` and `npm test` exit successfully.
2. Open the app in a clean browser profile; create a PIN, save the one-time recovery code outside the app, and finish setup.
3. Create a note and diary entry with unique test phrases; inspect IndexedDB and confirm the bodies are not present as plaintext. Confirm titles, dates and tags are intentionally visible.
4. Reload; verify PIN unlock, wrong PIN rejection, manual lock from the top bar, PIN change and recovery with the saved code.
5. Export a backup with a strong passphrase; reject a wrong passphrase and a modified file; restore a valid backup only after preview and explicit confirmation.
6. Attach an allowed test image/text/PDF; inspect IndexedDB for encrypted bytes and verify preview after reload.
7. Load once online, then reload offline. Confirm the app shell and static assets work without exposing data while locked.
8. Test a narrow Android viewport, keyboard focus, form validation, destructive-action confirmation, reduced motion and all three locales.
9. Confirm reminders are opt-in and understand that delivery while the app is closed/backgrounded is not guaranteed.

## Privacy scope to disclose

- Note and diary contents are encrypted at rest; note/diary titles, dates, tags and selected metadata remain visible for search/calendar usability.
- Attachments are encrypted at rest.
- Tasks, projects, habits and habit progress are **not encrypted** in this version.
- There is no cloud sync. Browser/OS storage cleanup can remove local data. If both PIN and recovery code are lost, encrypted content is unrecoverable.
- Manual lock is available; inactivity auto-lock is intentionally not implemented by user choice.

Do not use real confidential entries until the blocked browser/build checks are completed.
