# Privacy and browser limitations — Менин күнүм

## What is protected

- Note body and diary body, mood, private lists and attachment references are encrypted with AES-256-GCM using a random data key.
- Attachments are encrypted before they are written to IndexedDB.
- The data key is wrapped separately for the PIN and the one-time recovery code. The app does not persist the PIN or recovery code in plaintext.
- Backup files are encrypted with a separate passphrase. Restore validates the full file before opening one atomic IndexedDB transaction and preserves the current app keyring/PIN.
- Notification text is generic and does not include task titles or diary content.

## What remains visible or unprotected

- Note and diary titles, dates, tags, and selected technical metadata remain visible by the user's choice so search and calendar features remain convenient. The setup/settings screens explicitly disclose this scope.
- Tasks, projects, habits and habit progress are not encrypted by the current design; do not store sensitive details in their titles or fields.
- Data is local to one browser profile. There is no sync service and no server-side recovery.
- The app cannot protect data from a compromised device/browser, malicious JavaScript served by a compromised origin, screen capture, or a person using the app while it is unlocked.
- JavaScript cannot guarantee that all copies of decrypted text or key material are erased from memory.
- Automatic inactivity lock is intentionally not implemented. Use the manual Lock action when leaving the app. Closing/reloading normally discards the in-memory session, but browser lifecycle behavior is not a substitute for manual locking.
- Reminder scheduling relies on the app being open and the browser allowing timers/notifications. Delivery while closed or in the background is not guaranteed.
- Browser/OS storage cleanup, device loss or profile deletion can remove local data. If both PIN and recovery code are lost, encrypted content is unrecoverable.

## Before real personal data is used

The code has unit and structural checks, but the final security gate remains open until dependencies install and a real browser test verifies: setup/unlock, IndexedDB persistence, atomic migration/restore rollback, lock/recovery, backup round-trip, attachment encryption, offline reload and notification behavior on the target Android browser. Do not treat the app as production-ready before that verification.
