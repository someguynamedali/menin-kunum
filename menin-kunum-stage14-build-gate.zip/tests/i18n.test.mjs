import test from 'node:test';
import assert from 'node:assert/strict';
import { t, formatDate } from '../src/i18n/index.ts';

test('translates the app title in all supported locales', () => {
  assert.equal(t('ru', 'app.title'), 'Менин күнүм');
  assert.equal(t('ky', 'app.title'), 'Менин күнүм');
  assert.equal(t('en', 'app.title'), 'My Day');
});

test('falls back to the key for an unknown translation', () => {
  assert.equal(t('en', 'missing.key'), 'missing.key');
});

test('formats dates using the selected locale', () => {
  const date = new Date('2026-10-15T12:00:00Z');
  assert.match(formatDate(date, 'en'), /October/);
});

test('keeps all locale dictionaries in sync', async () => {
  const [{ default: ru }, { default: ky }, { default: en }] = await Promise.all([
    import('../src/i18n/locales/ru.ts'),
    import('../src/i18n/locales/ky.ts'),
    import('../src/i18n/locales/en.ts'),
  ]);
  assert.deepEqual(Object.keys(ky).sort(), Object.keys(ru).sort());
  assert.deepEqual(Object.keys(en).sort(), Object.keys(ru).sort());
});
