import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const app = await readFile(new URL('../src/app/App.tsx', import.meta.url), 'utf8');
const taskService = await readFile(new URL('../src/services/tasks.ts', import.meta.url), 'utf8');
const noteService = await readFile(new URL('../src/services/notes.ts', import.meta.url), 'utf8');
const diaryService = await readFile(new URL('../src/services/diary.ts', import.meta.url), 'utf8');

test('task UI uses the task service for create, edit, completion and delete', () => {
  assert.match(app, /createTaskService/u);
  assert.match(app, /repositories\.tasks\.create\(changes\)/u);
  assert.match(app, /repositories\.tasks\.update\(existing\.id, changes\)/u);
  assert.match(app, /repositories\.tasks\.setStatus\(task\.id/u);
  assert.match(app, /repositories\.tasks\.remove\(task\.id\)/u);
  assert.match(app, /name="dueDate"|type="date"/u);
  assert.match(taskService, /validateDate\(input\.dueDate\)/u);
});

test('notes UI uses service search, tags, favorites, update and delete', () => {
  assert.match(app, /createNoteService/u);
  assert.match(app, /noteSearch\.trim\(\)\.toLocaleLowerCase/u);
  assert.match(app, /repositories\.notes\.update\(existing\.id, changes\)/u);
  assert.match(app, /repositories\.notes\.toggleFavorite\(note\.id\)/u);
  assert.match(app, /repositories\.notes\.remove\(note\.id\)/u);
  assert.match(noteService, /normalizeTags\(input\.tags\)/u);
  assert.match(noteService, /async search\(query: string\)/u);
});

test('diary UI uses service create, edit and delete with date and mood', () => {
  assert.match(app, /createDiaryService/u);
  assert.match(app, /date: diaryDate/u);
  assert.match(app, /mood: diaryMood/u);
  assert.match(app, /repositories\.diary\.create\(changes\)/u);
  assert.match(app, /repositories\.diary\.update\(existing\.id, changes\)/u);
  assert.match(app, /repositories\.diary\.remove\(entry\.id\)/u);
  assert.match(app, /mood-quick-options/u);
  assert.match(app, /latestDiaryEntry/u);
  assert.match(diaryService, /validateDate\(input\.date\)/u);
});

test('the app requires PIN setup or unlock before exposing personal records', async () => {
  assert.match(app, /<SecurityGate/u);
  assert.match(app, /createEncryptedNotesRepository/u);
  assert.match(app, /createEncryptedDiaryRepository/u);
  assert.match(app, /migrateLegacyContentStoresAtomically/u);
  assert.match(app, /createPinUnlockGuard/u);
  assert.match(app, /onClick=\{lockSecurity\}/u);
  assert.match(app, /security-lock-topbar/u);
  const gate = await readFile(new URL('../src/features/security/SecurityGate.tsx', import.meta.url), 'utf8');
  assert.match(gate, /recovery-code/u);
  assert.match(gate, /I saved the code|Я сохранил код/u);
  assert.match(gate, /Recover access|Восстановить доступ/u);
  assert.match(gate, /tasks, projects and habits are not encrypted/u);
});

test('More section links to the implemented projects, habits, calendar and statistics screens', () => {
  assert.match(app, /setScreen\('projects'\)/u);
  assert.match(app, /setScreen\('habits'\)/u);
  assert.match(app, /setScreen\('calendar'\)/u);
  assert.match(app, /setScreen\('stats'\)/u);
  assert.match(app, /<HabitsPage/u);
  assert.match(app, /<CalendarPage/u);
  assert.match(app, /<StatsPage/u);
  assert.match(app, /<ProjectsPanel/u);
});

test('settings expose a PIN-change flow without resetting the data-encryption key', () => {
  assert.match(app, /changePin\(/u);
  assert.match(app, /updateKeyring\(securityStoreRef\.current, changedKeyring\)/u);
  assert.match(app, /currentPin/u);
  assert.match(app, /confirmNewPin/u);
});

test('diary attachments are encrypted, previewed and included in encrypted backups', async () => {
  assert.match(app, /repositories\.attachments\.addFile/u);
  assert.match(app, /repositories\.attachments\.exportForBackup\(\)/u);
  assert.match(app, /createIndexedDbBackupAdapter/u);
  const picker = await readFile(new URL('../src/features/diary/AttachmentPicker.tsx', import.meta.url), 'utf8');
  const attachmentService = await readFile(new URL('../src/services/attachments.ts', import.meta.url), 'utf8');
  const backup = await readFile(new URL('../src/services/backup.ts', import.meta.url), 'utf8');
  assert.match(picker, /URL\.createObjectURL/u);
  assert.match(attachmentService, /encryptPayload/u);
  assert.match(attachmentService, /MAX_TOTAL_ATTACHMENT_BYTES/u);
  assert.match(backup, /restoreBackupPreview/u);
});

test('reminders are opt-in, use generic notification text and respect the no-auto-lock setting', async () => {
  assert.match(app, /requestReminderPermission\(\)/u);
  assert.match(app, /remindersEnabled/u);
  const reminders = await readFile(new URL('../src/services/reminders.ts', import.meta.url), 'utf8');
  assert.match(reminders, /Удели минуту своим планам и мыслям/u);
  assert.match(reminders, /Take a quiet minute for your plans and reflections/u);
  const settingsService = await readFile(new URL('../src/services/settings.ts', import.meta.url), 'utf8');
  assert.match(settingsService, /autoLockMinutes: 0/u);
  assert.match(settingsService, /hideNotificationContent: true/u);
});
