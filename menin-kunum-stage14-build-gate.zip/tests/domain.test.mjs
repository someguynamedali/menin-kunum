import test from 'node:test';
import assert from 'node:assert/strict';
import { validateRequiredTitle, validateIsoDate } from '../src/domain/validation.ts';

test('rejects an empty required title', () => {
  assert.deepEqual(validateRequiredTitle('   '), { valid: false, error: 'required' });
});

test('accepts a non-empty required title', () => {
  assert.deepEqual(validateRequiredTitle('Read 10 pages'), { valid: true, value: 'Read 10 pages' });
});

test('rejects an invalid ISO date', () => {
  assert.deepEqual(validateIsoDate('2026-99-44'), { valid: false, error: 'invalid_date' });
});
