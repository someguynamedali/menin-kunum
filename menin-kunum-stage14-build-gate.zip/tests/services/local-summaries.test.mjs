import test from 'node:test';
import assert from 'node:assert/strict';
const moduleUnderTest = await import('../../src/services/local-summaries.ts').catch(() => null);

test('local summaries return safe zero metrics for empty data', () => {
  assert.ok(moduleUnderTest, 'local summaries service must be implemented');
  const service = moduleUnderTest.createLocalSummariesService();
  const result = service.summarize({ tasks: [], notes: [], diaryEntries: [], habits: [], habitLogs: [] }, new Date('2026-10-15T12:00:00Z'));
  assert.equal(result.weekly.tasks, 0);
  assert.equal(result.monthly.diaryEntries, 0);
  assert.deepEqual(result.weekly.moodCounts, {});
});

test('local summaries aggregate week and month using local dates and exclude out-of-range records', () => {
  const service = moduleUnderTest.createLocalSummariesService();
  const result = service.summarize({
    tasks: [
      { id: 't1', title: 'A', priority: 'medium', status: 'completed', dueDate: '2026-10-12', dependencyIds: [], createdAt: '2026-10-10T12:00:00Z', updatedAt: '2026-10-12T12:00:00Z' },
      { id: 't2', title: 'B', priority: 'low', status: 'planned', dueDate: '2026-09-30', dependencyIds: [], createdAt: '2026-09-01T12:00:00Z', updatedAt: '2026-09-01T12:00:00Z' },
    ],
    notes: [{ id: 'n1', title: 'N', body: 'x', tags: [], favorite: false, createdAt: '2026-10-13T12:00:00Z', updatedAt: '2026-10-14T12:00:00Z' }],
    diaryEntries: [{ id: 'd1', date: '2026-10-14', title: 'D', body: 'x', mood: 'good', goodThings: [], concerns: [], gratitude: [], tags: [], attachmentIds: [], createdAt: 'x', updatedAt: 'x' }, { id: 'd2', date: '2026-09-28', title: 'Old', body: 'x', mood: 'low', goodThings: [], concerns: [], gratitude: [], tags: [], attachmentIds: [], createdAt: 'x', updatedAt: 'x' }],
    habits: [], habitLogs: [{ id: 'h1', habitId: 'h', date: '2026-10-15', value: 1 }, { id: 'h2', habitId: 'h', date: '2026-09-30', value: 1 }],
  }, new Date('2026-10-15T12:00:00Z'));
  assert.equal(result.weekly.tasks, 1);
  assert.equal(result.weekly.completedTasks, 1);
  assert.equal(result.weekly.notesUpdated, 1);
  assert.equal(result.weekly.diaryEntries, 1);
  assert.equal(result.weekly.habitLogs, 1);
  assert.equal(result.weekly.moodCounts.good, 1);
  assert.equal(result.monthly.diaryEntries, 1);
  assert.equal(result.monthly.habitLogs, 1);
});
