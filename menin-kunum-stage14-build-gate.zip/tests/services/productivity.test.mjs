import test from 'node:test';
import assert from 'node:assert/strict';

const load = async (path) => import(path).catch(() => null);
const taskModule = await load('../../src/services/tasks.ts');
const projectModule = await load('../../src/services/projects.ts');
const habitModule = await load('../../src/services/habits.ts');
const calendarModule = await load('../../src/services/calendar.ts');
const statisticsModule = await load('../../src/services/statistics.ts');

function createMemoryRepository() {
  const records = new Map();
  return {
    async create(record) { if (records.has(record.id)) throw new Error('duplicate'); records.set(record.id, structuredClone(record)); return structuredClone(record); },
    async getById(id) { return records.has(id) ? structuredClone(records.get(id)) : undefined; },
    async list() { return [...records.values()].map((record) => structuredClone(record)); },
    async update(record) { if (!records.has(record.id)) throw new Error('missing'); records.set(record.id, structuredClone(record)); return structuredClone(record); },
    async delete(id) { if (!records.has(id)) throw new Error('missing'); records.delete(id); },
  };
}
const options = { createId: (() => { let n = 0; return () => `p-${++n}`; })(), now: () => new Date('2026-10-15T10:00:00Z') };

test('task service exposes carry-forward, dependency and time-tracking operations', () => {
  assert.ok(taskModule, 'task service must be importable');
  const service = taskModule.createTaskService(createMemoryRepository(), options);
  assert.equal(typeof service.carryForwardUnfinishedTasks, 'function');
  assert.equal(typeof service.validateDependency, 'function');
  assert.equal(typeof service.setTimeTracking, 'function');
});

test('carry-forward changes only unfinished tasks and never moves completed tasks', async () => {
  const repo = createMemoryRepository();
  const service = taskModule.createTaskService(repo, options);
  const unfinished = await service.create({ title: 'Unfinished', dueDate: '2026-10-14' });
  const completed = await service.create({ title: 'Done', dueDate: '2026-10-14', status: 'completed' });
  const moved = await service.carryForwardUnfinishedTasks('2026-10-14', '2026-10-15');
  assert.deepEqual(moved.map((task) => task.id), [unfinished.id]);
  assert.equal((await repo.getById(unfinished.id)).dueDate, '2026-10-15');
  assert.equal((await repo.getById(completed.id)).dueDate, '2026-10-14');
  assert.equal((await repo.list()).length, 2);
});

test('task service stores and toggles subtasks on the parent task', async () => {
  const repo = createMemoryRepository();
  const service = taskModule.createTaskService(repo, options);
  const parent = await service.create({ title: 'Project task' });
  const subtask = await service.addSubtask(parent.id, 'First step');
  const updated = await service.setSubtaskCompleted(parent.id, subtask.id, true);
  assert.equal(updated.subtasks[0].completed, true);
  assert.equal(updated.subtasks[0].parentTaskId, parent.id);
});

test('dependency validation rejects cycles and allows an acyclic dependency graph', async () => {
  const service = taskModule.createTaskService(createMemoryRepository(), options);
  const first = await service.create({ title: 'First' });
  const second = await service.create({ title: 'Second', dependencyIds: [first.id] });
  assert.equal(await service.validateDependency(second.id, [first.id]), true);
  await assert.rejects(service.validateDependency(first.id, [second.id]), (error) => error.code === 'STORAGE_OPERATION_FAILED');
  await assert.rejects(service.update(first.id, { dependencyIds: [second.id] }), (error) => error.code === 'STORAGE_OPERATION_FAILED');
});

test('deleting a task removes references from dependent tasks', async () => {
  const repo = createMemoryRepository(); const service = taskModule.createTaskService(repo, options);
  const prerequisite = await service.create({ title: 'Prerequisite' });
  const dependent = await service.create({ title: 'Dependent', dependencyIds: [prerequisite.id] });
  await service.remove(prerequisite.id);
  assert.deepEqual((await repo.getById(dependent.id)).dependencyIds, []);
});

test('time tracking rejects negative values and stores planned versus actual minutes', async () => {
  const service = taskModule.createTaskService(createMemoryRepository(), options);
  const task = await service.create({ title: 'Study' });
  const tracked = await service.setTimeTracking(task.id, { estimatedMinutes: 45, actualMinutes: 60 });
  assert.equal(tracked.estimatedMinutes, 45);
  assert.equal(tracked.actualMinutes, 60);
  await assert.rejects(service.setTimeTracking(task.id, { actualMinutes: -1 }), (error) => error.code === 'STORAGE_OPERATION_FAILED');
});

test('project service can attach and detach tasks', async () => {
  assert.ok(projectModule, 'project service must be implemented');
  const projects = createMemoryRepository();
  const tasks = createMemoryRepository();
  const service = projectModule.createProjectService(projects, tasks, options);
  const task = { id: 'task-1', title: 'Task', priority: 'medium', status: 'planned', dependencyIds: [], createdAt: '2026-10-15T10:00:00.000Z', updatedAt: '2026-10-15T10:00:00.000Z' };
  await tasks.create(task);
  const project = await service.create({ title: 'My project' });
  const attached = await service.addTask(project.id, task.id);
  assert.deepEqual(attached.taskIds, ['task-1']);
  const detached = await service.removeTask(project.id, task.id);
  assert.deepEqual(detached.taskIds, []);
});

test('habit service validates measurements and calculates daily and weekly target progress', async () => {
  assert.ok(habitModule, 'habit service must be implemented');
  const habits = createMemoryRepository();
  const logs = createMemoryRepository();
  const service = habitModule.createHabitService(habits, logs, options);
  const habit = await service.create({ title: 'Read', measure: 'pages', targetValue: 20, targetPeriod: 'daily' });
  await service.recordHabitProgress(habit.id, '2026-10-15', 12);
  assert.deepEqual(await service.getProgress(habit.id, '2026-10-15'), { currentValue: 12, targetValue: 20, percent: 60, complete: false });
  await assert.rejects(service.recordHabitProgress(habit.id, '2026-10-15', -1), (error) => error.code === 'STORAGE_OPERATION_FAILED');
});

test('weekly habit progress aggregates logs from the start of the week', async () => {
  const habits = createMemoryRepository(); const logs = createMemoryRepository();
  const service = habitModule.createHabitService(habits, logs, options);
  const habit = await service.create({ title: 'Read weekly', measure: 'pages', targetValue: 50, targetPeriod: 'weekly' });
  await service.recordHabitProgress(habit.id, '2026-10-12', 20);
  await service.recordHabitProgress(habit.id, '2026-10-15', 15);
  assert.deepEqual(await service.getProgress(habit.id, '2026-10-15'), { currentValue: 35, targetValue: 50, percent: 70, complete: false });
});

test('weekly habit streak counts consecutive goal-complete weeks', async () => {
  const habits = createMemoryRepository(); const logs = createMemoryRepository();
  const service = habitModule.createHabitService(habits, logs, options);
  const habit = await service.create({ title: 'Weekly pages', measure: 'pages', targetValue: 30, targetPeriod: 'weekly' });
  await service.recordHabitProgress(habit.id, '2026-10-05', 35);
  await service.recordHabitProgress(habit.id, '2026-10-12', 15);
  assert.equal(await service.getStreak(habit.id, '2026-10-15'), 1);
  await service.recordHabitProgress(habit.id, '2026-10-15', 20);
  assert.equal(await service.getStreak(habit.id, '2026-10-15'), 2);
});

test('calendar expands selected weekdays without duplicating original records', async () => {
  assert.ok(calendarModule, 'calendar service must be implemented');
  const service = calendarModule.createCalendarService();
  const expanded = service.expandRecurringTasks([{ id: 'weekly', title: 'Run', status: 'planned', priority: 'medium', dependencyIds: [], dueDate: '2026-10-12', recurringRule: { weekdays: [1, 3] }, createdAt: '2026-10-12T08:00:00Z', updatedAt: '2026-10-12T08:00:00Z' }], '2026-10-12', '2026-10-18');
  assert.deepEqual(expanded.map((task) => task.dueDate), ['2026-10-12', '2026-10-14']);
  assert.equal(new Set(expanded.map((task) => `${task.id}:${task.dueDate}`)).size, expanded.length);
});

test('statistics return safe zero values when no local records exist', () => {
  assert.ok(statisticsModule, 'statistics service must be implemented');
  const summary = statisticsModule.createStatisticsService().summarize({ tasks: [], habits: [], habitLogs: [], diaryEntries: [] });
  assert.equal(summary.totalTasks, 0);
  assert.equal(summary.completionRate, 0);
  assert.equal(summary.estimatedMinutes, 0);
  assert.deepEqual(summary.moodCounts, {});
});
