import test from 'node:test';
import assert from 'node:assert/strict';
const settingsModule = await import('../../src/services/settings.ts').catch(() => null);
function memoryStore() { const records = new Map(); return { records, async add(r) { if (records.has(r.id)) throw new Error('duplicate'); records.set(r.id, structuredClone(r)); }, async get(id) { return records.has(id) ? structuredClone(records.get(id)) : undefined; }, async getAll() { return [...records.values()].map(structuredClone); }, async put(r) { records.set(r.id, structuredClone(r)); }, async delete(id) { records.delete(id); } }; }

test('settings default to no auto-lock and disabled private-content-free reminders', async () => {
  assert.ok(settingsModule, 'settings service must be implemented');
  const service = settingsModule.createSettingsService(memoryStore());
  const settings = await service.get();
  assert.equal(settings.autoLockMinutes, 0);
  assert.equal(settings.remindersEnabled, false);
  assert.equal(settings.hideNotificationContent, true);
  assert.equal(settings.dailyReminderTime, '20:00');
});

test('settings persist reminder preferences while forcing the approved no-auto-lock policy', async () => {
  const store = memoryStore(); const service = settingsModule.createSettingsService(store);
  const settings = await service.update({ remindersEnabled: true, dailyReminderTime: '21:15', autoLockMinutes: 15 });
  assert.equal(settings.remindersEnabled, true);
  assert.equal(settings.dailyReminderTime, '21:15');
  assert.equal(settings.autoLockMinutes, 0);
  assert.equal(settings.hideNotificationContent, true);
  assert.equal(store.records.get('app-settings').autoLockMinutes, 0);
});

test('settings reject invalid reminder times and locale values without writing', async () => {
  const store = memoryStore(); const service = settingsModule.createSettingsService(store);
  await assert.rejects(service.update({ dailyReminderTime: '25:99' }), /time|время/i);
  await assert.rejects(service.update({ locale: 'xx' }), /locale|язык/i);
  assert.equal(store.records.size, 0);
});
