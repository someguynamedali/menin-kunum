import test from 'node:test';
import assert from 'node:assert/strict';
const reminders = await import('../../src/services/reminders.ts').catch(() => null);

test('notification permission denial is handled without breaking the app', async () => {
  assert.ok(reminders, 'reminder service must be implemented');
  const result = await reminders.requestReminderPermission({ permission: 'default', async requestPermission() { return 'denied'; } });
  assert.equal(result, 'denied');
  assert.equal(await reminders.requestReminderPermission(undefined), 'unsupported');
});

test('reminders do not schedule when disabled or permission is denied', () => {
  let schedules = 0;
  const service = reminders.createReminderService({ scheduleTimeout: () => { schedules += 1; return 1; }, clearTimeout: () => {}, notify: async () => {} });
  service.schedule({ enabled: true, permission: 'denied', time: '20:00', locale: 'en' });
  service.schedule({ enabled: false, permission: 'granted', time: '20:00', locale: 'en' });
  assert.equal(schedules, 0);
});

test('reminder messages stay generic and contain no task or diary content', async () => {
  const notifications = []; let current = new Date('2026-10-15T17:59:00Z'); let scheduled;
  const service = reminders.createReminderService({ now: () => current, scheduleTimeout: (callback) => { scheduled = callback; return 1; }, clearTimeout: () => {}, notify: async (notice) => notifications.push(notice) });
  service.schedule({ enabled: true, permission: 'granted', time: '18:00', locale: 'en' });
  current = new Date('2026-10-15T18:00:00Z'); scheduled();
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(notifications.length, 1);
  assert.match(notifications[0].body, /plans|minute/i);
  assert.equal(/task|diary|secret|password/i.test(notifications[0].body), false);
});
