import test from 'node:test';
import assert from 'node:assert/strict';

const load = async (path) => import(path).catch(() => null);
const taskModule = await load('../../src/services/tasks.ts');
const noteModule = await load('../../src/services/notes.ts');
const diaryModule = await load('../../src/services/diary.ts');

test('task service exposes the planned service boundary', () => {
  assert.ok(taskModule, 'src/services/tasks.ts must exist and be importable');
  assert.equal(typeof taskModule.createTaskService, 'function');
});

test('note service exposes the planned service boundary', () => {
  assert.ok(noteModule, 'src/services/notes.ts must exist and be importable');
  assert.equal(typeof noteModule.createNoteService, 'function');
});

test('diary service exposes the planned service boundary', () => {
  assert.ok(diaryModule, 'src/services/diary.ts must exist and be importable');
  assert.equal(typeof diaryModule.createDiaryService, 'function');
});

function createMemoryRepository() {
  const records = new Map();
  return {
    async create(record) {
      if (records.has(record.id)) throw new Error('duplicate');
      records.set(record.id, structuredClone(record));
      return structuredClone(record);
    },
    async getById(id) { return records.has(id) ? structuredClone(records.get(id)) : undefined; },
    async list() { return [...records.values()].map((record) => structuredClone(record)); },
    async update(record) {
      if (!records.has(record.id)) throw new Error('missing');
      records.set(record.id, structuredClone(record));
      return structuredClone(record);
    },
    async delete(id) {
      if (!records.has(id)) throw new Error('missing');
      records.delete(id);
    },
  };
}

const testOptions = {
  createId: (() => { let next = 0; return () => `test-${++next}`; })(),
  now: () => new Date('2026-10-15T10:00:00.000Z'),
};

test('task service validates and persists create, update, search and delete', async (t) => {
  assert.ok(taskModule, 'task service must be implemented');
  const repository = createMemoryRepository();
  const service = taskModule.createTaskService(repository, testOptions);
  const created = await service.create({ title: '  Study chemistry  ', dueDate: '2026-10-16', priority: 'high' });
  assert.equal(created.title, 'Study chemistry');
  assert.equal(created.status, 'planned');
  assert.equal((await service.search('CHEMISTRY')).length, 1);
  const updated = await service.update(created.id, { title: 'Study physics' });
  assert.equal(updated.title, 'Study physics');
  assert.equal((await service.search('chemistry')).length, 0);
  await service.remove(created.id);
  assert.equal(await repository.getById(created.id), undefined);
  await assert.rejects(service.create({ title: '   ' }), (error) => error.code === 'STORAGE_OPERATION_FAILED');
});

test('note service searches body and tags and updates favorite state', async () => {
  assert.ok(noteModule, 'note service must be implemented');
  const repository = createMemoryRepository();
  const service = noteModule.createNoteService(repository, testOptions);
  const note = await service.create({ title: 'Book idea', body: 'A story about mountains', tags: ['Writing', 'Ideas'] });
  assert.equal((await service.search('mountains')).length, 1);
  assert.equal((await service.search('ideas')).length, 1);
  const updated = await service.update(note.id, { favorite: true, tags: ['Writing'] });
  assert.equal(updated.favorite, true);
  assert.deepEqual(updated.tags, ['Writing']);
  await service.remove(note.id);
  assert.equal((await service.list()).length, 0);
});

test('diary service validates date, searches entries and preserves mood on edits', async () => {
  assert.ok(diaryModule, 'diary service must be implemented');
  const repository = createMemoryRepository();
  const service = diaryModule.createDiaryService(repository, testOptions);
  const entry = await service.create({ date: '2026-10-15', title: 'A good day', body: 'Walked in the mountains', mood: 'good' });
  assert.equal((await service.search('mountains')).length, 1);
  const updated = await service.update(entry.id, { body: 'Read in the evening' });
  assert.equal(updated.mood, 'good');
  assert.equal((await service.search('mountains')).length, 0);
  await assert.rejects(service.create({ date: '2026-02-30', title: '', body: 'Invalid date' }), (error) => error.code === 'STORAGE_OPERATION_FAILED');
});
