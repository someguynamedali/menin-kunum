import test from 'node:test';
import assert from 'node:assert/strict';

const moduleUnderTest = await import('../../src/services/attachments.ts').catch(() => null);
const crypto = await import('../../src/security/crypto.ts').catch(() => null);

function memoryStore() {
  const records = new Map();
  return {
    records,
    async add(record) { if (records.has(record.id)) throw new Error('duplicate'); records.set(record.id, structuredClone(record)); },
    async get(id) { return records.has(id) ? structuredClone(records.get(id)) : undefined; },
    async getAll() { return [...records.values()].map((record) => structuredClone(record)); },
    async put(record) { records.set(record.id, structuredClone(record)); },
    async delete(id) { records.delete(id); },
  };
}
function fakeFile(name, type, content) {
  const bytes = new TextEncoder().encode(content);
  return { name, type, size: bytes.byteLength, async arrayBuffer() { return bytes.slice().buffer; } };
}

test('attachment service encrypts bytes before persistence and can decrypt a preview', async () => {
  assert.ok(moduleUnderTest, 'attachment service must be implemented');
  const store = memoryStore(); const key = await crypto.generateDataKey();
  const service = moduleUnderTest.createAttachmentsService(store, () => key, { createId: () => 'attachment-1', now: () => new Date('2026-10-15T00:00:00.000Z') });
  const file = fakeFile('private.txt', 'text/plain', 'secret attachment text');
  const metadata = await service.addFile(file);
  const stored = store.records.get(metadata.id);
  assert.equal(JSON.stringify(stored).includes('secret attachment text'), false);
  assert.ok(stored.encryptedContent.ciphertext);
  const blob = await service.readBlob(metadata.id);
  assert.equal(await blob.text(), 'secret attachment text');
});

test('attachment service rejects unsupported MIME types and oversized files before writing', async () => {
  const store = memoryStore(); const key = await crypto.generateDataKey();
  const service = moduleUnderTest.createAttachmentsService(store, () => key);
  await assert.rejects(service.addFile(fakeFile('run.exe', 'application/octet-stream', 'binary')), /type|тип/i);
  const huge = { name: 'huge.pdf', type: 'application/pdf', size: 5 * 1024 * 1024 + 1, async arrayBuffer() { throw new Error('must not read oversized file'); } };
  await assert.rejects(service.addFile(huge), /size|размер/i);
  assert.equal(store.records.size, 0);
});

test('attachment export for backup returns validated bytes without storing plaintext', async () => {
  const store = memoryStore(); const key = await crypto.generateDataKey();
  const service = moduleUnderTest.createAttachmentsService(store, () => key, { createId: () => 'attachment-backup' });
  await service.addFile(fakeFile('memo.txt', 'text/plain', 'backup-only plaintext'));
  const exported = await service.exportForBackup();
  assert.equal(exported[0].id, 'attachment-backup');
  assert.equal(new TextDecoder().decode(crypto.decodeBase64Url(exported[0].contentBase64)), 'backup-only plaintext');
  assert.equal(JSON.stringify(store.records.get('attachment-backup')).includes('backup-only plaintext'), false);
});

test('attachment service caps aggregate local attachment storage to avoid excessive mobile memory use', async () => {
  const store = memoryStore(); const key = await crypto.generateDataKey();
  const service = moduleUnderTest.createAttachmentsService(store, () => key);
  for (const id of ['att-old-1', 'att-old-2']) store.records.set(id, { id, mimeType: 'application/pdf', sizeBytes: 5 * 1024 * 1024, createdAt: 'old', encryptedContent: { formatVersion: 1, algorithm: 'AES-256-GCM', nonce: 'test', ciphertext: 'test' } });
  const tooMuch = new Uint8Array(1); tooMuch.fill(3);
  await assert.rejects(service.addFile({ type: 'text/plain', size: 1, async arrayBuffer() { return tooMuch.buffer; } }), /10 MB|10 МБ/i);
  assert.equal(store.records.size, 2);
});
