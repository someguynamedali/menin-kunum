import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

test('root app renders the app title through the active locale dictionary', async () => {
  const app = await readFile(new URL('../src/app/App.tsx', import.meta.url), 'utf8');
  assert.match(app, /<h1>\{t\(locale, 'app\.title'\)\}<\/h1>/u);
  const ru = await readFile(new URL('../src/i18n/locales/ru.ts', import.meta.url), 'utf8');
  assert.match(ru, /'app\.title': 'Менин күнүм'/u);
});
