import test from 'node:test';
import assert from 'node:assert/strict';
import { openAppDatabase, STORE_NAMES, DATABASE_VERSION } from '../../src/storage/db.ts';
import { StorageError } from '../../src/storage/errors.ts';

test('database schema includes all planned local record stores', () => {
  assert.deepEqual(STORE_NAMES, ['tasks', 'projects', 'notes', 'diaryEntries', 'habits', 'habitLogs', 'attachments', 'settings']);
  assert.equal(DATABASE_VERSION, 1);
});

test('reports a clear error when IndexedDB is unavailable', async () => {
  const original = globalThis.indexedDB;
  try {
    // Node's test runtime does not provide IndexedDB unless a browser polyfill is installed.
    Object.defineProperty(globalThis, 'indexedDB', { configurable: true, value: undefined });
    await assert.rejects(openAppDatabase(), (error) => {
      assert.ok(error instanceof StorageError);
      assert.equal(error.code, 'STORAGE_UNAVAILABLE');
      return true;
    });
  } finally {
    Object.defineProperty(globalThis, 'indexedDB', { configurable: true, value: original });
  }
});
