import test from 'node:test';
import assert from 'node:assert/strict';
import { createRepository } from '../../src/storage/repositories/base.ts';
import { StorageError } from '../../src/storage/errors.ts';

function memoryStore() {
  const rows = new Map();
  return {
    rows,
    async add(record) {
      if (rows.has(record.id)) throw new DOMException('duplicate', 'ConstraintError');
      rows.set(record.id, structuredClone(record));
    },
    async get(id) { return rows.has(id) ? structuredClone(rows.get(id)) : undefined; },
    async getAll() { return [...rows.values()].map((row) => structuredClone(row)); },
    async put(record) { rows.set(record.id, structuredClone(record)); },
    async delete(id) { rows.delete(id); },
  };
}

test('repository creates, reads, lists, updates and deletes records', async () => {
  const repository = createRepository(memoryStore());
  const first = { id: 'n1', title: 'Test note' };
  assert.deepEqual(await repository.create(first), first);
  assert.deepEqual(await repository.getById('n1'), first);
  assert.deepEqual(await repository.list(), [first]);
  const updated = { ...first, title: 'Updated note' };
  assert.deepEqual(await repository.update(updated), updated);
  assert.deepEqual(await repository.getById('n1'), updated);
  await repository.delete('n1');
  assert.equal(await repository.getById('n1'), undefined);
});

test('repository refuses to update a missing record', async () => {
  const repository = createRepository(memoryStore());
  await assert.rejects(repository.update({ id: 'missing', title: 'No record' }), (error) => {
    assert.ok(error instanceof StorageError);
    assert.equal(error.code, 'NOT_FOUND');
    return true;
  });
});

test('repository maps duplicate ID errors instead of claiming success', async () => {
  const repository = createRepository(memoryStore());
  await repository.create({ id: 'same', title: 'first' });
  await assert.rejects(repository.create({ id: 'same', title: 'second' }), (error) => {
    assert.ok(error instanceof StorageError);
    assert.equal(error.code, 'DUPLICATE_ID');
    return true;
  });
});
