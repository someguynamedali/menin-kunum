import test from 'node:test';
import assert from 'node:assert/strict';

const cryptoModule = await import('../../src/security/crypto.ts').catch(() => null);

test('crypto module exposes authenticated payload encryption', () => {
  assert.ok(cryptoModule, 'src/security/crypto.ts must exist and be importable');
  assert.equal(typeof cryptoModule.encryptPayload, 'function');
  assert.equal(typeof cryptoModule.decryptPayload, 'function');
});

test('AES-GCM payload round-trips with matching associated data', async () => {
  assert.ok(cryptoModule, 'crypto module must be implemented');
  const key = await cryptoModule.generateDataKey();
  const payload = await cryptoModule.encryptPayload('private note', key, 'notes:random-id');
  assert.equal(payload.formatVersion, 1);
  assert.equal(payload.algorithm, 'AES-256-GCM');
  assert.equal(await cryptoModule.decryptPayload(payload, key, 'notes:random-id'), 'private note');
});

test('AES-GCM rejects altered ciphertext and wrong associated data', async () => {
  assert.ok(cryptoModule, 'crypto module must be implemented');
  const key = await cryptoModule.generateDataKey();
  const payload = await cryptoModule.encryptPayload('private note', key, 'notes:one');
  const bytes = cryptoModule.decodeBase64Url(payload.ciphertext);
  bytes[0] ^= 1;
  const altered = { ...payload, ciphertext: cryptoModule.encodeBase64Url(bytes) };
  await assert.rejects(cryptoModule.decryptPayload(altered, key, 'notes:one'));
  await assert.rejects(cryptoModule.decryptPayload(payload, key, 'notes:two'));
});

test('AES-GCM rejects wrong key and unsupported payload version', async () => {
  assert.ok(cryptoModule, 'crypto module must be implemented');
  const key = await cryptoModule.generateDataKey();
  const wrongKey = await cryptoModule.generateDataKey();
  const payload = await cryptoModule.encryptPayload('private note', key, 'notes:one');
  await assert.rejects(cryptoModule.decryptPayload(payload, wrongKey, 'notes:one'));
  await assert.rejects(cryptoModule.decryptPayload({ ...payload, formatVersion: 999 }, key, 'notes:one'), /version/i);
});
