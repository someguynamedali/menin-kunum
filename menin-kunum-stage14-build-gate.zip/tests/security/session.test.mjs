import test from 'node:test';
import assert from 'node:assert/strict';

const sessionModule = await import('../../src/security/session.ts').catch(() => null);

test('session module exposes an in-memory manual-lock session', () => {
  assert.ok(sessionModule, 'src/security/session.ts must exist and be importable');
  assert.equal(typeof sessionModule.createSecuritySession, 'function');
});

test('session only exposes the key while unlocked and manual lock removes access', async () => {
  assert.ok(sessionModule, 'session module must be implemented');
  const session = sessionModule.createSecuritySession();
  const key = { marker: 'test-only' };
  assert.equal(session.isUnlocked(), false);
  assert.throws(() => session.getDataKey(), /locked/i);
  session.unlock(key);
  assert.equal(session.isUnlocked(), true);
  assert.equal(session.getDataKey(), key);
  session.lockSession();
  assert.equal(session.isUnlocked(), false);
  assert.throws(() => session.getDataKey(), /locked/i);
});

test('session has no inactivity timer and remains unlocked until manual lock', async () => {
  assert.ok(sessionModule, 'session module must be implemented');
  const session = sessionModule.createSecuritySession();
  session.unlock({ marker: 'test-only' });
  await new Promise((resolve) => setTimeout(resolve, 30));
  assert.equal(session.isUnlocked(), true);
  session.lockSession();
});
