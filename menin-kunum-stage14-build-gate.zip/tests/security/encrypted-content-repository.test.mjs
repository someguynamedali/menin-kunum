import test from 'node:test';
import assert from 'node:assert/strict';

const repositoryModule = await import('../../src/storage/repositories/encrypted-content.ts').catch(() => null);
const cryptoModule = await import('../../src/security/crypto.ts').catch(() => null);

function memoryStore() {
  const records = new Map();
  return {
    records,
    async add(record) { if (records.has(record.id)) throw new Error('duplicate'); records.set(record.id, structuredClone(record)); },
    async get(id) { return records.has(id) ? structuredClone(records.get(id)) : undefined; },
    async getAll() { return [...records.values()].map((record) => structuredClone(record)); },
    async put(record) { if (!records.has(record.id)) throw new Error('missing'); records.set(record.id, structuredClone(record)); },
    async delete(id) { records.delete(id); },
  };
}

test('encrypted content repository stores note body as ciphertext and decrypts it on read', async () => {
  assert.ok(repositoryModule, 'encrypted content repository must be implemented');
  assert.ok(cryptoModule, 'crypto primitives must be implemented');
  const store = memoryStore();
  const key = await cryptoModule.generateDataKey();
  const repository = repositoryModule.createEncryptedContentRepository(store, () => key, {
    storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'],
  });
  const note = { id: 'note-random-id', title: 'Open title', body: 'SECRET BODY TEXT', tags: ['open-tag'], favorite: false, createdAt: '2026-10-15T00:00:00.000Z', updatedAt: '2026-10-15T00:00:00.000Z' };
  await repository.create(note);
  const stored = store.records.get(note.id);
  assert.equal(stored.title, note.title);
  assert.deepEqual(stored.tags, note.tags);
  assert.equal(JSON.stringify(stored).includes('SECRET BODY TEXT'), false);
  assert.ok(stored.encryptedContent.ciphertext);
  assert.deepEqual(await repository.getById(note.id), note);
});

test('encrypted content repository preserves future private fields across reads and updates', async () => {
  const store = memoryStore();
  const key = await cryptoModule.generateDataKey();
  const repository = repositoryModule.createEncryptedContentRepository(store, () => key, {
    storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'],
  });
  await repository.create({ id: 'note-forward-compatible', title: 'Title', body: 'Private body', futurePrivateField: 'Private future value', tags: [], favorite: false, createdAt: 'a', updatedAt: 'a' });
  assert.equal(JSON.stringify(store.records.get('note-forward-compatible')).includes('Private future value'), false);
  const loaded = await repository.getById('note-forward-compatible');
  assert.equal(loaded.futurePrivateField, 'Private future value');
  await repository.update({ ...loaded, title: 'Updated title' });
  assert.equal((await repository.getById('note-forward-compatible')).futurePrivateField, 'Private future value');
});

test('encrypted content repository rejects reads while locked and rejects tampered ciphertext', async () => {
  assert.ok(repositoryModule, 'encrypted content repository must be implemented');
  const store = memoryStore();
  const key = await cryptoModule.generateDataKey();
  let unlocked = true;
  const repository = repositoryModule.createEncryptedContentRepository(store, () => {
    if (!unlocked) throw new Error('Security session is locked');
    return key;
  }, { storeName: 'diaryEntries', publicFields: ['date', 'title', 'tags'], encryptedFields: ['body', 'mood'] });
  await repository.create({ id: 'diary-random-id', date: '2026-10-15', title: 'Open title', tags: [], body: 'Private entry', mood: 'good' });
  unlocked = false;
  await assert.rejects(repository.getById('diary-random-id'), /locked/i);
  unlocked = true;
  const stored = store.records.get('diary-random-id');
  const bytes = cryptoModule.decodeBase64Url(stored.encryptedContent.ciphertext);
  bytes[0] ^= 1;
  stored.encryptedContent.ciphertext = cryptoModule.encodeBase64Url(bytes);
  store.records.set(stored.id, stored);
  await assert.rejects(repository.getById(stored.id));
});
