import test from 'node:test';
import assert from 'node:assert/strict';

const backup = await import('../../src/services/backup.ts').catch(() => null);
const crypto = await import('../../src/security/crypto.ts').catch(() => null);

function snapshot(overrides = {}) {
  return {
    schemaVersion: 1,
    exportedAt: '2026-10-15T17:00:00.000Z',
    records: {
      tasks: [], projects: [], notes: [{ id: 'note-1', title: 'Visible title', body: 'private backup note', tags: ['school'], favorite: false, createdAt: '2026-10-15T17:00:00.000Z', updatedAt: '2026-10-15T17:00:00.000Z' }],
      diaryEntries: [], habits: [], habitLogs: [], attachments: [],
      ...overrides,
    },
  };
}

function memoryRestoreAdapter() {
  let records = { tasks: [{ id: 'old-task', title: 'keep until valid' }], projects: [], notes: [], diaryEntries: [], habits: [], habitLogs: [], attachments: [] };
  let writes = 0;
  return {
    get records() { return structuredClone(records); },
    get writes() { return writes; },
    async replaceAtomically(nextRecords) { records = structuredClone(nextRecords); writes += 1; },
  };
}

test('encrypted backup exports and previews a validated snapshot', async () => {
  assert.ok(backup, 'encrypted backup service must be implemented');
  const serialized = await backup.exportEncryptedBackup(snapshot(), 'long backup phrase 2026', { iterations: 1000 });
  assert.equal(serialized.includes('private backup note'), false);
  const preview = await backup.previewEncryptedBackup(serialized, 'long backup phrase 2026', { iterations: 1000 });
  assert.equal(preview.metadata.counts.notes, 1);
  assert.equal(preview.snapshot.records.notes[0].body, 'private backup note');
});

test('backup rejects a wrong passphrase and never calls restore', async () => {
  const serialized = await backup.exportEncryptedBackup(snapshot(), 'long backup phrase 2026', { iterations: 1000 });
  const adapter = memoryRestoreAdapter();
  const before = adapter.records;
  await assert.rejects(backup.restoreEncryptedBackup(serialized, 'wrong backup phrase', await crypto.generateDataKey(), adapter, { iterations: 1000 }));
  assert.deepEqual(adapter.records, before);
  assert.equal(adapter.writes, 0);
});

test('backup rejects truncated, corrupted and unsupported-version files', async () => {
  const serialized = await backup.exportEncryptedBackup(snapshot(), 'long backup phrase 2026', { iterations: 1000 });
  await assert.rejects(backup.previewEncryptedBackup(serialized.slice(0, -18), 'long backup phrase 2026', { iterations: 1000 }));
  const envelope = JSON.parse(serialized);
  envelope.payload.ciphertext = envelope.payload.ciphertext.slice(0, -2) + 'AA';
  await assert.rejects(backup.previewEncryptedBackup(JSON.stringify(envelope), 'long backup phrase 2026', { iterations: 1000 }));
  const unsupported = JSON.parse(serialized); unsupported.version = 99;
  await assert.rejects(backup.previewEncryptedBackup(JSON.stringify(unsupported), 'long backup phrase 2026', { iterations: 1000 }), /version|format|версия|формат/i);
});

test('backup validates record shape and duplicate IDs before restore', async () => {
  const invalid = snapshot({ notes: [{ id: 'same', title: 'A', body: 'x', tags: [], favorite: false, createdAt: '2026-10-15T17:00:00.000Z', updatedAt: '2026-10-15T17:00:00.000Z' }, { id: 'same', title: 'B', body: 'y', tags: [], favorite: false, createdAt: '2026-10-15T17:00:00.000Z', updatedAt: '2026-10-15T17:00:00.000Z' }] });
  await assert.rejects(backup.exportEncryptedBackup(invalid, 'long backup phrase 2026', { iterations: 1000 }), /duplicate|идентификатор/i);
  const unknown = snapshot({ notes: [{ id: 'note-1', title: 'A', body: 'secret', tags: [], favorite: false, createdAt: '2026-10-15T17:00:00.000Z', updatedAt: '2026-10-15T17:00:00.000Z', encryptedContent: { ciphertext: 'bad' } }] });
  await assert.rejects(backup.exportEncryptedBackup(unknown, 'long backup phrase 2026', { iterations: 1000 }));
});

test('valid backup is applied only after complete preview validation', async () => {
  const serialized = await backup.exportEncryptedBackup(snapshot(), 'long backup phrase 2026', { iterations: 1000 });
  const adapter = memoryRestoreAdapter();
  const preview = await backup.restoreEncryptedBackup(serialized, 'long backup phrase 2026', await crypto.generateDataKey(), adapter, { iterations: 1000 });
  assert.equal(adapter.writes, 1);
  assert.equal(adapter.records.notes[0].body, 'private backup note');
  assert.equal(preview.metadata.counts.notes, 1);
});


test('backup rejects malformed nested task fields before restoring', async () => {
  const malformed = snapshot({ tasks: [{
    id: 'task-1', title: 'Task', priority: 'medium', status: 'planned', dependencyIds: [],
    subtasks: { id: 'not-an-array' }, createdAt: '2026-10-15T17:00:00.000Z', updatedAt: '2026-10-15T17:00:00.000Z',
  }] });
  assert.throws(() => backup.validateBackupSnapshot(malformed), /Подзадачи|subtasks/i);
});

test('backup rejects malformed diary dates and oversized text fields', async () => {
  const badDate = snapshot({ diaryEntries: [{ id: 'diary-1', date: '2026-02-31', title: 'Entry', body: 'text', tags: [], createdAt: '2026-10-15T17:00:00.000Z', updatedAt: '2026-10-15T17:00:00.000Z' }] });
  assert.throws(() => backup.validateBackupSnapshot(badDate), /Дата дневника/i);
  const oversized = snapshot({ notes: [{ id: 'note-2', title: 'Title', body: 'x'.repeat(20_001), tags: [], favorite: false, createdAt: '2026-10-15T17:00:00.000Z', updatedAt: '2026-10-15T17:00:00.000Z' }] });
  assert.throws(() => backup.validateBackupSnapshot(oversized), /body|Поле/i);
});

test('backup rejects dangling references and task dependency cycles', async () => {
  const stamp = '2026-10-15T17:00:00.000Z';
  const dangling = snapshot({ tasks: [{ id: 'task-1', title: 'Task', priority: 'medium', status: 'planned', dependencyIds: ['missing'], createdAt: stamp, updatedAt: stamp }] });
  assert.throws(() => backup.validateBackupSnapshot(dangling), /ссылается|отсутствующ/i);
  const cyclic = snapshot({ tasks: [
    { id: 'task-1', title: 'One', priority: 'medium', status: 'planned', dependencyIds: ['task-2'], createdAt: stamp, updatedAt: stamp },
    { id: 'task-2', title: 'Two', priority: 'medium', status: 'planned', dependencyIds: ['task-1'], createdAt: stamp, updatedAt: stamp },
  ] });
  assert.throws(() => backup.validateBackupSnapshot(cyclic), /цикл/i);
});

test('restore rejects altered preview metadata before any storage write', async () => {
  const serialized = await backup.exportEncryptedBackup(snapshot(), 'long backup phrase 2026', { iterations: 1000 });
  const preview = await backup.previewEncryptedBackup(serialized, 'long backup phrase 2026', { iterations: 1000 });
  const adapter = memoryRestoreAdapter();
  const before = adapter.records;
  const altered = structuredClone(preview);
  altered.metadata.schemaVersion = 99;
  await assert.rejects(backup.restoreBackupPreview(altered, await crypto.generateDataKey(), adapter), /preview|metadata|version|предваритель|верси/i);
  assert.deepEqual(adapter.records, before);
  assert.equal(adapter.writes, 0);
});

test('restore rejects malformed preview counts before any storage write', async () => {
  const serialized = await backup.exportEncryptedBackup(snapshot(), 'long backup phrase 2026', { iterations: 1000 });
  const preview = await backup.previewEncryptedBackup(serialized, 'long backup phrase 2026', { iterations: 1000 });
  const adapter = memoryRestoreAdapter();
  const before = adapter.records;
  const altered = structuredClone(preview);
  altered.metadata.counts.notes = Number.NaN;
  await assert.rejects(backup.restoreBackupPreview(altered, await crypto.generateDataKey(), adapter), /count|счётчик|предваритель/i);
  assert.deepEqual(adapter.records, before);
  assert.equal(adapter.writes, 0);
});
