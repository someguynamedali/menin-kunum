import test from 'node:test';
import assert from 'node:assert/strict';

const migrationModule = await import('../../src/security/migration.ts').catch(() => null);
const cryptoModule = await import('../../src/security/crypto.ts').catch(() => null);
const encryptedRepositoryModule = await import('../../src/storage/repositories/encrypted-content.ts').catch(() => null);

function memoryStore(initial = []) {
  const records = new Map(initial.map((record) => [record.id, structuredClone(record)]));
  return {
    records,
    async add(record) { if (records.has(record.id)) throw new Error('duplicate'); records.set(record.id, structuredClone(record)); },
    async get(id) { return records.has(id) ? structuredClone(records.get(id)) : undefined; },
    async getAll() { return [...records.values()].map((record) => structuredClone(record)); },
    async put(record) { if (!records.has(record.id)) throw new Error('missing'); records.set(record.id, structuredClone(record)); },
    async delete(id) { records.delete(id); },
  };
}

function migrationAdapter({ notes = [], diaryEntries = [], failNextCommit = false } = {}) {
  const stores = { notes: memoryStore(notes), diaryEntries: memoryStore(diaryEntries) };
  let shouldFail = failNextCommit;
  let commits = 0;
  return {
    stores,
    get commits() { return commits; },
    async readAll(storeName) { return stores[storeName].getAll(); },
    async commitAtomically(changes) {
      for (const change of changes) {
        assert.deepEqual(await stores[change.storeName].getAll(), change.before, 'adapter checks the staged snapshot before commit');
      }
      if (shouldFail) { shouldFail = false; throw new Error('simulated transaction abort'); }
      const replacements = new Map();
      for (const change of changes) {
        if (!change.changed) continue;
        replacements.set(change.storeName, new Map(change.after.map((record) => [record.id, structuredClone(record)])));
      }
      for (const [name, records] of replacements) stores[name].records.clear(), records.forEach((record, id) => stores[name].records.set(id, record));
      commits += 1;
    },
  };
}

test('legacy notes migrate to ciphertext while approved metadata remains searchable', async () => {
  assert.ok(migrationModule, 'atomic content migration must be implemented');
  const adapter = migrationAdapter({ notes: [{ id: 'note-1', title: 'Open title', body: 'private note body', tags: ['school'], favorite: true, createdAt: '2026-10-01', updatedAt: '2026-10-02' }] });
  const key = await cryptoModule.generateDataKey();
  await migrationModule.migrateLegacyContentStoresAtomically(adapter, key);
  const saved = adapter.stores.notes.records.get('note-1');
  assert.equal(saved.title, 'Open title');
  assert.deepEqual(saved.tags, ['school']);
  assert.equal(JSON.stringify(saved).includes('private note body'), false);
  assert.ok(saved.encryptedContent);
  const repository = encryptedRepositoryModule.createEncryptedContentRepository(adapter.stores.notes, () => key, { storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'] });
  assert.equal((await repository.getById('note-1')).body, 'private note body');
});

test('migration encrypts diary mood and private lists and is idempotent', async () => {
  const adapter = migrationAdapter({ diaryEntries: [{ id: 'diary-1', date: '2026-10-15', title: 'Open title', tags: ['life'], body: 'private diary', mood: 'good', goodThings: ['friend-secret'], concerns: ['exam-secret'], gratitude: ['family-secret'], attachmentIds: ['attachment-secret'], createdAt: 'now', updatedAt: 'now' }] });
  const key = await cryptoModule.generateDataKey();
  const first = await migrationModule.migrateLegacyContentStoresAtomically(adapter, key);
  const stored = adapter.stores.diaryEntries.records.get('diary-1');
  assert.equal(JSON.stringify(stored).includes('private diary'), false);
  assert.equal(JSON.stringify(stored).includes('friend-secret'), false);
  assert.equal(JSON.stringify(stored).includes('exam-secret'), false);
  assert.equal(JSON.stringify(stored).includes('family-secret'), false);
  assert.equal(JSON.stringify(stored).includes('attachment-secret'), false);
  assert.equal(stored.title, 'Open title');
  assert.equal(stored.date, '2026-10-15');
  assert.equal(first.diaryEntries.migrated, 1);
  const commitsBeforeRepeat = adapter.commits;
  const second = await migrationModule.migrateLegacyContentStoresAtomically(adapter, key);
  assert.equal(second.diaryEntries.alreadyEncrypted, 1);
  assert.equal(adapter.commits, commitsBeforeRepeat, 'already-encrypted records should not be rewritten');
});

test('aborted multi-store migration leaves all plaintext records untouched and can be retried', async () => {
  const adapter = migrationAdapter({
    notes: [{ id: 'n1', title: 'One', body: 'secret one', tags: [], favorite: false, createdAt: 'a', updatedAt: 'a' }],
    diaryEntries: [{ id: 'd1', date: '2026-10-15', title: 'Two', body: 'secret two', tags: [], mood: 'good', createdAt: 'a', updatedAt: 'a' }],
    failNextCommit: true,
  });
  const key = await cryptoModule.generateDataKey();
  await assert.rejects(migrationModule.migrateLegacyContentStoresAtomically(adapter, key), /transaction abort/i);
  assert.equal(adapter.stores.notes.records.get('n1').body, 'secret one');
  assert.equal(adapter.stores.diaryEntries.records.get('d1').body, 'secret two');
  await migrationModule.migrateLegacyContentStoresAtomically(adapter, key);
  assert.equal(JSON.stringify(adapter.stores.notes.records.get('n1')).includes('secret one'), false);
  assert.equal(JSON.stringify(adapter.stores.diaryEntries.records.get('d1')).includes('secret two'), false);
});


test('migration preserves unknown legacy fields inside ciphertext instead of silently dropping them', async () => {
  const adapter = migrationAdapter({ notes: [{ id: 'note-future', title: 'Open title', body: 'private body', privateExtra: 'future private value', tags: ['school'], favorite: false, createdAt: 'a', updatedAt: 'a' }] });
  const key = await cryptoModule.generateDataKey();
  await migrationModule.migrateLegacyContentStoresAtomically(adapter, key);
  const stored = adapter.stores.notes.records.get('note-future');
  assert.equal(Object.hasOwn(stored, 'privateExtra'), false);
  assert.equal(JSON.stringify(stored).includes('future private value'), false);
  const repository = encryptedRepositoryModule.createEncryptedContentRepository(adapter.stores.notes, () => key, { storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'] });
  assert.equal((await repository.getById('note-future')).privateExtra, 'future private value');
});

test('migration seals unexpected plaintext fields on an already encrypted record without losing them', async () => {
  const key = await cryptoModule.generateDataKey();
  const payload = await cryptoModule.encryptPayload('{"body":"private body"}', key, 'menin-kunum:record:v1:notes:note-leak');
  const adapter = migrationAdapter({ notes: [{ id: 'note-leak', title: 'Open title', tags: [], favorite: false, createdAt: 'a', updatedAt: 'a', encryptedContent: payload, leakedField: 'plaintext leak' }] });
  await migrationModule.migrateLegacyContentStoresAtomically(adapter, key);
  const stored = adapter.stores.notes.records.get('note-leak');
  assert.equal(Object.hasOwn(stored, 'leakedField'), false);
  assert.equal(JSON.stringify(stored).includes('plaintext leak'), false);
  const repository = encryptedRepositoryModule.createEncryptedContentRepository(adapter.stores.notes, () => key, { storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'] });
  assert.equal((await repository.getById('note-leak')).leakedField, 'plaintext leak');
});

test('startup refuses to create a new keyring when encrypted records exist without their keyring', async () => {
  const key = await cryptoModule.generateDataKey();
  const store = memoryStore([{ id: 'note-orphan', title: 'visible', tags: [], favorite: false, createdAt: 'a', updatedAt: 'a', encryptedContent: await cryptoModule.encryptPayload('{"body":"old secret"}', key, 'menin-kunum:record:v1:notes:note-orphan') }]);
  await assert.rejects(migrationModule.assertKeyringPresentForEncryptedRecords(undefined, [store]), /keyring.*missing|ключ.*не найден|recovery/i);
  await assert.doesNotReject(migrationModule.assertKeyringPresentForEncryptedRecords({ version: 1 }, [store]));
});

test('startup also refuses a new keyring when encrypted attachments exist without their keyring', async () => {
  const key = await cryptoModule.generateDataKey();
  const attachmentStore = memoryStore([{ id: 'attachment-orphan', mimeType: 'image/png', sizeBytes: 1, createdAt: 'a', encryptedContent: await cryptoModule.encryptPayload('AA', key, 'menin-kunum:attachment:v1:attachment-orphan') }]);
  await assert.rejects(migrationModule.assertKeyringPresentForEncryptedRecords(undefined, [attachmentStore]), /keyring.*missing|ключ.*не найден|recovery/i);
  await assert.doesNotReject(migrationModule.assertKeyringPresentForEncryptedRecords({ version: 1 }, [attachmentStore]));
});
