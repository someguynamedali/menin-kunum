import test from 'node:test';
import assert from 'node:assert/strict';

const moduleUnderTest = await import('../../src/security/keyring-store.ts').catch(() => null);
const keyManagement = await import('../../src/security/key-management.ts').catch(() => null);

function memoryStore() {
  const records = new Map();
  return {
    records,
    async add(record) {
      if (records.has(record.id)) throw new Error('duplicate');
      records.set(record.id, structuredClone(record));
    },
    async get(id) { return records.has(id) ? structuredClone(records.get(id)) : undefined; },
    async getAll() { return [...records.values()].map((record) => structuredClone(record)); },
    async put(record) {
      if (!records.has(record.id)) throw new Error('missing');
      records.set(record.id, structuredClone(record));
    },
    async delete(id) { records.delete(id); },
  };
}

test('keyring store persists only wrapped keys and can load them again', async () => {
  assert.ok(moduleUnderTest, 'keyring store must be implemented');
  assert.ok(keyManagement, 'key management must be implemented');
  const store = memoryStore();
  const setup = await keyManagement.initializeKeyring('secure-pin-123', { iterations: 1000 });
  await moduleUnderTest.saveKeyring(store, setup.keyring);
  const persisted = store.records.get('security-keyring');
  assert.ok(persisted);
  assert.equal(JSON.stringify(persisted).includes('secure-pin-123'), false);
  assert.equal(JSON.stringify(persisted).includes(setup.recoveryCode), false);
  assert.deepEqual(await moduleUnderTest.loadKeyring(store), setup.keyring);
});

test('keyring setup never overwrites an existing keyring', async () => {
  assert.ok(moduleUnderTest);
  const store = memoryStore();
  const first = (await keyManagement.initializeKeyring('secure-pin-111', { iterations: 1000 })).keyring;
  const second = (await keyManagement.initializeKeyring('secure-pin-222', { iterations: 1000 })).keyring;
  await moduleUnderTest.saveKeyring(store, first);
  await assert.rejects(moduleUnderTest.saveKeyring(store, second), /уже существует|duplicate/i);
  assert.deepEqual(await moduleUnderTest.loadKeyring(store), first);
});

test('keyring loading rejects malformed KDF parameters and wrapped payload metadata', async () => {
  assert.ok(moduleUnderTest);
  const store = memoryStore();
  const setup = await keyManagement.initializeKeyring('secure-pin-123', { iterations: 1000 });
  await moduleUnderTest.saveKeyring(store, setup.keyring);
  const record = store.records.get('security-keyring');
  record.keyring.pin.iterations = 9_999_999;
  store.records.set('security-keyring', record);
  await assert.rejects(moduleUnderTest.loadKeyring(store), /повреждена|формат|keyring|iteration|parameters/i);

  record.keyring = structuredClone(setup.keyring);
  record.keyring.recovery.wrappedDataKey.nonce = 'AA';
  store.records.set('security-keyring', record);
  await assert.rejects(moduleUnderTest.loadKeyring(store), /повреждена|формат|keyring|nonce|payload/i);
});
