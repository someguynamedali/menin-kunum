import test from 'node:test';
import assert from 'node:assert/strict';

const keys = await import('../../src/security/key-management.ts').catch(() => null);

test('key management module exposes setup, unlock, PIN change and recovery', () => {
  assert.ok(keys, 'src/security/key-management.ts must exist and be importable');
  for (const name of ['initializeKeyring', 'unlockWithPin', 'changePin', 'recoverWithCode']) {
    assert.equal(typeof keys[name], 'function', `${name} must be exported`);
  }
});

test('wrong PIN and wrong recovery code fail without changing keyring', async () => {
  assert.ok(keys, 'key management must be implemented');
  const setup = await keys.initializeKeyring('135790', { iterations: 1000 });
  const before = JSON.stringify(setup.keyring);
  await assert.rejects(keys.unlockWithPin('000000', setup.keyring));
  await assert.rejects(keys.recoverWithCode('00000000', '246810', setup.keyring));
  assert.equal(JSON.stringify(setup.keyring), before);
});

test('PIN change preserves access to the same encrypted data key', async () => {
  assert.ok(keys, 'key management must be implemented');
  const setup = await keys.initializeKeyring('135790', { iterations: 1000 });
  const before = await keys.unlockWithPin('135790', setup.keyring);
  const changed = await keys.changePin('135790', '246810', setup.keyring, { iterations: 1000 });
  await assert.rejects(keys.unlockWithPin('135790', changed));
  const after = await keys.unlockWithPin('246810', changed);
  const crypto = await import('../../src/security/crypto.ts');
  const a = await crypto.encryptPayload('same key', before, 'test:id');
  assert.equal(await crypto.decryptPayload(a, after, 'test:id'), 'same key');
});

test('recovery code restores access and allows setting a new PIN', async () => {
  assert.ok(keys, 'key management must be implemented');
  const setup = await keys.initializeKeyring('135790', { iterations: 1000 });
  const recovered = await keys.recoverWithCode(setup.recoveryCode, '987654', setup.keyring, { iterations: 1000 });
  await assert.rejects(keys.unlockWithPin('135790', recovered.keyring));
  const unlocked = await keys.unlockWithPin('987654', recovered.keyring);
  const crypto = await import('../../src/security/crypto.ts');
  const payload = await crypto.encryptPayload('existing data', recovered.dataKey, 'diary:id');
  assert.equal(await crypto.decryptPayload(payload, unlocked, 'diary:id'), 'existing data');
});

test('serialized keyring contains neither PIN, recovery code nor plaintext data key', async () => {
  assert.ok(keys, 'key management must be implemented');
  const setup = await keys.initializeKeyring('secret-pin-381', { iterations: 1000 });
  const serialized = JSON.stringify(setup.keyring);
  assert.equal(serialized.includes('secret-pin-381'), false);
  assert.equal(serialized.includes(setup.recoveryCode), false);
  assert.equal(serialized.includes('dataKeyBytes'), false);
  assert.equal(typeof setup.recoveryCode, 'string');
});


test('recovery code checksum rejects a mistyped code before keyring changes', async () => {
  assert.ok(keys, 'key management must be implemented');
  const setup = await keys.initializeKeyring('135790', { iterations: 1000 });
  const before = JSON.stringify(setup.keyring);
  const corrupted = `${setup.recoveryCode.slice(0, -1)}${setup.recoveryCode.endsWith('0') ? '1' : '0'}`;
  await assert.rejects(keys.recoverWithCode(corrupted, '246810', setup.keyring, { iterations: 1000 }));
  assert.equal(JSON.stringify(setup.keyring), before);
});

test('PIN unlock guard temporarily blocks repeated failures in the active session', async () => {
  assert.ok(keys, 'key management must be implemented');
  const setup = await keys.initializeKeyring('135790', { iterations: 1000 });
  let now = 1000;
  const guard = keys.createPinUnlockGuard(() => setup.keyring, { maxAttempts: 2, cooldownMs: 500, now: () => now });
  await assert.rejects(guard.unlock('000000'), /Invalid PIN/i);
  await assert.rejects(guard.unlock('000000'), /Invalid PIN/i);
  await assert.rejects(guard.unlock('135790'), /Too many failed/i);
  now += 501;
  assert.ok(await guard.unlock('135790'));
});

test('PIN unlock guard rejects non-finite cooldown and invalid attempt limits', () => {
  assert.ok(keys, 'key management must be implemented');
  const getKeyring = () => ({ version: 1, pin: {}, recovery: {} });
  assert.throws(() => keys.createPinUnlockGuard(getKeyring, { cooldownMs: Number.NaN }), /configuration|настройк/i);
  assert.throws(() => keys.createPinUnlockGuard(getKeyring, { cooldownMs: Number.POSITIVE_INFINITY }), /configuration|настройк/i);
  assert.throws(() => keys.createPinUnlockGuard(getKeyring, { maxAttempts: 0 }), /configuration|настройк/i);
});

test('malformed keyring KDF parameters are rejected before expensive derivation', async () => {
  const setup = await keys.initializeKeyring('135790', { iterations: 1000 });
  const malformed = structuredClone(setup.keyring);
  malformed.pin.iterations = 9_999_999_999;
  await assert.rejects(keys.unlockWithPin('135790', malformed), /parameters|iteration|keyring/i);
  const malformedSalt = structuredClone(setup.keyring);
  malformedSalt.pin.salt = 'AA';
  await assert.rejects(keys.unlockWithPin('135790', malformedSalt), /salt|keyring|base64/i);
});
