import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = (path) => readFile(new URL(path, import.meta.url), 'utf8');

test('web app manifest is configured for an installable standalone app', async () => {
  const manifest = JSON.parse(await read('../public/manifest.webmanifest'));
  assert.equal(manifest.name, 'Менин күнүм — личное пространство');
  assert.equal(manifest.display, 'standalone');
  assert.equal(manifest.start_url, '/');
  assert.ok(manifest.icons.some((icon) => icon.src === '/icons/app-icon.svg'));
});

test('service worker caches only the app shell and same-origin static assets', async () => {
  const worker = await read('../public/sw.js');
  assert.match(worker, /request\.method !== 'GET'/);
  assert.match(worker, /url\.origin !== self\.location\.origin/);
  assert.match(worker, /url\.pathname\.startsWith\('\/assets\/'\)/);
  assert.match(worker, /Never cache IndexedDB records, API responses, or user content/);
  assert.match(worker, /caches\.match\('\/index\.html'\)/);
});

test('service worker registration is progressive and disabled in development', async () => {
  const registration = await read('../src/pwa.ts');
  const entry = await read('../src/main.tsx');
  assert.match(registration, /'serviceWorker' in navigator/);
  assert.match(registration, /import\.meta\.env\.DEV/);
  assert.match(entry, /registerServiceWorker\(\)/);
});

test('primary navigation includes interactive destinations and a selected-page state', async () => {
  const app = await read('../src/app/App.tsx');
  assert.match(app, /onClick=\{\(\) => setScreen\(item\.id\)\}/);
  assert.match(app, /aria-current=\{screen === item\.id \? 'page' : undefined\}/);
  for (const screen of ['home', 'plans', 'notes', 'diary', 'more']) {
    assert.match(app, new RegExp(`id: '${screen}'`));
  }
});
