import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App';
import { registerServiceWorker } from './pwa';
import './styles/global.css';

const root = document.getElementById('root');
if (!root) throw new Error('App root element #root was not found.');

createRoot(root).render(
  <StrictMode>
    <App />
  </StrictMode>,
);

void registerServiceWorker();
