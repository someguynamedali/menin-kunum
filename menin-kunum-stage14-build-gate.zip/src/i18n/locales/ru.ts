const ru = {
  'app.title': 'Менин күнүм',
  'app.tagline': 'Твоё личное пространство',
  'nav.home': 'Главная',
  'nav.plans': 'Планы',
  'nav.notes': 'Заметки',
  'nav.diary': 'Дневник',
  'nav.more': 'Ещё',
  'home.today': 'Сегодня',
  'home.newPlan': 'Новый план',
  'home.thoughts': 'Мысли сегодня',
  'settings.title': 'Настройки',
  'common.save': 'Сохранить',
  'common.cancel': 'Отмена',
  'common.delete': 'Удалить',
  'common.search': 'Поиск',
} as const;
export default ru;
