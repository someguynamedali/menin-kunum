const en = {
  'app.title': 'My Day',
  'app.tagline': 'Your personal space',
  'nav.home': 'Home',
  'nav.plans': 'Plans',
  'nav.notes': 'Notes',
  'nav.diary': 'Diary',
  'nav.more': 'More',
  'home.today': 'Today',
  'home.newPlan': 'New plan',
  'home.thoughts': 'Today’s thoughts',
  'settings.title': 'Settings',
  'common.save': 'Save',
  'common.cancel': 'Cancel',
  'common.delete': 'Delete',
  'common.search': 'Search',
} as const;
export default en;
