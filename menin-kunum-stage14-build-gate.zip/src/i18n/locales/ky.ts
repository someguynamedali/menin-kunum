const ky = {
  'app.title': 'Менин күнүм',
  'app.tagline': 'Сенин жеке мейкиндигиң',
  'nav.home': 'Башкы бет',
  'nav.plans': 'Пландар',
  'nav.notes': 'Белгилер',
  'nav.diary': 'Күндөлүк',
  'nav.more': 'Дагы',
  'home.today': 'Бүгүн',
  'home.newPlan': 'Жаңы план',
  'home.thoughts': 'Бүгүнкү ойлор',
  'settings.title': 'Жөндөөлөр',
  'common.save': 'Сактоо',
  'common.cancel': 'Жокко чыгаруу',
  'common.delete': 'Өчүрүү',
  'common.search': 'Издөө',
} as const;
export default ky;
