import type { Locale } from '../domain/models.ts';
import ru from './locales/ru.ts';
import ky from './locales/ky.ts';
import en from './locales/en.ts';

const dictionaries = { ru, ky, en } as const;
export type TranslationKey = keyof typeof ru;

export function t(locale: Locale, key: string): string {
  const selected = dictionaries[locale] as Record<string, string>;
  const fallback = ru as Record<string, string>;
  return selected[key] ?? fallback[key] ?? key;
}

export function formatDate(date: Date, locale: Locale): string {
  const languageTag: Record<Locale, string> = { ru: 'ru-RU', ky: 'ky-KG', en: 'en-US' };
  return new Intl.DateTimeFormat(languageTag[locale], { day: 'numeric', month: 'long', year: 'numeric' }).format(date);
}

export function formatTime(date: Date, locale: Locale): string {
  const languageTag: Record<Locale, string> = { ru: 'ru-RU', ky: 'ky-KG', en: 'en-US' };
  return new Intl.DateTimeFormat(languageTag[locale], { hour: '2-digit', minute: '2-digit' }).format(date);
}
