export type StorageErrorCode =
  | 'STORAGE_UNAVAILABLE'
  | 'QUOTA_EXCEEDED'
  | 'MIGRATION_FAILED'
  | 'NOT_FOUND'
  | 'DUPLICATE_ID'
  | 'STORAGE_OPERATION_FAILED';

export class StorageError extends Error {
  readonly code: StorageErrorCode;
  readonly cause?: unknown;

  constructor(code: StorageErrorCode, message: string, cause?: unknown) {
    super(message);
    this.name = 'StorageError';
    this.code = code;
    this.cause = cause;
  }
}

export function mapStorageError(error: unknown): StorageError {
  if (error instanceof StorageError) return error;
  const name = error instanceof DOMException ? error.name : '';
  if (name === 'QuotaExceededError') {
    return new StorageError('QUOTA_EXCEEDED', 'Недостаточно места для сохранения данных.', error);
  }
  if (name === 'NotFoundError') {
    return new StorageError('NOT_FOUND', 'Запись не найдена.', error);
  }
  if (name === 'ConstraintError') {
    return new StorageError('DUPLICATE_ID', 'Запись с таким идентификатором уже существует.', error);
  }
  return new StorageError('STORAGE_OPERATION_FAILED', 'Не удалось выполнить операцию с локальным хранилищем.', error);
}
