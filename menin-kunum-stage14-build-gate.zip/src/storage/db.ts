import { StorageError } from './errors.ts';

export const DATABASE_NAME = 'menin-kunum-local';
export const DATABASE_VERSION = 1;

export const STORE_NAMES = [
  'tasks',
  'projects',
  'notes',
  'diaryEntries',
  'habits',
  'habitLogs',
  'attachments',
  'settings',
] as const;

export type StoreName = (typeof STORE_NAMES)[number];

function ensureIndexedDb(): IDBFactory {
  if (typeof indexedDB === 'undefined') {
    throw new StorageError('STORAGE_UNAVAILABLE', 'Это окружение не поддерживает IndexedDB.');
  }
  return indexedDB;
}

/** Opens the versioned local database. User data is never cleared during upgrades. */
export function openAppDatabase(): Promise<IDBDatabase> {
  let factory: IDBFactory;
  try {
    factory = ensureIndexedDb();
  } catch (error) {
    return Promise.reject(error);
  }

  return new Promise((resolve, reject) => {
    const request = factory.open(DATABASE_NAME, DATABASE_VERSION);

    request.onupgradeneeded = () => {
      const database = request.result;
      for (const storeName of STORE_NAMES) {
        if (!database.objectStoreNames.contains(storeName)) {
          database.createObjectStore(storeName, { keyPath: 'id' });
        }
      }
    };

    request.onsuccess = () => {
      const database = request.result;
      database.onversionchange = () => database.close();
      resolve(database);
    };

    request.onerror = () => reject(new StorageError(
      'STORAGE_UNAVAILABLE',
      'Не удалось открыть локальное хранилище.',
      request.error,
    ));

    request.onblocked = () => reject(new StorageError(
      'MIGRATION_FAILED',
      'Обновление хранилища заблокировано другой открытой вкладкой. Закройте другие вкладки приложения и попробуйте снова.',
    ));
  });
}
