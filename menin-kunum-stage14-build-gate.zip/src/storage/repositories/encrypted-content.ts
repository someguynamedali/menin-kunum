import { decryptPayload, encryptPayload, type EncryptedPayload } from '../../security/crypto.ts';
import type { IdentifiedRecord, RecordRepository, RecordStore } from './base.ts';

export interface EncryptedStoredRecord extends IdentifiedRecord {
  encryptedContent: EncryptedPayload;
  [field: string]: unknown;
}

export interface EncryptedContentRepositoryOptions<T extends IdentifiedRecord> {
  storeName: string;
  publicFields: readonly (keyof T)[];
  encryptedFields: readonly (keyof T)[];
}

/**
 * Stores only explicitly allow-listed metadata in plaintext. All remaining
 * protected fields are serialized together and authenticated with store/id AAD.
 */
export function createEncryptedContentRepository<T extends IdentifiedRecord>(
  store: RecordStore<EncryptedStoredRecord>,
  getDataKey: () => CryptoKey,
  options: EncryptedContentRepositoryOptions<T>,
): RecordRepository<T> {
  const { storeName, publicFields, encryptedFields } = options;
  if (!storeName || !publicFields.length || !encryptedFields.length) throw new Error('Encrypted repository configuration is incomplete');
  const publicSet = new Set<string>(publicFields.map(String));
  for (const field of encryptedFields) {
    if (publicSet.has(String(field)) || field === 'id') throw new Error(`Field ${String(field)} cannot be both public and encrypted`);
  }
  const aadFor = (id: string) => `menin-kunum:record:v1:${storeName}:${id}`;

  async function encode(record: T): Promise<EncryptedStoredRecord> {
    if (!record.id || typeof record.id !== 'string') throw new Error('Encrypted record requires an ID');
    const publicRecord: Record<string, unknown> = { id: record.id };
    for (const field of publicFields) {
      const value = record[field];
      if (value !== undefined) publicRecord[String(field)] = value;
    }
    const privateRecord: Record<string, unknown> = {};
    for (const [field, value] of Object.entries(record)) {
      if (field !== 'id' && !publicSet.has(field) && value !== undefined) privateRecord[field] = value;
    }
    const encryptedContent = await encryptPayload(JSON.stringify(privateRecord), getDataKey(), aadFor(record.id));
    return { ...publicRecord, encryptedContent } as EncryptedStoredRecord;
  }

  async function decode(record: EncryptedStoredRecord): Promise<T> {
    if (!record || typeof record.id !== 'string' || !record.encryptedContent) throw new Error('Malformed encrypted record');
    const plaintext = await decryptPayload(record.encryptedContent, getDataKey(), aadFor(record.id));
    const privateRecord = JSON.parse(plaintext) as Record<string, unknown>;
    const publicRecord: Record<string, unknown> = { id: record.id };
    for (const field of publicFields) {
      if (record[String(field)] !== undefined) publicRecord[String(field)] = record[String(field)];
    }
    for (const [field, value] of Object.entries(privateRecord)) {
      if (field !== 'id' && !publicSet.has(field) && value !== undefined) publicRecord[field] = value;
    }
    return publicRecord as T;
  }

  return {
    async create(record) {
      await store.add(await encode(record));
      return record;
    },
    async getById(id) {
      const record = await store.get(id);
      return record ? decode(record) : undefined;
    },
    async list() {
      const records = await store.getAll();
      return Promise.all(records.map(decode));
    },
    async update(record) {
      const existing = await store.get(record.id);
      if (!existing) throw new Error('Cannot update missing encrypted record');
      await store.put(await encode(record));
      return record;
    },
    async delete(id) {
      const existing = await store.get(id);
      if (!existing) throw new Error('Cannot delete missing encrypted record');
      await store.delete(id);
    },
  };
}
