import type { HabitLog } from '../../domain/models.ts';
import type { RecordRepository } from './base.ts';
import { createRepository } from './base.ts';
import { createIndexedDbStore } from './indexed-db-store.ts';

export function createHabitLogsRepository(database: IDBDatabase): RecordRepository<HabitLog> {
  return createRepository(createIndexedDbStore<HabitLog>(database, 'habitLogs'));
}
