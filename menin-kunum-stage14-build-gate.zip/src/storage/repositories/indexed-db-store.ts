import type { IdentifiedRecord, RecordStore } from './base.ts';
import type { StoreName } from '../db.ts';
import { mapStorageError } from '../errors.ts';

export function createIndexedDbStore<T extends IdentifiedRecord>(database: IDBDatabase, storeName: StoreName): RecordStore<T> {
  function requestResult<R>(request: IDBRequest<R>): Promise<R> {
    return new Promise((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(mapStorageError(request.error));
    });
  }

  function runWrite(action: (store: IDBObjectStore) => IDBRequest): Promise<void> {
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(storeName, 'readwrite');
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(mapStorageError(transaction.error));
      transaction.onabort = () => reject(mapStorageError(transaction.error));
      try {
        action(transaction.objectStore(storeName));
      } catch (error) {
        transaction.abort();
        reject(mapStorageError(error));
      }
    });
  }

  return {
    async add(record) {
      await runWrite((store) => store.add(record));
    },
    async get(id) {
      const transaction = database.transaction(storeName, 'readonly');
      return requestResult(transaction.objectStore(storeName).get(id)) as Promise<T | undefined>;
    },
    async getAll() {
      const transaction = database.transaction(storeName, 'readonly');
      return requestResult(transaction.objectStore(storeName).getAll()) as Promise<T[]>;
    },
    async put(record) {
      await runWrite((store) => store.put(record));
    },
    async delete(id) {
      await runWrite((store) => store.delete(id));
    },
  };
}
