import type { Project } from '../../domain/models.ts';
import type { RecordRepository } from './base.ts';
import { createRepository } from './base.ts';
import { createIndexedDbStore } from './indexed-db-store.ts';

export function createProjectsRepository(database: IDBDatabase): RecordRepository<Project> {
  return createRepository(createIndexedDbStore<Project>(database, 'projects'));
}
