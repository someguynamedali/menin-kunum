import type { Note } from '../../domain/models.ts';
import type { RecordRepository } from './base.ts';
import { createRepository } from './base.ts';
import { createIndexedDbStore } from './indexed-db-store.ts';
import { createEncryptedContentRepository } from './encrypted-content.ts';

export function createNotesRepository(database: IDBDatabase): RecordRepository<Note> {
  return createRepository(createIndexedDbStore<Note>(database, 'notes'));
}

export function createEncryptedNotesRepository(database: IDBDatabase, getDataKey: () => CryptoKey): RecordRepository<Note> {
  return createEncryptedContentRepository(
    createIndexedDbStore(database, 'notes'),
    getDataKey,
    { storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'] },
  );
}
