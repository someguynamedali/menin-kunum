import { mapStorageError, StorageError } from '../errors.ts';

export interface IdentifiedRecord {
  id: string;
}

export interface RecordRepository<T extends IdentifiedRecord> {
  create(record: T): Promise<T>;
  getById(id: string): Promise<T | undefined>;
  list(): Promise<T[]>;
  update(record: T): Promise<T>;
  delete(id: string): Promise<void>;
}

/** A narrow storage boundary makes repositories testable without a real browser database. */
export interface RecordStore<T extends IdentifiedRecord> {
  add(record: T): Promise<void>;
  get(id: string): Promise<T | undefined>;
  getAll(): Promise<T[]>;
  put(record: T): Promise<void>;
  delete(id: string): Promise<void>;
}

export function createRepository<T extends IdentifiedRecord>(store: RecordStore<T>): RecordRepository<T> {
  return {
    async create(record) {
      if (!record.id.trim()) throw new StorageError('STORAGE_OPERATION_FAILED', 'У записи должен быть идентификатор.');
      try {
        await store.add(record);
        return record;
      } catch (error) {
        throw mapStorageError(error);
      }
    },
    async getById(id) {
      try {
        return await store.get(id);
      } catch (error) {
        throw mapStorageError(error);
      }
    },
    async list() {
      try {
        return await store.getAll();
      } catch (error) {
        throw mapStorageError(error);
      }
    },
    async update(record) {
      const existing = await this.getById(record.id);
      if (!existing) throw new StorageError('NOT_FOUND', 'Нельзя обновить несуществующую запись.');
      try {
        await store.put(record);
        return record;
      } catch (error) {
        throw mapStorageError(error);
      }
    },
    async delete(id) {
      const existing = await this.getById(id);
      if (!existing) throw new StorageError('NOT_FOUND', 'Нельзя удалить несуществующую запись.');
      try {
        await store.delete(id);
      } catch (error) {
        throw mapStorageError(error);
      }
    },
  };
}
