import type { DiaryEntry } from '../../domain/models.ts';
import type { RecordRepository } from './base.ts';
import { createRepository } from './base.ts';
import { createIndexedDbStore } from './indexed-db-store.ts';
import { createEncryptedContentRepository } from './encrypted-content.ts';

export function createDiaryRepository(database: IDBDatabase): RecordRepository<DiaryEntry> {
  return createRepository(createIndexedDbStore<DiaryEntry>(database, 'diaryEntries'));
}

export function createEncryptedDiaryRepository(database: IDBDatabase, getDataKey: () => CryptoKey): RecordRepository<DiaryEntry> {
  return createEncryptedContentRepository(
    createIndexedDbStore(database, 'diaryEntries'),
    getDataKey,
    {
      storeName: 'diaryEntries',
      publicFields: ['date', 'title', 'tags', 'createdAt', 'updatedAt'],
      encryptedFields: ['body', 'mood', 'goodThings', 'concerns', 'gratitude', 'attachmentIds'],
    },
  );
}
