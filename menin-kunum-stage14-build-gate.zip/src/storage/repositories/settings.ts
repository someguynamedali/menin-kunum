import type { AppSettings } from '../../domain/models.ts';
import type { RecordRepository } from './base.ts';
import { createRepository } from './base.ts';
import { createIndexedDbStore } from './indexed-db-store.ts';

export interface StoredSettings extends AppSettings { id: 'app-settings'; }

export function createSettingsRepository(database: IDBDatabase): RecordRepository<StoredSettings> {
  return createRepository(createIndexedDbStore<StoredSettings>(database, 'settings'));
}
