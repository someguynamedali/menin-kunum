import type { Task } from '../../domain/models.ts';
import type { RecordRepository } from './base.ts';
import { createRepository } from './base.ts';
import { createIndexedDbStore } from './indexed-db-store.ts';
import type { StoreName } from '../db.ts';

export function createTasksRepository(database: IDBDatabase): RecordRepository<Task> {
  return createRepository(createIndexedDbStore<Task>(database, 'tasks' satisfies StoreName));
}
