import {
  decodeBase64Url,
  encodeBase64Url,
  encryptPayload,
  decryptPayload,
  generateRawDataKey,
  importDataKey,
  randomBytes,
  type EncryptedPayload,
} from './crypto.ts';

const KEYRING_VERSION = 1 as const;
const DEFAULT_PIN_ITERATIONS = 600_000;
const MAX_PIN_ITERATIONS = 2_000_000;
const MIN_SALT_BYTES = 16;
const MAX_SALT_BYTES = 64;
const MIN_PIN_LENGTH = 6;
const RECOVERY_SECRET_BYTES = 16;
const PIN_WRAP_AAD = 'menin-kunum:key-wrap:v1:pin';
const RECOVERY_WRAP_AAD = 'menin-kunum:key-wrap:v1:recovery';
const RECOVERY_HKDF_INFO = new TextEncoder().encode('menin-kunum recovery key v1');

export interface KeyWrapper {
  salt: string;
  wrappedDataKey: EncryptedPayload;
  iterations?: number;
}

export interface Keyring {
  version: typeof KEYRING_VERSION;
  pin: KeyWrapper;
  recovery: KeyWrapper;
}

export interface KeyManagementOptions {
  /** Override only for tests/benchmarks; production default is 600,000. */
  iterations?: number;
}

function cryptoApi(): Crypto {
  if (!globalThis.crypto?.subtle) throw new Error('Web Crypto is unavailable in this environment');
  return globalThis.crypto;
}

function validatePin(pin: string): void {
  if (typeof pin !== 'string' || pin.length < MIN_PIN_LENGTH || pin.length > 128) {
    throw new Error(`PIN must contain at least ${MIN_PIN_LENGTH} characters`);
  }
}

async function derivePinKey(pin: string, salt: Uint8Array, iterations: number): Promise<CryptoKey> {
  validatePin(pin);
  if (!Number.isSafeInteger(iterations) || iterations < 1000 || iterations > MAX_PIN_ITERATIONS) throw new Error('Invalid PIN derivation parameters');
  const pinBytes = new TextEncoder().encode(pin);
  try {
    const material = await cryptoApi().subtle.importKey('raw', pinBytes, 'PBKDF2', false, ['deriveKey']);
    return await cryptoApi().subtle.deriveKey(
      { name: 'PBKDF2', hash: 'SHA-256', salt, iterations },
      material,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt'],
    );
  } finally { pinBytes.fill(0); }
}

async function deriveRecoveryKey(secret: Uint8Array, salt: Uint8Array): Promise<CryptoKey> {
  const material = await cryptoApi().subtle.importKey('raw', secret, 'HKDF', false, ['deriveKey']);
  return cryptoApi().subtle.deriveKey(
    { name: 'HKDF', hash: 'SHA-256', salt, info: RECOVERY_HKDF_INFO },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt'],
  );
}

async function makeRecoveryCode(): Promise<{ code: string; secret: Uint8Array }> {
  const secret = randomBytes(RECOVERY_SECRET_BYTES);
  const digest = new Uint8Array(await cryptoApi().subtle.digest('SHA-256', secret));
  const raw = `${toHex(secret)}${toHex(digest.slice(0, 2))}`;
  const code = raw.match(/.{1,4}/g)!.join('-');
  return { code, secret };
}

function toHex(bytes: Uint8Array): string {
  return [...bytes].map((byte) => byte.toString(16).padStart(2, '0')).join('').toUpperCase();
}

function parseRecoveryCode(code: string): { secret: Uint8Array; checksum: string } {
  const normalized = code.replace(/[\s-]/g, '').toUpperCase();
  if (!/^[0-9A-F]{36}$/.test(normalized)) throw new Error('Invalid recovery code');
  const secret = new Uint8Array(RECOVERY_SECRET_BYTES);
  for (let i = 0; i < RECOVERY_SECRET_BYTES; i += 1) secret[i] = Number.parseInt(normalized.slice(i * 2, i * 2 + 2), 16);
  return { secret, checksum: normalized.slice(32) };
}

async function verifyRecoveryCode(code: string): Promise<Uint8Array> {
  const { secret, checksum } = parseRecoveryCode(code);
  const digest = new Uint8Array(await cryptoApi().subtle.digest('SHA-256', secret));
  if (checksum !== toHex(digest.slice(0, 2))) {
    secret.fill(0);
    throw new Error('Invalid recovery code');
  }
  return secret;
}

async function wrapRawDataKey(rawDataKey: Uint8Array, wrappingKey: CryptoKey, aad: string): Promise<EncryptedPayload> {
  return encryptPayload(encodeBase64Url(rawDataKey), wrappingKey, aad);
}

async function unwrapRawDataKey(wrapper: KeyWrapper, wrappingKey: CryptoKey, aad: string): Promise<Uint8Array> {
  const encoded = await decryptPayload(wrapper.wrappedDataKey, wrappingKey, aad);
  const raw = decodeBase64Url(encoded);
  if (raw.byteLength !== 32) {
    raw.fill(0);
    throw new Error('Invalid wrapped data key');
  }
  return raw;
}

export async function initializeKeyring(pin: string, options: KeyManagementOptions = {}): Promise<{ keyring: Keyring; recoveryCode: string; dataKey: CryptoKey }> {
  validatePin(pin);
  const iterations = options.iterations ?? DEFAULT_PIN_ITERATIONS;
  validateIterations(iterations);
  const rawDataKey = await generateRawDataKey();
  const recovery = await makeRecoveryCode();
  const pinSalt = randomBytes(16);
  const recoverySalt = randomBytes(16);
  try {
    const pinKey = await derivePinKey(pin, pinSalt, iterations);
    const recoveryKey = await deriveRecoveryKey(recovery.secret, recoverySalt);
    const [pinWrapped, recoveryWrapped] = await Promise.all([
      wrapRawDataKey(rawDataKey, pinKey, PIN_WRAP_AAD),
      wrapRawDataKey(rawDataKey, recoveryKey, RECOVERY_WRAP_AAD),
    ]);
    // Verify both wrappers before returning a completed setup.
    const [pinCheck, recoveryCheck] = await Promise.all([
      unwrapRawDataKey({ salt: '', iterations, wrappedDataKey: pinWrapped }, pinKey, PIN_WRAP_AAD),
      unwrapRawDataKey({ salt: '', wrappedDataKey: recoveryWrapped }, recoveryKey, RECOVERY_WRAP_AAD),
    ]);
    try {
      if (!constantTimeEqual(rawDataKey, pinCheck) || !constantTimeEqual(rawDataKey, recoveryCheck)) {
        throw new Error('Keyring self-check failed');
      }
    } finally {
      pinCheck.fill(0);
      recoveryCheck.fill(0);
    }
    const dataKey = await importDataKey(rawDataKey);
    return {
      keyring: {
        version: KEYRING_VERSION,
        pin: { salt: encodeBase64Url(pinSalt), iterations, wrappedDataKey: pinWrapped },
        recovery: { salt: encodeBase64Url(recoverySalt), wrappedDataKey: recoveryWrapped },
      },
      recoveryCode: recovery.code,
      dataKey,
    };
  } finally {
    rawDataKey.fill(0);
    recovery.secret.fill(0);
    pinSalt.fill(0);
    recoverySalt.fill(0);
  }
}

function constantTimeEqual(a: Uint8Array, b: Uint8Array): boolean {
  if (a.length !== b.length) return false;
  let difference = 0;
  for (let index = 0; index < a.length; index += 1) difference |= a[index]! ^ b[index]!;
  return difference === 0;
}

function validateSalt(value: unknown, label: string): Uint8Array {
  if (typeof value !== 'string') throw new Error(`Invalid ${label} salt`);
  let salt: Uint8Array;
  try { salt = decodeBase64Url(value); } catch { throw new Error(`Invalid ${label} salt`); }
  if (salt.byteLength < MIN_SALT_BYTES || salt.byteLength > MAX_SALT_BYTES) { salt.fill(0); throw new Error(`Invalid ${label} salt length`); }
  return salt;
}

function validateIterations(iterations: number): void {
  if (!Number.isSafeInteger(iterations) || iterations < 1000 || iterations > MAX_PIN_ITERATIONS) throw new Error('Invalid PIN derivation parameters');
}

function validateWrapper(wrapper: KeyWrapper, label: string, allowIterations: boolean): void {
  if (!wrapper || typeof wrapper !== 'object' || !wrapper.wrappedDataKey) throw new Error(`Invalid ${label} key wrapper`);
  const salt = validateSalt(wrapper.salt, label);
  salt.fill(0);
  if (allowIterations) validateIterations(wrapper.iterations ?? DEFAULT_PIN_ITERATIONS);
  const payload = wrapper.wrappedDataKey;
  if (payload.formatVersion !== 1 || payload.algorithm !== 'AES-256-GCM' || typeof payload.nonce !== 'string' || typeof payload.ciphertext !== 'string') throw new Error(`Invalid ${label} wrapped key payload`);
}

function validateKeyring(keyring: Keyring): void {
  if (!keyring || keyring.version !== KEYRING_VERSION || !keyring.pin || !keyring.recovery) throw new Error('Unsupported keyring version or structure');
  validateWrapper(keyring.pin, 'PIN', true);
  validateWrapper(keyring.recovery, 'recovery', false);
}

export async function unlockWithPin(pin: string, keyring: Keyring): Promise<CryptoKey> {
  validateKeyring(keyring);
  const salt = validateSalt(keyring.pin.salt, 'PIN');
  const iterations = keyring.pin.iterations ?? DEFAULT_PIN_ITERATIONS;
  let raw: Uint8Array | undefined;
  try {
    const wrappingKey = await derivePinKey(pin, salt, iterations);
    raw = await unwrapRawDataKey(keyring.pin, wrappingKey, PIN_WRAP_AAD);
    return await importDataKey(raw);
  } finally {
    raw?.fill(0);
    salt.fill(0);
  }
}

export async function changePin(oldPin: string, newPin: string, keyring: Keyring, options: KeyManagementOptions = {}): Promise<Keyring> {
  validateKeyring(keyring);
  validatePin(newPin);
  const iterations = options.iterations ?? DEFAULT_PIN_ITERATIONS;
  validateIterations(iterations);
  const oldSalt = validateSalt(keyring.pin.salt, 'PIN');
  const salt = randomBytes(16);
  let rawDataKey: Uint8Array | undefined;
  try {
    const oldWrappingKey = await derivePinKey(oldPin, oldSalt, keyring.pin.iterations ?? DEFAULT_PIN_ITERATIONS);
    rawDataKey = await unwrapRawDataKey(keyring.pin, oldWrappingKey, PIN_WRAP_AAD);
    const newWrappingKey = await derivePinKey(newPin, salt, iterations);
    const wrappedDataKey = await wrapRawDataKey(rawDataKey, newWrappingKey, PIN_WRAP_AAD);
    const check = await unwrapRawDataKey({ salt: '', iterations, wrappedDataKey }, newWrappingKey, PIN_WRAP_AAD);
    try {
      if (!constantTimeEqual(rawDataKey, check)) throw new Error('PIN wrapper self-check failed');
    } finally { check.fill(0); }
    return { ...keyring, pin: { salt: encodeBase64Url(salt), iterations, wrappedDataKey } };
  } finally {
    rawDataKey?.fill(0);
    oldSalt.fill(0);
    salt.fill(0);
  }
}

export async function recoverWithCode(code: string, newPin: string, keyring: Keyring, options: KeyManagementOptions = {}): Promise<{ keyring: Keyring; dataKey: CryptoKey }> {
  validateKeyring(keyring);
  validatePin(newPin);
  const secret = await verifyRecoveryCode(code);
  const salt = validateSalt(keyring.recovery.salt, 'recovery');
  let rawDataKey: Uint8Array | undefined;
  try {
    const recoveryKey = await deriveRecoveryKey(secret, salt);
    rawDataKey = await unwrapRawDataKey(keyring.recovery, recoveryKey, RECOVERY_WRAP_AAD);
    const newPinSalt = randomBytes(16);
    const iterations = options.iterations ?? DEFAULT_PIN_ITERATIONS;
    validateIterations(iterations);
    try {
      const newPinKey = await derivePinKey(newPin, newPinSalt, iterations);
      const wrappedDataKey = await wrapRawDataKey(rawDataKey, newPinKey, PIN_WRAP_AAD);
      const check = await unwrapRawDataKey({ salt: '', iterations, wrappedDataKey }, newPinKey, PIN_WRAP_AAD);
      try {
        if (!constantTimeEqual(rawDataKey, check)) throw new Error('PIN wrapper self-check failed');
      } finally {
        check.fill(0);
      }
      return {
        keyring: { ...keyring, pin: { salt: encodeBase64Url(newPinSalt), iterations, wrappedDataKey } },
        dataKey: await importDataKey(rawDataKey),
      };
    } finally {
      newPinSalt.fill(0);
    }
  } finally {
    secret.fill(0);
    salt.fill(0);
    rawDataKey?.fill(0);
  }
}

export interface PinUnlockGuardOptions {
  maxAttempts?: number;
  cooldownMs?: number;
  now?: () => number;
}

/** Session-local throttling only; it is not protection against offline PIN guessing. */
export function createPinUnlockGuard(getKeyring: () => Keyring, options: PinUnlockGuardOptions = {}) {
  const maxAttempts = options.maxAttempts ?? 5;
  const cooldownMs = options.cooldownMs ?? 1_000;
  const now = options.now ?? Date.now;
  if (!Number.isSafeInteger(maxAttempts) || maxAttempts < 1 || !Number.isFinite(cooldownMs) || cooldownMs < 0) throw new Error('Invalid PIN guard configuration');
  let failures = 0;
  let lockedUntil = 0;

  return {
    async unlock(pin: string): Promise<CryptoKey> {
      if (now() < lockedUntil) throw new Error('Too many failed PIN attempts. Try again later.');
      try {
        const key = await unlockWithPin(pin, getKeyring());
        failures = 0;
        lockedUntil = 0;
        return key;
      } catch {
        failures += 1;
        if (failures >= maxAttempts) {
          lockedUntil = now() + cooldownMs;
          failures = 0;
        }
        throw new Error('Invalid PIN or corrupted keyring');
      }
    },
    reset(): void {
      failures = 0;
      lockedUntil = 0;
    },
  };
}
