export interface SecuritySessionOptions {
  onLock?: () => void;
}

/** In-memory session only. This intentionally has no inactivity timer. */
export function createSecuritySession(options: SecuritySessionOptions = {}) {
  let dataKey: CryptoKey | null = null;

  return {
    isUnlocked(): boolean {
      return dataKey !== null;
    },
    unlock(key: CryptoKey): void {
      if (!key || typeof key !== 'object') throw new Error('A valid data key is required');
      dataKey = key;
    },
    getDataKey(): CryptoKey {
      if (!dataKey) throw new Error('Security session is locked');
      return dataKey;
    },
    lockSession(): void {
      dataKey = null;
      options.onLock?.();
    },
  };
}
