import type { Keyring } from './key-management.ts';
import { decodeBase64Url, ENCRYPTED_PAYLOAD_VERSION, ENCRYPTION_ALGORITHM } from './crypto.ts';
import type { IdentifiedRecord, RecordStore } from '../storage/repositories/base.ts';

export const SECURITY_KEYRING_ID = 'security-keyring' as const;

export interface SecurityKeyringRecord extends IdentifiedRecord {
  id: typeof SECURITY_KEYRING_ID;
  keyring: Keyring;
  schemaVersion: 1;
  createdAt: string;
  updatedAt: string;
}

function isEncodedBytes(value: unknown, minBytes: number, maxBytes: number): boolean {
  if (typeof value !== 'string' || !/^[A-Za-z0-9_-]+$/.test(value)) return false;
  try {
    const bytes = decodeBase64Url(value);
    const valid = bytes.byteLength >= minBytes && bytes.byteLength <= maxBytes;
    bytes.fill(0);
    return valid;
  } catch {
    return false;
  }
}

function isWrapper(value: unknown): boolean {
  if (!value || typeof value !== 'object') return false;
  const wrapper = value as Record<string, unknown>;
  if (!isEncodedBytes(wrapper.salt, 16, 64)) return false;
  if (wrapper.iterations !== undefined
    && (!Number.isSafeInteger(wrapper.iterations) || (wrapper.iterations as number) < 1_000 || (wrapper.iterations as number) > 2_000_000)) return false;
  const payload = wrapper.wrappedDataKey;
  if (!payload || typeof payload !== 'object') return false;
  const encrypted = payload as Record<string, unknown>;
  return encrypted.formatVersion === ENCRYPTED_PAYLOAD_VERSION
    && encrypted.algorithm === ENCRYPTION_ALGORITHM
    && isEncodedBytes(encrypted.nonce, 12, 12)
    && isEncodedBytes(encrypted.ciphertext, 16, 1_000);
}

function isKeyring(value: unknown): value is Keyring {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Partial<Keyring>;
  return candidate.version === 1
    && isWrapper(candidate.pin)
    && isWrapper(candidate.recovery);
}

export async function loadKeyring(store: RecordStore<SecurityKeyringRecord>): Promise<Keyring | undefined> {
  const record = await store.get(SECURITY_KEYRING_ID);
  if (!record) return undefined;
  if (record.id !== SECURITY_KEYRING_ID || record.schemaVersion !== 1 || !isKeyring(record.keyring)) {
    throw new Error('Локальная настройка защиты повреждена или имеет неподдерживаемый формат. Не удаляй данные; сначала создай резервную копию хранилища.');
  }
  return record.keyring;
}

/** Creates the keyring once. It intentionally refuses to overwrite an existing key. */
export async function saveKeyring(
  store: RecordStore<SecurityKeyringRecord>,
  keyring: Keyring,
  now: () => Date = () => new Date(),
): Promise<SecurityKeyringRecord> {
  if (!isKeyring(keyring)) throw new Error('Невозможно сохранить некорректный ключ защиты.');
  const existing = await store.get(SECURITY_KEYRING_ID);
  if (existing) throw new Error('Настройка защиты уже существует; перезапись ключа запрещена.');
  const timestamp = now().toISOString();
  const record: SecurityKeyringRecord = {
    id: SECURITY_KEYRING_ID,
    keyring,
    schemaVersion: 1,
    createdAt: timestamp,
    updatedAt: timestamp,
  };
  await store.add(record);
  return record;
}

export async function updateKeyring(
  store: RecordStore<SecurityKeyringRecord>,
  keyring: Keyring,
  now: () => Date = () => new Date(),
): Promise<SecurityKeyringRecord> {
  if (!isKeyring(keyring)) throw new Error('Невозможно сохранить некорректный ключ защиты.');
  const existing = await store.get(SECURITY_KEYRING_ID);
  if (!existing) throw new Error('Настройка защиты не найдена.');
  const record: SecurityKeyringRecord = {
    ...existing,
    keyring,
    schemaVersion: 1,
    updatedAt: now().toISOString(),
  };
  await store.put(record);
  return record;
}
