import { decryptPayload, encryptPayload, type EncryptedPayload } from './crypto.ts';
import type { IdentifiedRecord, RecordStore } from '../storage/repositories/base.ts';
import { createIndexedDbStore } from '../storage/repositories/indexed-db-store.ts';
import type { StoreName } from '../storage/db.ts';

export type LegacyContentRecord = IdentifiedRecord & Record<string, unknown>;
export interface ContentMigrationOptions {
  storeName: 'notes' | 'diaryEntries';
  publicFields: readonly string[];
  encryptedFields: readonly string[];
}
export interface ContentMigrationChange {
  storeName: ContentMigrationOptions['storeName'];
  before: LegacyContentRecord[];
  after: LegacyContentRecord[];
  recordsToWrite: LegacyContentRecord[];
  changed: boolean;
  migrated: number;
  alreadyEncrypted: number;
}
export interface ContentMigrationAdapter {
  readAll(storeName: ContentMigrationOptions['storeName']): Promise<LegacyContentRecord[]>;
  /** Must compare snapshots and apply every changed store in one atomic transaction. */
  commitAtomically(changes: readonly ContentMigrationChange[]): Promise<void>;
}

export async function assertKeyringPresentForEncryptedRecords(
  keyring: unknown,
  stores: readonly RecordStore<LegacyContentRecord>[],
): Promise<void> {
  if (keyring) return;
  for (const store of stores) {
    const records = await store.getAll();
    if (records.some((record) => Object.hasOwn(record, 'encryptedContent'))) {
      throw new Error('Encrypted records exist but the keyring is missing. Do not initialize a new key; restore the original keyring or an encrypted backup.');
    }
  }
}

function stableValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(stableValue);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.keys(value as Record<string, unknown>).sort().map((key) => [key, stableValue((value as Record<string, unknown>)[key])]));
  }
  return value;
}

function sameRecords(a: readonly LegacyContentRecord[], b: readonly LegacyContentRecord[]): boolean {
  if (a.length !== b.length) return false;
  const left = [...a].sort((x, y) => x.id.localeCompare(y.id));
  const right = [...b].sort((x, y) => x.id.localeCompare(y.id));
  return left.every((record, index) => JSON.stringify(stableValue(record)) === JSON.stringify(stableValue(right[index])));
}

async function prepareStore(
  records: readonly LegacyContentRecord[],
  dataKey: CryptoKey,
  options: ContentMigrationOptions,
): Promise<ContentMigrationChange> {
  if (!options.storeName || options.publicFields.length === 0 || options.encryptedFields.length === 0) {
    throw new Error('Параметры миграции защищённых данных неполные.');
  }
  const publicFields = new Set(options.publicFields);
  const encryptedFields = new Set(options.encryptedFields);
  if (publicFields.has('id') || [...encryptedFields].some((field) => publicFields.has(field) || field === 'id')) {
    throw new Error('Поля миграции противоречат правилам защиты.');
  }
  let migrated = 0;
  let alreadyEncrypted = 0;
  const after: LegacyContentRecord[] = [];
  const recordsToWrite: LegacyContentRecord[] = [];
  for (const record of records) {
    const existingEncrypted = record.encryptedContent as EncryptedPayload | undefined;
    if (existingEncrypted) {
      if ([...encryptedFields].some((field) => Object.hasOwn(record, field))) {
        throw new Error(`Запись ${record.id} содержит одновременно шифротекст и открытые личные поля. Миграция остановлена.`);
      }
      const plaintext = await decryptPayload(existingEncrypted, dataKey, `menin-kunum:record:v1:${options.storeName}:${record.id}`);
      const parsed: unknown = JSON.parse(plaintext);
      if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
        throw new Error(`Зашифрованная запись ${record.id} имеет некорректный формат.`);
      }
      const privateRecord = parsed as Record<string, unknown>;
      const allowedKeys = new Set(['id', 'encryptedContent', ...publicFields]);
      const extraPrivateFields = Object.keys(record).filter((field) => !allowedKeys.has(field));
      if (extraPrivateFields.length > 0) {
        const mergedPrivate = { ...privateRecord };
        for (const field of extraPrivateFields) {
          if (Object.hasOwn(mergedPrivate, field)) {
            throw new Error(`Запись ${record.id} содержит конфликтующее поле ${field}; миграция остановлена без изменения данных.`);
          }
          mergedPrivate[field] = record[field];
        }
        const encryptedContent = await encryptPayload(JSON.stringify(mergedPrivate), dataKey, `menin-kunum:record:v1:${options.storeName}:${record.id}`);
        const sanitized: LegacyContentRecord = { id: record.id, encryptedContent };
        for (const field of publicFields) if (Object.hasOwn(record, field)) sanitized[field] = record[field];
        after.push(sanitized); recordsToWrite.push(sanitized); migrated += 1;
      } else {
        after.push(record); alreadyEncrypted += 1;
      }
      continue;
    }

    const publicRecord: LegacyContentRecord = { id: record.id };
    const privateRecord: Record<string, unknown> = {};
    for (const field of publicFields) if (Object.hasOwn(record, field)) publicRecord[field] = record[field];
    for (const [field, value] of Object.entries(record)) {
      if (field !== 'id' && !publicFields.has(field)) privateRecord[field] = value;
    }
    const encryptedContent = await encryptPayload(JSON.stringify(privateRecord), dataKey, `menin-kunum:record:v1:${options.storeName}:${record.id}`);
    const encryptedRecord = { ...publicRecord, encryptedContent };
    after.push(encryptedRecord); recordsToWrite.push(encryptedRecord); migrated += 1;
  }
  return { storeName: options.storeName, before: [...records], after, recordsToWrite, changed: migrated > 0, migrated, alreadyEncrypted };
}


export async function prepareContentRecordsForEncryption(
  records: readonly LegacyContentRecord[],
  dataKey: CryptoKey,
  options: ContentMigrationOptions,
): Promise<LegacyContentRecord[]> {
  const prepared = await prepareStore(records, dataKey, options);
  return prepared.after;
}

/**
 * Stages and verifies every note and diary record in memory first, then commits
 * all changed records in one IndexedDB transaction. Interrupted migrations are
 * all-or-nothing; a concurrent tab change aborts rather than overwriting data.
 */
export async function migrateLegacyContentStoresAtomically(
  adapter: ContentMigrationAdapter,
  dataKey: CryptoKey,
): Promise<{ notes: ContentMigrationChange; diaryEntries: ContentMigrationChange }> {
  const [notesBefore, diaryBefore] = await Promise.all([adapter.readAll('notes'), adapter.readAll('diaryEntries')]);
  const [notes, diaryEntries] = await Promise.all([
    prepareStore(notesBefore, dataKey, { storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'] }),
    prepareStore(diaryBefore, dataKey, { storeName: 'diaryEntries', publicFields: ['date', 'title', 'tags', 'createdAt', 'updatedAt'], encryptedFields: ['body', 'mood', 'goodThings', 'concerns', 'gratitude', 'attachmentIds'] }),
  ]);
  if (notes.changed || diaryEntries.changed) await adapter.commitAtomically([notes, diaryEntries]);
  return { notes, diaryEntries };
}

export function createIndexedDbMigrationAdapter(database: IDBDatabase): ContentMigrationAdapter {
  return {
    async readAll(storeName) {
      return createIndexedDbStore<LegacyContentRecord>(database, storeName as StoreName).getAll();
    },
    async commitAtomically(changes) {
      await new Promise<void>((resolve, reject) => {
        const storeNames = [...new Set(changes.map((change) => change.storeName))];
        let transaction: IDBTransaction;
        try { transaction = database.transaction(storeNames, 'readwrite'); }
        catch (error) { reject(error); return; }
        let failure: Error | undefined;
        let completedReads = 0;
        let settled = false;
        const fail = (error: Error) => {
          if (settled) return;
          failure = error;
          try { transaction.abort(); } catch { settled = true; reject(error); }
        };
        transaction.oncomplete = () => { if (!settled) { settled = true; resolve(); } };
        transaction.onerror = () => { if (!settled) { settled = true; reject(failure ?? transaction.error ?? new Error('IndexedDB migration transaction failed.')); } };
        transaction.onabort = () => { if (!settled) { settled = true; reject(failure ?? transaction.error ?? new Error('IndexedDB migration transaction aborted.')); } };
        for (const change of changes) {
          const store = transaction.objectStore(change.storeName);
          const request = store.getAll();
          request.onerror = () => fail(request.error ?? new Error('Could not verify records before migration.'));
          request.onsuccess = () => {
            if (settled || failure) return;
            if (!sameRecords(change.before, request.result as LegacyContentRecord[])) {
              fail(new Error('A record changed in another tab during migration. No migrated records were committed; retry after closing other app tabs.'));
              return;
            }
            completedReads += 1;
            if (completedReads !== changes.length) return;
            try {
              for (const prepared of changes) {
                if (!prepared.changed) continue;
                const target = transaction.objectStore(prepared.storeName);
                for (const record of prepared.recordsToWrite) target.put(record);
              }
            } catch (error) {
              fail(error instanceof Error ? error : new Error('Could not stage encrypted records.'));
            }
          };
        }
      });
    },
  };
}
