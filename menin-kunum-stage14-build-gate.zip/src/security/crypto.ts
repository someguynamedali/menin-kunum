export const ENCRYPTED_PAYLOAD_VERSION = 1 as const;
export const ENCRYPTION_ALGORITHM = 'AES-256-GCM' as const;
const NONCE_BYTES = 12;
const DATA_KEY_BYTES = 32;

export interface EncryptedPayload {
  formatVersion: typeof ENCRYPTED_PAYLOAD_VERSION;
  algorithm: typeof ENCRYPTION_ALGORITHM;
  nonce: string;
  ciphertext: string;
}

function webCrypto(): Crypto {
  if (!globalThis.crypto?.subtle || !globalThis.crypto?.getRandomValues) {
    throw new Error('Web Crypto is unavailable in this environment');
  }
  return globalThis.crypto;
}

export function encodeBase64Url(bytes: Uint8Array): string {
  let binary = '';
  for (let index = 0; index < bytes.length; index += 1) binary += String.fromCharCode(bytes[index]!);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}

export function decodeBase64Url(value: string): Uint8Array {
  if (!/^[A-Za-z0-9_-]*$/.test(value)) throw new Error('Invalid base64url data');
  const padded = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - (value.length % 4)) % 4);
  const binary = atob(padded);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  return bytes;
}

export function randomBytes(length: number): Uint8Array {
  if (!Number.isInteger(length) || length <= 0) throw new Error('Byte length must be a positive integer');
  return webCrypto().getRandomValues(new Uint8Array(length));
}

export async function generateRawDataKey(): Promise<Uint8Array> {
  return randomBytes(DATA_KEY_BYTES);
}

export async function importDataKey(rawKey: Uint8Array): Promise<CryptoKey> {
  if (rawKey.byteLength !== DATA_KEY_BYTES) throw new Error('Data key must be 256 bits');
  return webCrypto().subtle.importKey('raw', rawKey, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}

export async function generateDataKey(): Promise<CryptoKey> {
  const raw = await generateRawDataKey();
  try {
    return await importDataKey(raw);
  } finally {
    raw.fill(0);
  }
}

export async function encryptPayload(plaintext: string, key: CryptoKey, associatedData: string): Promise<EncryptedPayload> {
  if (typeof plaintext !== 'string') throw new TypeError('Plaintext must be a string');
  if (typeof associatedData !== 'string' || associatedData.length === 0) throw new Error('Associated data is required');
  const nonce = randomBytes(NONCE_BYTES);
  const ciphertext = await webCrypto().subtle.encrypt(
    { name: 'AES-GCM', iv: nonce, additionalData: new TextEncoder().encode(associatedData), tagLength: 128 },
    key,
    new TextEncoder().encode(plaintext),
  );
  return {
    formatVersion: ENCRYPTED_PAYLOAD_VERSION,
    algorithm: ENCRYPTION_ALGORITHM,
    nonce: encodeBase64Url(nonce),
    ciphertext: encodeBase64Url(new Uint8Array(ciphertext)),
  };
}

export async function decryptPayload(payload: EncryptedPayload, key: CryptoKey, associatedData: string): Promise<string> {
  if (!payload || payload.formatVersion !== ENCRYPTED_PAYLOAD_VERSION) throw new Error('Unsupported encrypted payload version');
  if (payload.algorithm !== ENCRYPTION_ALGORITHM) throw new Error('Unsupported encryption algorithm');
  if (typeof associatedData !== 'string' || associatedData.length === 0) throw new Error('Associated data is required');
  const nonce = decodeBase64Url(payload.nonce);
  const ciphertext = decodeBase64Url(payload.ciphertext);
  if (nonce.byteLength !== NONCE_BYTES) throw new Error('Invalid AES-GCM nonce length');
  if (ciphertext.byteLength < 16) throw new Error('Invalid AES-GCM ciphertext length');
  const plaintext = await webCrypto().subtle.decrypt(
    { name: 'AES-GCM', iv: nonce, additionalData: new TextEncoder().encode(associatedData), tagLength: 128 },
    key,
    ciphertext,
  );
  return new TextDecoder('utf-8', { fatal: true }).decode(plaintext);
}
