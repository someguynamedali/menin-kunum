import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import App from './App';

describe('App', () => {
  it('renders the app title Менин күнүм', () => {
    render(<App />);
    expect(screen.getByRole('heading', { name: 'Менин күнүм' })).toBeInTheDocument();
  });
});
