import { useEffect, useMemo, useRef, useState } from 'react';
import type { FormEvent } from 'react';
import type { DiaryEntry, Habit, HabitLog, Locale, Mood, Note, Priority, Project, Task } from '../domain/models.ts';
import { validateRequiredTitle, validateIsoDate } from '../domain/validation.ts';
import { formatDate, formatTime, t } from '../i18n/index.ts';
import { openAppDatabase } from '../storage/db.ts';
import { createTasksRepository } from '../storage/repositories/tasks.ts';
import { createEncryptedNotesRepository } from '../storage/repositories/notes.ts';
import { createEncryptedDiaryRepository } from '../storage/repositories/diary.ts';
import { createHabitsRepository } from '../storage/repositories/habits.ts';
import { createProjectsRepository } from '../storage/repositories/projects.ts';
import { createHabitLogsRepository } from '../storage/repositories/habit-logs.ts';
import type { IdentifiedRecord, RecordRepository, RecordStore } from '../storage/repositories/base.ts';
import { createIndexedDbStore } from '../storage/repositories/indexed-db-store.ts';
import { createSecuritySession } from '../security/session.ts';
import { changePin, createPinUnlockGuard, initializeKeyring, recoverWithCode, type Keyring } from '../security/key-management.ts';
import { loadKeyring, saveKeyring, updateKeyring, type SecurityKeyringRecord } from '../security/keyring-store.ts';
import { assertKeyringPresentForEncryptedRecords, createIndexedDbMigrationAdapter, migrateLegacyContentStoresAtomically } from '../security/migration.ts';
import { SecurityGate, type SecurityGateMode } from '../features/security/SecurityGate.tsx';
import { createTaskService } from '../services/tasks.ts';
import { createNoteService } from '../services/notes.ts';
import { createDiaryService } from '../services/diary.ts';
import { createHabitService } from '../services/habits.ts';
import { createProjectService } from '../services/projects.ts';
import { createCalendarService } from '../services/calendar.ts';
import { createStatisticsService } from '../services/statistics.ts';
import { createLocalSummariesService } from '../services/local-summaries.ts';
import { createSettingsService, type StoredSettings } from '../services/settings.ts';
import { createReminderService, requestReminderPermission } from '../services/reminders.ts';
import { createAttachmentsService, type EncryptedAttachmentRecord } from '../services/attachments.ts';
import { createIndexedDbBackupAdapter, exportEncryptedBackup, previewEncryptedBackup, restoreBackupPreview as applyBackupPreview, type BackupPreview, type BackupSnapshot } from '../services/backup.ts';
import { HabitsPage } from '../features/habits/HabitsPage.tsx';
import { CalendarPage } from '../features/calendar/CalendarPage.tsx';
import { StatsPage } from '../features/stats/StatsPage.tsx';
import { ProjectsPanel } from '../features/plans/ProjectsPanel.tsx';
import { AttachmentGallery, AttachmentPicker } from '../features/diary/AttachmentPicker.tsx';
import { BackupPanel } from '../features/settings/BackupPanel.tsx';
import { ReminderSettings } from '../features/settings/ReminderSettings.tsx';
import './app.css';

type Screen = 'home' | 'plans' | 'notes' | 'diary' | 'more' | 'settings' | 'projects' | 'habits' | 'calendar' | 'stats';
type NavItem = { id: 'home' | 'plans' | 'notes' | 'diary' | 'more'; icon: string; key: string };
type Services = { tasks: ReturnType<typeof createTaskService>; notes: ReturnType<typeof createNoteService>; diary: ReturnType<typeof createDiaryService>; habits: ReturnType<typeof createHabitService>; habitLogs: RecordRepository<HabitLog>; projects: ReturnType<typeof createProjectService>; calendar: ReturnType<typeof createCalendarService>; statistics: ReturnType<typeof createStatisticsService>; localSummaries: ReturnType<typeof createLocalSummariesService>; attachments: ReturnType<typeof createAttachmentsService> };
type LegacyContentRecord = IdentifiedRecord & Record<string, unknown>;
type PendingSecuritySetup = { keyring: Keyring; recoveryCode: string; dataKey: CryptoKey };

function createAppServices(database: IDBDatabase, getDataKey: () => CryptoKey): Services {
  const taskRepository = createTasksRepository(database);
  const projectRepository = createProjectsRepository(database);
  const habitRepository = createHabitsRepository(database);
  const habitLogRepository = createHabitLogsRepository(database);
  const attachmentStore = createIndexedDbStore<EncryptedAttachmentRecord>(database, 'attachments');
  return {
    tasks: createTaskService(taskRepository),
    notes: createNoteService(createEncryptedNotesRepository(database, getDataKey)),
    diary: createDiaryService(createEncryptedDiaryRepository(database, getDataKey)),
    habits: createHabitService(habitRepository, habitLogRepository),
    habitLogs: habitLogRepository,
    projects: createProjectService(projectRepository, taskRepository),
    calendar: createCalendarService(),
    statistics: createStatisticsService(),
    localSummaries: createLocalSummariesService(),
    attachments: createAttachmentsService(attachmentStore, getDataKey),
  };
}

const navigation: NavItem[] = [
  { id: 'home', icon: '⌂', key: 'nav.home' },
  { id: 'plans', icon: '▤', key: 'nav.plans' },
  { id: 'notes', icon: '✎', key: 'nav.notes' },
  { id: 'diary', icon: '☾', key: 'nav.diary' },
  { id: 'more', icon: '•••', key: 'nav.more' },
];

const copy = {
  ru: {
    greeting: 'Хорошо, что ты здесь.', pace: 'Твой день. Твой ритм.', welcome: 'Собери мысли, расставь приоритеты и оставь место для себя.',
    today: 'Спокойный старт', quick: 'Быстрые действия', newTask: 'Новая задача', writeDiary: 'Запись в дневник', taskHint: 'Разложи день по шагам', diaryHint: 'Запиши то, что важно', thought: 'МЫСЛЬ ДНЯ', privacy: 'Твоё пространство', privacyText: 'Данные хранятся на устройстве. Содержимое заметок и дневника зашифровано; названия, даты и теги остаются видимыми для поиска.',
    plansTitle: 'Планы и задачи', plansSubtitle: 'Выбери следующий понятный шаг.', notesTitle: 'Заметки', notesSubtitle: 'Сохраняй идеи, чтобы вернуться к ним позже.', diaryTitle: 'Личный дневник', diarySubtitle: 'Записывай мысли и отмечай настроение.', moreTitle: 'Твоё пространство', moreSubtitle: 'Управляй проектами, отслеживай привычки и замечай свой прогресс.',
    title: 'Название', description: 'Описание или текст', dueDate: 'Срок', priority: 'Приоритет', low: 'Низкий', medium: 'Средний', high: 'Высокий', addTask: 'Добавить задачу', save: 'Сохранить', saved: 'Сохранено', cancel: 'Отмена', delete: 'Удалить', edit: 'Изменить', complete: 'Отметить выполненной', reopen: 'Вернуть в работу', noTasks: 'Пока нет задач. Добавь первую — даже маленький шаг имеет значение.',
    search: 'Поиск по заметкам', addNote: 'Новая заметка', tags: 'Теги через запятую', favorite: 'В избранное', unfavorite: 'Убрать из избранного', noNotes: 'Заметок пока нет. Сохрани здесь идею, мысль или полезную информацию.',
    date: 'Дата записи', mood: 'Настроение', great: 'Отличное', good: 'Хорошее', okay: 'Обычное', lowMood: 'Пониженное', difficult: 'Тяжёлое', addEntry: 'Сохранить запись', noDiary: 'Записей пока нет. Начни с пары предложений о своём дне.',
    loading: 'Открываем локальное хранилище…', storageError: 'Не удалось открыть локальное хранилище. Проверь, что браузер разрешает хранение данных.', titleRequired: 'Введи название.', saveError: 'Не удалось сохранить запись. Попробуй ещё раз.', deleteConfirm: 'Удалить эту запись без возможности отмены?',
    settings: 'Настройки', language: 'Язык', offline: 'Офлайн-режим', offlineText: 'Файлы приложения могут работать без интернета после первого успешного открытия.', security: 'Шифруется только содержимое заметок и дневника. Их названия, даты и теги остаются открытыми для поиска; задачи, проекты и привычки в этой версии не шифруются. Сохрани код восстановления отдельно от телефона.', securityPinTitle: 'Изменить PIN-код', currentPinLabel: 'Текущий PIN-код', newPinLabel: 'Новый PIN-код', confirmNewPinLabel: 'Повтори новый PIN-код', changePinAction: 'Сохранить новый PIN', pinMismatch: 'Новые PIN-коды не совпадают.', pinShort: 'Используй не менее 6 символов.', pinChanged: 'PIN-код изменён.', pinChangeError: 'Не удалось изменить PIN. Проверь текущий код и попробуй снова.',
    planned: 'В работе', completed: 'Выполнено', emptySearch: 'По запросу ничего не найдено.', diaryTitleField: 'Заголовок (необязательно)',
  },
  ky: {
    greeting: 'Келгениңе кубанычтабыз.', pace: 'Сенин күнүң. Сенин ыргагың.', welcome: 'Ойлоруңду иретте, маанилүү иштерди танда жана өзүңө убакыт калтыр.', today: 'Жай баштоо', quick: 'Тез аракеттер', newTask: 'Жаңы тапшырма', writeDiary: 'Күндөлүккө жазуу', taskHint: 'Күнүңдү кадамдарга бөл', diaryHint: 'Маанилүү нерсени жаз', thought: 'КҮНДҮН ОЮ', privacy: 'Сенин мейкиндигиң', privacyText: 'Маалыматтар түзмөктө сакталат. Белгилердин жана күндөлүктүн мазмуну шифрленет; аталыштар, даталар жана тегдер издөө үчүн ачык калат.',
    plansTitle: 'Пландар жана тапшырмалар', plansSubtitle: 'Кийинки так кадамды танда.', notesTitle: 'Белгилер', notesSubtitle: 'Идеяларды кийин кайрылуу үчүн сакта.', diaryTitle: 'Жеке күндөлүк', diarySubtitle: 'Ойлоруңду жазып, маанайыңды белгилеп тур.', moreTitle: 'Сенин мейкиндигиң', moreSubtitle: 'Долбоорлорду башкар, адаттарды белгилеп, прогрессиңди байка.', title: 'Аталышы', description: 'Сүрөттөмө же текст', dueDate: 'Мөөнөтү', priority: 'Маанилүүлүгү', low: 'Төмөн', medium: 'Орточо', high: 'Жогору', addTask: 'Тапшырма кошуу', save: 'Сактоо', saved: 'Сакталды', cancel: 'Жокко чыгаруу', delete: 'Өчүрүү', edit: 'Өзгөртүү', complete: 'Аткарылды деп белгилөө', reopen: 'Кайра ишке кайтаруу', noTasks: 'Азырынча тапшырма жок. Биринчисин кош — кичинекей кадам да маанилүү.', search: 'Белгилерден издөө', addNote: 'Жаңы белги', tags: 'Үтүр менен бөлүнгөн тегдер', favorite: 'Тандалгандарга кошуу', unfavorite: 'Тандалгандардан алуу', noNotes: 'Азырынча белгилер жок. Идеяңды же пайдалуу маалыматты сакта.', date: 'Жазылган күнү', mood: 'Маанай', great: 'Сонун', good: 'Жакшы', okay: 'Кадимки', lowMood: 'Төмөн', difficult: 'Оор', addEntry: 'Жазууну сактоо', noDiary: 'Азырынча жазуу жок. Күнүң тууралуу бир-эки сүйлөмдөн башта.', loading: 'Жергиликтүү сактагыч ачылууда…', storageError: 'Жергиликтүү сактагыч ачылган жок. Браузер маалымат сактоого уруксат берерин текшер.', titleRequired: 'Аталышын жаз.', saveError: 'Сактоо мүмкүн болгон жок. Кайра аракет кыл.', deleteConfirm: 'Бул жазууну биротоло өчүрөсүңбү?', settings: 'Жөндөөлөр', language: 'Тил', offline: 'Офлайн режими', offlineText: 'Биринчи ийгиликтүү ачылгандан кийин колдонмонун файлдары интернетсиз иштей алат.', security: 'Белгилердин жана күндөлүктүн мазмуну түзмөктө шифрленет. Аталыштар, даталар жана тегдер издөө үчүн ачык калат. Калыбына келтирүү кодун телефондон өзүнчө сакта.', securityPinTitle: 'PIN-кодду өзгөртүү', currentPinLabel: 'Учурдагы PIN-код', newPinLabel: 'Жаңы PIN-код', confirmNewPinLabel: 'Жаңы PIN-кодду кайтала', changePinAction: 'Жаңы PIN-кодду сактоо', pinMismatch: 'Жаңы PIN-коддор дал келген жок.', pinShort: 'Кеминде 6 белги колдон.', pinChanged: 'PIN-код өзгөртүлдү.', pinChangeError: 'PIN-кодду өзгөртүү мүмкүн болгон жок. Учурдагы кодду текшерип, кайра аракет кыл.', planned: 'Аткарылууда', completed: 'Аткарылды', emptySearch: 'Бул издөө боюнча эч нерсе табылган жок.', diaryTitleField: 'Аталышы (милдеттүү эмес)',
  },
  en: {
    greeting: 'Good to have you here.', pace: 'Your day. Your pace.', welcome: 'Gather your thoughts, choose what matters, and leave room for yourself.', today: 'A gentle start', quick: 'Quick actions', newTask: 'New task', writeDiary: 'Diary entry', taskHint: 'Break your day into steps', diaryHint: 'Write down what matters', thought: 'A THOUGHT FOR TODAY', privacy: 'Your space', privacyText: 'Data stays on this device. Note and diary contents are encrypted; titles, dates and tags remain visible for search.', plansTitle: 'Plans and tasks', plansSubtitle: 'Choose the next clear step.', notesTitle: 'Notes', notesSubtitle: 'Keep ideas so you can return to them later.', diaryTitle: 'Personal diary', diarySubtitle: 'Write your thoughts and reflect on your mood.', moreTitle: 'Your space', moreSubtitle: 'Organize projects, track habits, and notice your progress.', title: 'Title', description: 'Description or text', dueDate: 'Due date', priority: 'Priority', low: 'Low', medium: 'Medium', high: 'High', addTask: 'Add task', save: 'Save', saved: 'Saved', cancel: 'Cancel', delete: 'Delete', edit: 'Edit', complete: 'Mark complete', reopen: 'Reopen task', noTasks: 'No tasks yet. Add your first one—even a small step matters.', search: 'Search notes', addNote: 'New note', tags: 'Tags separated by commas', favorite: 'Add to favorites', unfavorite: 'Remove from favorites', noNotes: 'No notes yet. Save an idea or useful information here.', date: 'Entry date', mood: 'Mood', great: 'Great', good: 'Good', okay: 'Okay', lowMood: 'Low', difficult: 'Difficult', addEntry: 'Save entry', noDiary: 'No entries yet. Start with a couple of sentences about your day.', loading: 'Opening local storage…', storageError: 'Could not open local storage. Check whether your browser allows local data storage.', titleRequired: 'Please enter a title.', saveError: 'Could not save this entry. Please try again.', deleteConfirm: 'Delete this entry permanently?', settings: 'Settings', language: 'Language', offline: 'Offline mode', offlineText: 'App files can work offline after the first successful load.', security: 'Note and diary contents are encrypted on this device. Titles, dates and tags remain visible for search. Keep the recovery code somewhere separate from your phone.', securityPinTitle: 'Change PIN', currentPinLabel: 'Current PIN', newPinLabel: 'New PIN', confirmNewPinLabel: 'Confirm new PIN', changePinAction: 'Save new PIN', pinMismatch: 'The new PINs do not match.', pinShort: 'Use at least 6 characters.', pinChanged: 'PIN changed.', pinChangeError: 'Could not change PIN. Check the current PIN and try again.', planned: 'In progress', completed: 'Completed', emptySearch: 'No results found.', diaryTitleField: 'Title (optional)',
  },
} as const;

type CopyKey = keyof typeof copy.ru;
type CopyText = Record<CopyKey, string>;
const quotes: Record<Locale, string[]> = {
  ru: ['Не обязательно видеть всю лестницу. Достаточно сделать следующий шаг.', 'Маленький прогресс — тоже прогресс.', 'Не нужно быть идеальным. Нужно продолжать.', 'Пусть сегодняшний день будет немного ближе к твоей цели.'],
  ky: ['Бүт жолду көрүү шарт эмес. Кийинки кадамды жаса.', 'Кичинекей жылыш да — жылыш.', 'Кемчиликсиз болуу шарт эмес. Улантуу маанилүү.', 'Бүгүн максатыңа бир аз жакында.'],
  en: ['You do not need to see the whole staircase. Just take the next step.', 'Small progress is still progress.', 'You do not need to be perfect. Keep going.', 'Let today bring you a little closer to your goal.'],
};

function localDateString(date = new Date()): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}
function sortNewest<T extends { updatedAt: string }>(items: T[]): T[] {
  return [...items].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [locale, setLocale] = useState<Locale>(() => {
    try { const saved = window.localStorage.getItem('menin-kunum-locale'); return saved === 'ky' || saved === 'en' ? saved : 'ru'; } catch { return 'ru'; }
  });
  const [now, setNow] = useState(() => new Date());
  const [online, setOnline] = useState(() => typeof navigator === 'undefined' ? true : navigator.onLine);
  const [repositories, setRepositories] = useState<Services | null>(null);
  const [database, setDatabase] = useState<IDBDatabase | null>(null);
  const [securityMode, setSecurityMode] = useState<SecurityGateMode | 'unlocked'>('loading');
  const [securityError, setSecurityError] = useState('');
  const [securityBusy, setSecurityBusy] = useState(false);
  const [keyring, setKeyring] = useState<Keyring | null>(null);
  const [pendingSetup, setPendingSetup] = useState<PendingSecuritySetup | null>(null);
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmNewPin, setConfirmNewPin] = useState('');
  const securityStoreRef = useRef<RecordStore<SecurityKeyringRecord> | null>(null);
  const settingsStoreRef = useRef<RecordStore<StoredSettings> | null>(null);
  const settingsServiceRef = useRef<ReturnType<typeof createSettingsService> | null>(null);
  const reminderServiceRef = useRef<ReturnType<typeof createReminderService> | null>(null);
  if (!reminderServiceRef.current) reminderServiceRef.current = createReminderService();
  const [remindersEnabled, setRemindersEnabled] = useState(false);
  const [dailyReminderTime, setDailyReminderTime] = useState('20:00');
  const [notificationPermission, setNotificationPermission] = useState<'default' | 'granted' | 'denied' | 'unsupported'>(() => typeof Notification === 'undefined' ? 'unsupported' : Notification.permission);
  const sessionRef = useRef<ReturnType<typeof createSecuritySession> | null>(null);
  const unlockGuardRef = useRef<ReturnType<typeof createPinUnlockGuard> | null>(null);
  const [storageReady, setStorageReady] = useState(false);
  const [storageError, setStorageError] = useState('');
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [notes, setNotes] = useState<Note[]>([]);
  const [diary, setDiary] = useState<DiaryEntry[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [habitLogs, setHabitLogs] = useState<HabitLog[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [diaryFiles, setDiaryFiles] = useState<File[]>([]);
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDate, setTaskDate] = useState(localDateString());
  const [taskPriority, setTaskPriority] = useState<Priority>('medium');
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteBody, setNoteBody] = useState('');
  const [noteTags, setNoteTags] = useState('');
  const [noteSearch, setNoteSearch] = useState('');
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [diaryTitle, setDiaryTitle] = useState('');
  const [diaryBody, setDiaryBody] = useState('');
  const [diaryDate, setDiaryDate] = useState(localDateString());
  const [diaryMood, setDiaryMood] = useState<Mood>('okay');
  const [editingDiaryId, setEditingDiaryId] = useState<string | null>(null);
  const c: CopyText = copy[locale];
  const text = (key: CopyKey) => c[key];

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 30_000);
    const updateOnline = () => setOnline(navigator.onLine);
    window.addEventListener('online', updateOnline);
    window.addEventListener('offline', updateOnline);
    return () => { window.clearInterval(timer); window.removeEventListener('online', updateOnline); window.removeEventListener('offline', updateOnline); };
  }, []);

  useEffect(() => {
    try { window.localStorage.setItem('menin-kunum-locale', locale); } catch { /* Optional preference only. */ }
    document.documentElement.lang = locale;
    void settingsServiceRef.current?.update({ locale }).catch(() => undefined);
  }, [locale]);

  useEffect(() => reminderServiceRef.current?.schedule({ enabled: securityMode === 'unlocked' && remindersEnabled, permission: notificationPermission, time: dailyReminderTime, locale }), [securityMode, remindersEnabled, notificationPermission, dailyReminderTime, locale]);

  useEffect(() => {
    let cancelled = false;
    let database: IDBDatabase | undefined;
    async function initialize() {
      try {
        database = await openAppDatabase();
        const securityStore = createIndexedDbStore<SecurityKeyringRecord>(database, 'settings');
        const settingsStore = createIndexedDbStore<StoredSettings>(database, 'settings');
        const settingsService = createSettingsService(settingsStore);
        const preferences = await settingsService.get();
        const savedKeyring = await loadKeyring(securityStore);
        const noteStore = createIndexedDbStore<LegacyContentRecord>(database, 'notes');
        const diaryStore = createIndexedDbStore<LegacyContentRecord>(database, 'diaryEntries');
        const attachmentStore = createIndexedDbStore<LegacyContentRecord>(database, 'attachments');
        await assertKeyringPresentForEncryptedRecords(savedKeyring, [noteStore, diaryStore, attachmentStore]);
        if (cancelled) { database.close(); return; }
        securityStoreRef.current = securityStore;
        settingsStoreRef.current = settingsStore;
        settingsServiceRef.current = settingsService;
        setRemindersEnabled(preferences.remindersEnabled);
        setDailyReminderTime(preferences.dailyReminderTime ?? '20:00');
        sessionRef.current = createSecuritySession();
        setDatabase(database);
        setKeyring(savedKeyring ?? null);
        unlockGuardRef.current = savedKeyring ? createPinUnlockGuard(() => savedKeyring, { maxAttempts: 5, cooldownMs: 30_000 }) : null;
        setSecurityMode(savedKeyring ? 'unlock' : 'setup');
        setStorageReady(true);
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : c.storageError;
          setStorageError(message); setSecurityError(message); setSecurityMode('error'); setStorageReady(true);
        }
      }
    }
    void initialize();
    return () => { cancelled = true; database?.close(); };
    // The database connection is intentionally opened once per app mount.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filteredNotes = useMemo(() => {
    const query = noteSearch.trim().toLocaleLowerCase(locale);
    return sortNewest(notes).filter((note) => !query || `${note.title} ${note.body} ${note.tags.join(' ')}`.toLocaleLowerCase(locale).includes(query));
  }, [notes, noteSearch, locale]);
  const todayTasks = tasks.filter((task) => task.status !== 'completed' && (!task.dueDate || task.dueDate <= localDateString())).sort((a, b) => ({ high: 0, medium: 1, low: 2 }[a.priority] - { high: 0, medium: 1, low: 2 }[b.priority]));
  const completedToday = tasks.filter((task) => task.status === 'completed').length;
  const completionPercent = tasks.length ? Math.round((completedToday / tasks.length) * 100) : 0;
  const latestDiaryEntry = [...diary].sort((a, b) => b.date.localeCompare(a.date) || b.updatedAt.localeCompare(a.updatedAt))[0];

  const refreshData = async (repos: Services | null = repositories) => {
    if (!repos) return;
    const [nextTasks, nextNotes, nextDiary, nextHabits, nextHabitLogs, nextProjects] = await Promise.all([repos.tasks.list(), repos.notes.list(), repos.diary.list(), repos.habits.list(), repos.habitLogs.list(), repos.projects.list()]);
    setTasks(sortNewest(nextTasks)); setNotes(sortNewest(nextNotes)); setDiary(sortNewest(nextDiary)); setHabits(nextHabits); setHabitLogs(nextHabitLogs); setProjects(nextProjects);
  };
  const activateDataKey = async (dataKey: CryptoKey) => {
    if (!database) throw new Error('Локальное хранилище ещё не открыто.');
    setSecurityBusy(true); setSecurityError(''); setSecurityMode('migration');
    try {
      if (!sessionRef.current) sessionRef.current = createSecuritySession();
      sessionRef.current.unlock(dataKey);
      await migrateLegacyContentStoresAtomically(createIndexedDbMigrationAdapter(database), dataKey);
      const repos = createAppServices(database, () => {
        if (!sessionRef.current) throw new Error('Security session is unavailable.');
        return sessionRef.current.getDataKey();
      });
      const [nextTasks, nextNotes, nextDiary, nextHabits, nextHabitLogs, nextProjects] = await Promise.all([repos.tasks.list(), repos.notes.list(), repos.diary.list(), repos.habits.list(), repos.habitLogs.list(), repos.projects.list()]);
      setRepositories(repos); setTasks(sortNewest(nextTasks)); setNotes(sortNewest(nextNotes)); setDiary(sortNewest(nextDiary)); setHabits(nextHabits); setHabitLogs(nextHabitLogs); setProjects(nextProjects);
      setSecurityMode('unlocked'); setSecurityError('');
    } catch (error) {
      setRepositories(null); setTasks([]); setNotes([]); setDiary([]); setHabits([]); setHabitLogs([]); setProjects([]);
      setSecurityError(error instanceof Error ? error.message : 'Не удалось безопасно открыть записи.');
      setSecurityMode('migration');
    } finally { setSecurityBusy(false); }
  };
  const setupSecurity = async (pin: string) => {
    setSecurityBusy(true); setSecurityError('');
    try {
      const setup = await initializeKeyring(pin);
      setPendingSetup(setup); setSecurityMode('recovery-code');
    } catch (error) {
      setSecurityError(error instanceof Error ? error.message : 'Не удалось создать защиту.');
    } finally { setSecurityBusy(false); }
  };
  const confirmRecoverySaved = async () => {
    if (!pendingSetup || !securityStoreRef.current) return;
    setSecurityBusy(true); setSecurityError('');
    try {
      await saveKeyring(securityStoreRef.current, pendingSetup.keyring);
      setKeyring(pendingSetup.keyring);
      unlockGuardRef.current = createPinUnlockGuard(() => pendingSetup.keyring, { maxAttempts: 5, cooldownMs: 30_000 });
      const dataKey = pendingSetup.dataKey;
      setPendingSetup(null);
      await activateDataKey(dataKey);
    } catch (error) {
      setSecurityError(error instanceof Error ? error.message : 'Не удалось сохранить настройку защиты.');
    } finally { setSecurityBusy(false); }
  };
  const unlockSecurity = async (pin: string) => {
    if (!keyring) return;
    setSecurityBusy(true); setSecurityError('');
    try {
      const guard = unlockGuardRef.current ?? createPinUnlockGuard(() => keyring, { maxAttempts: 5, cooldownMs: 30_000 });
      unlockGuardRef.current = guard;
      const dataKey = await guard.unlock(pin);
      await activateDataKey(dataKey);
    } catch (error) {
      setSecurityError(error instanceof Error ? error.message : 'Не удалось разблокировать приложение.');
    } finally { setSecurityBusy(false); }
  };
  const recoverSecurity = async (code: string, newPin: string) => {
    if (!keyring || !securityStoreRef.current) return;
    setSecurityBusy(true); setSecurityError('');
    try {
      const recovered = await recoverWithCode(code, newPin, keyring);
      await updateKeyring(securityStoreRef.current, recovered.keyring);
      setKeyring(recovered.keyring);
      unlockGuardRef.current = createPinUnlockGuard(() => recovered.keyring, { maxAttempts: 5, cooldownMs: 30_000 });
      await activateDataKey(recovered.dataKey);
    } catch (error) {
      setSecurityError(error instanceof Error ? error.message : 'Не удалось восстановить доступ.');
    } finally { setSecurityBusy(false); }
  };
  const retrySecurityMigration = async () => {
    try {
      if (!sessionRef.current) throw new Error('Сессия заблокирована. Введи PIN-код ещё раз.');
      await activateDataKey(sessionRef.current.getDataKey());
    } catch (error) {
      sessionRef.current?.lockSession(); setSecurityMode('unlock');
      setSecurityError(error instanceof Error ? error.message : 'Не удалось продолжить миграцию.');
    }
  };
  const lockSecurity = () => {
    sessionRef.current?.lockSession(); setRepositories(null);
    setTasks([]); setNotes([]); setDiary([]); setHabits([]); setHabitLogs([]); setProjects([]);
    setTaskTitle(''); setNoteTitle(''); setNoteBody(''); setNoteTags(''); setNoteSearch(''); setEditingNoteId(null);
    setDiaryTitle(''); setDiaryBody(''); setDiaryFiles([]); setEditingDiaryId(null); setSecurityError(''); setNotice(''); setScreen('home');
    setSecurityMode('unlock');
  };
  const toggleReminders = async () => {
    if (!settingsServiceRef.current) return;
    let permission: 'default' | 'granted' | 'denied' | 'unsupported' = notificationPermission;
    if (!remindersEnabled) {
      permission = await requestReminderPermission();
      setNotificationPermission(permission);
      if (permission !== 'granted') {
        setNotice(locale === 'en' ? 'Allow notifications in your browser settings to enable reminders.' : locale === 'ky' ? 'Эскертмелерди күйгүзүү үчүн браузерден уруксат бер.' : 'Разреши уведомления в настройках браузера, чтобы включить напоминания.');
        return;
      }
    }
    try {
      const next = await settingsServiceRef.current.update({ remindersEnabled: !remindersEnabled, dailyReminderTime, locale });
      setRemindersEnabled(next.remindersEnabled); setNotice('');
    } catch {
      setNotice(locale === 'en' ? 'Could not save reminder settings.' : locale === 'ky' ? 'Эскертме жөндөөлөрү сакталган жок.' : 'Не удалось сохранить настройки напоминаний.');
    }
  };
  const changeReminderTime = async (time: string) => {
    if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(time) || !settingsServiceRef.current) return;
    setDailyReminderTime(time);
    try { await settingsServiceRef.current.update({ dailyReminderTime: time, remindersEnabled, locale }); }
    catch { setNotice(locale === 'en' ? 'Could not save reminder time.' : locale === 'ky' ? 'Эскертме убактысы сакталган жок.' : 'Не удалось сохранить время напоминания.'); }
  };
  const exportBackupFile = async (passphrase: string): Promise<string> => {
    if (!repositories) throw new Error('Сначала разблокируй приложение.');
    const snapshot: BackupSnapshot = {
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      records: {
        tasks: await repositories.tasks.list(),
        projects: await repositories.projects.list(),
        notes: await repositories.notes.list(),
        diaryEntries: await repositories.diary.list(),
        habits: await repositories.habits.list(),
        habitLogs: await repositories.habitLogs.list(),
        attachments: await repositories.attachments.exportForBackup(),
      },
    };
    return exportEncryptedBackup(snapshot, passphrase);
  };
  const previewBackupFile = (serialized: string, passphrase: string): Promise<BackupPreview> => previewEncryptedBackup(serialized, passphrase);
  const restoreBackupInApp = async (preview: BackupPreview) => {
    if (!database || !sessionRef.current) throw new Error('Сессия заблокирована. Разблокируй приложение и повтори попытку.');
    await applyBackupPreview(preview, sessionRef.current.getDataKey(), createIndexedDbBackupAdapter(database));
    setNoteTitle(''); setNoteBody(''); setNoteTags(''); setNoteSearch(''); setEditingNoteId(null);
    setDiaryTitle(''); setDiaryBody(''); setDiaryFiles([]); setEditingDiaryId(null);
    await refreshData();
  };
  const submitPinChange = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (newPin.length < 6 || confirmNewPin.length < 6) { setNotice(text('pinShort')); return; }
    if (newPin !== confirmNewPin) { setNotice(text('pinMismatch')); return; }
    if (!keyring || !securityStoreRef.current) { setNotice(text('pinChangeError')); return; }
    setSecurityBusy(true); setNotice('');
    try {
      const changedKeyring = await changePin(currentPin, newPin, keyring);
      await updateKeyring(securityStoreRef.current, changedKeyring);
      setKeyring(changedKeyring);
      unlockGuardRef.current = createPinUnlockGuard(() => changedKeyring, { maxAttempts: 5, cooldownMs: 30_000 });
      setCurrentPin(''); setNewPin(''); setConfirmNewPin(''); setNotice(text('pinChanged'));
    } catch {
      setNotice(text('pinChangeError'));
    } finally { setSecurityBusy(false); }
  };
  const runSave = async (operation: () => Promise<void>) => {
    if (busy) return;
    setBusy(true); setNotice('');
    try { await operation(); await refreshData(); setNotice(text('saved')); }
    catch { setNotice(text('saveError')); }
    finally { setBusy(false); }
  };
  const resetTaskForm = () => { setTaskTitle(''); setTaskDate(localDateString()); setTaskPriority('medium'); setEditingTaskId(null); };
  const saveTask = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validated = validateRequiredTitle(taskTitle);
    if (!validated.valid) { setNotice(text('titleRequired')); return; }
    if (taskDate && !validateIsoDate(taskDate).valid) { setNotice(text('saveError')); return; }
    if (!repositories) return;
    const existing = editingTaskId ? tasks.find((task) => task.id === editingTaskId) : undefined;
    const changes = { title: validated.value, dueDate: taskDate || undefined, priority: taskPriority };
    await runSave(async () => { if (existing) await repositories.tasks.update(existing.id, changes); else await repositories.tasks.create(changes); resetTaskForm(); });
  };
  const toggleTask = async (task: Task) => {
    if (!repositories) return;
    await runSave(async () => { await repositories.tasks.setStatus(task.id, task.status === 'completed' ? 'planned' : 'completed'); });
  };
  const removeTask = async (task: Task) => {
    if (!repositories || !window.confirm(text('deleteConfirm'))) return;
    await runSave(async () => { if (task.projectId) await repositories.projects.removeTask(task.projectId, task.id); await repositories.tasks.remove(task.id); if (editingTaskId === task.id) resetTaskForm(); });
  };
  const saveNote = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validated = validateRequiredTitle(noteTitle);
    if (!validated.valid) { setNotice(text('titleRequired')); return; }
    if (!repositories) return;
    const existing = editingNoteId ? notes.find((note) => note.id === editingNoteId) : undefined;
    const changes = { title: validated.value, body: noteBody.trim(), tags: [...new Set(noteTags.split(',').map((tag) => tag.trim()).filter(Boolean))] };
    await runSave(async () => { if (existing) await repositories.notes.update(existing.id, changes); else await repositories.notes.create(changes); setNoteTitle(''); setNoteBody(''); setNoteTags(''); setEditingNoteId(null); });
  };
  const editNote = (note: Note) => { setEditingNoteId(note.id); setNoteTitle(note.title); setNoteBody(note.body); setNoteTags(note.tags.join(', ')); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const toggleFavorite = async (note: Note) => { if (!repositories) return; await runSave(async () => { await repositories.notes.toggleFavorite(note.id); }); };
  const removeNote = async (note: Note) => { if (!repositories || !window.confirm(text('deleteConfirm'))) return; await runSave(async () => { await repositories.notes.remove(note.id); if (editingNoteId === note.id) { setEditingNoteId(null); setNoteTitle(''); setNoteBody(''); setNoteTags(''); } }); };
  const saveDiaryEntry = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const title = diaryTitle.trim() || (locale === 'ru' ? 'Запись за ' : locale === 'ky' ? 'Жазуу: ' : 'Entry for ') + diaryDate;
    if (!validateIsoDate(diaryDate).valid) { setNotice(text('saveError')); return; }
    if (!diaryBody.trim()) { setNotice(text('titleRequired')); return; }
    if (!repositories) return;
    const existing = editingDiaryId ? diary.find((entry) => entry.id === editingDiaryId) : undefined;
    await runSave(async () => {
      const createdAttachmentIds: string[] = [];
      try {
        for (const file of diaryFiles) createdAttachmentIds.push((await repositories.attachments.addFile(file)).id);
        const changes = { date: diaryDate, title, body: diaryBody.trim(), mood: diaryMood, goodThings: existing?.goodThings ?? [], concerns: existing?.concerns ?? [], gratitude: existing?.gratitude ?? [], tags: existing?.tags ?? [], attachmentIds: [...(existing?.attachmentIds ?? []), ...createdAttachmentIds] };
        if (existing) await repositories.diary.update(existing.id, changes); else await repositories.diary.create(changes);
        setDiaryTitle(''); setDiaryBody(''); setDiaryFiles([]); setDiaryDate(localDateString()); setDiaryMood('okay'); setEditingDiaryId(null);
      } catch (error) {
        await Promise.all(createdAttachmentIds.map((id) => repositories.attachments.remove(id).catch(() => undefined)));
        throw error;
      }
    });
  };
  const editDiaryEntry = (entry: DiaryEntry) => { setEditingDiaryId(entry.id); setDiaryTitle(entry.title); setDiaryBody(entry.body); setDiaryDate(entry.date); setDiaryMood(entry.mood ?? 'okay'); setDiaryFiles([]); window.scrollTo({ top: 0, behavior: 'smooth' }); };
  const removeDiaryEntry = async (entry: DiaryEntry) => { if (!repositories || !window.confirm(text('deleteConfirm'))) return; await runSave(async () => { await repositories.diary.remove(entry.id); await Promise.all((entry.attachmentIds ?? []).map((id) => repositories.attachments.remove(id).catch(() => undefined))); if (editingDiaryId === entry.id) { setEditingDiaryId(null); setDiaryTitle(''); setDiaryBody(''); setDiaryFiles([]); } }); };

  if (securityMode !== 'unlocked') {
    return <SecurityGate mode={securityMode} locale={locale} error={securityError || storageError} busy={securityBusy} recoveryCode={pendingSetup?.recoveryCode}
      onSetup={setupSecurity} onConfirmRecoverySaved={confirmRecoverySaved} onUnlock={unlockSecurity} onRecover={recoverSecurity} onRetryMigration={retrySecurityMigration} />;
  }

  const greeting = locale === 'ky' ? 'Кутман күн!' : locale === 'en' ? 'Make today count.' : c.greeting;
  const quote = quotes[locale][now.getDate() % quotes[locale].length];
  const dateLocale = locale === 'ky' ? 'ky-KG' : locale === 'en' ? 'en-US' : 'ru-RU';
  const moodLabel = (mood?: Mood) => mood ? ({ great: c.great, good: c.good, okay: c.okay, low: c.lowMood, difficult: c.difficult })[mood] : '';

  return (
    <main className="app-shell">
      <header className="topbar">
        <div className="brand-mark" aria-hidden="true">м</div>
        <div className="brand-copy"><span className="eyebrow">{t(locale, 'app.tagline').toLocaleUpperCase(locale)}</span><h1>{t(locale, 'app.title')}</h1></div>
        <div className="topbar-actions"><button className="icon-button" aria-label={text('settings')} title={text('settings')} onClick={() => setScreen('settings')} type="button">⚙</button><button className="icon-button security-lock-topbar" aria-label={locale === 'ky' ? 'Колдонмону кулпулоо' : locale === 'en' ? 'Lock app' : 'Заблокировать приложение'} title={locale === 'ky' ? 'Колдонмону кулпулоо' : locale === 'en' ? 'Lock app' : 'Заблокировать приложение'} onClick={lockSecurity} type="button">⌑</button></div>
      </header>
      <div className="status-row" aria-live="polite"><span className={`status-dot${online ? '' : ' is-offline'}`} /><span>{online ? (locale === 'ky' ? 'Интернет бар' : locale === 'en' ? 'Online' : 'Интернет доступен') : (locale === 'ky' ? 'Интернет жок · жергиликтүү режим' : locale === 'en' ? 'Offline · local mode' : 'Нет интернета · локальный режим')}</span><span className="status-time">{formatTime(now, locale)}</span></div>
      {!storageReady && <div className="inline-state" role="status">{text('loading')}</div>}
      {storageError && <div className="inline-error" role="alert">{text('storageError')}<small>{storageError}</small></div>}
      {notice && <div className="inline-notice" role="status">{notice}</div>}

      {screen === 'home' && <>
        <section className="welcome-card" aria-labelledby="welcome-title"><div className="welcome-orb orb-one" aria-hidden="true" /><div className="welcome-orb orb-two" aria-hidden="true" /><p className="eyebrow">{locale === 'ky' ? 'БИР КАДАМДАН БАШТА' : locale === 'en' ? 'ONE STEP AT A TIME' : 'ОДИН ШАГ ЗА РАЗ'}</p><h2 id="welcome-title">{greeting}<br /><span>{c.pace}</span></h2><p className="welcome-copy">{c.welcome}</p><div className="date-pill"><span aria-hidden="true">✦</span>{formatDate(now, locale)}</div></section>
        <section className="section-heading"><div><p className="eyebrow">{t(locale, 'home.today').toLocaleUpperCase(locale)}</p><h2>{c.today}</h2></div><span className="day-chip">{now.toLocaleDateString(dateLocale, { weekday: 'short', day: '2-digit', month: 'short' })}</span></section>
        <section className="summary-grid" aria-label={c.today}><div className="summary-card"><span className="summary-number">{tasks.filter((task) => task.status !== 'completed').length}</span><span>{locale === 'ky' ? 'Ачык тапшырмалар' : locale === 'en' ? 'Open tasks' : 'Открытых задач'}</span></div><div className="summary-card"><span className="summary-number">{completedToday}</span><span>{locale === 'ky' ? 'Аткарылганы' : locale === 'en' ? 'Completed' : 'Выполнено'}</span></div><div className="summary-card"><span className="summary-number">{diary.length}</span><span>{locale === 'ky' ? 'Күндөлүк жазуулары' : locale === 'en' ? 'Diary entries' : 'Записей в дневнике'}</span></div></section>
        <section className="progress-card" aria-label={locale === 'ky' ? 'Тапшырмалардын жүрүшү' : locale === 'en' ? 'Task progress' : 'Прогресс задач'}><div><strong>{locale === 'ky' ? 'Күнүмдүк жүрүш' : locale === 'en' ? 'Daily progress' : 'Прогресс дня'}</strong><span>{completionPercent}%</span></div><div className="progress-track"><span style={{ width: `${completionPercent}%` }} /></div><p>{tasks.length === 0 ? (locale === 'ky' ? 'Биринчи кадамыңды кош.' : locale === 'en' ? 'Add your first step.' : 'Добавь свой первый шаг.') : (locale === 'ky' ? `${completedToday} / ${tasks.length} тапшырма аткарылды` : locale === 'en' ? `${completedToday} of ${tasks.length} tasks completed` : `Выполнено ${completedToday} из ${tasks.length} задач`)}</p></section>
        <section className="mood-quick-card"><div><p className="eyebrow">{locale === 'ky' ? 'МААНАЙЫҢ КАНДАЙ?' : locale === 'en' ? 'HOW ARE YOU FEELING?' : 'КАК ТЫ СЕБЯ ЧУВСТВУЕШЬ?'}</p><h3>{locale === 'ky' ? 'Маанайыңды белгилеп кой' : locale === 'en' ? 'Check in with yourself' : 'Отметь своё настроение'}</h3></div><div className="mood-quick-options">{(['great', 'good', 'okay', 'low', 'difficult'] as Mood[]).map((mood) => <button key={mood} type="button" className={`mood-choice mood-${mood}`} aria-label={moodLabel(mood)} onClick={() => { setDiaryMood(mood); setScreen('diary'); }}>{mood === 'great' ? '☀' : mood === 'good' ? '☺' : mood === 'okay' ? '◉' : mood === 'low' ? '☁' : '☾'}<span>{moodLabel(mood)}</span></button>)}</div></section>
        <section className="quick-grid" aria-label={text('quick')}><button className="quick-card task-card" type="button" onClick={() => { setScreen('plans'); resetTaskForm(); }}><span className="quick-icon" aria-hidden="true">＋</span><span className="quick-label">{c.newTask}</span><span className="quick-caption">{c.taskHint}</span><span className="card-arrow" aria-hidden="true">↗</span></button><button className="quick-card diary-card" type="button" onClick={() => setScreen('diary')}><span className="quick-icon" aria-hidden="true">✧</span><span className="quick-label">{c.writeDiary}</span><span className="quick-caption">{c.diaryHint}</span><span className="card-arrow" aria-hidden="true">↗</span></button></section>
        <section className="quote-card"><span className="quote-symbol" aria-hidden="true">“</span><div><p className="eyebrow">{c.thought}</p><blockquote>{quote}</blockquote></div></section>
        {todayTasks.length > 0 && <section className="home-tasks"><div className="section-heading"><div><p className="eyebrow">{t(locale, 'home.today').toLocaleUpperCase(locale)}</p><h2>{locale === 'ky' ? 'Жакынкы иштер' : locale === 'en' ? 'Up next' : 'Ближайшие дела'}</h2></div><button className="text-action" type="button" onClick={() => setScreen('plans')}>{locale === 'ky' ? 'Баары' : locale === 'en' ? 'All' : 'Все'} →</button></div>{todayTasks.slice(0, 3).map((task) => <TaskCard key={task.id} task={task} onToggle={toggleTask} onEdit={(item) => { setEditingTaskId(item.id); setTaskTitle(item.title); setTaskDate(item.dueDate ?? ''); setTaskPriority(item.priority); setScreen('plans'); }} onDelete={removeTask} c={c} locale={locale} />)}</section>}
        {latestDiaryEntry && <section className="memory-card"><div className="memory-heading"><span className="privacy-icon" aria-hidden="true">☾</span><div><p className="eyebrow">{locale === 'ky' ? 'АКЫРКЫ ЭСКЕРҮҮ' : locale === 'en' ? 'A RECENT MEMORY' : 'ПОСЛЕДНЕЕ ВОСПОМИНАНИЕ'}</p><h3>{latestDiaryEntry.title}</h3></div></div><p>{latestDiaryEntry.body.length > 150 ? `${latestDiaryEntry.body.slice(0, 150).trim()}…` : latestDiaryEntry.body}</p><button className="text-action" type="button" onClick={() => setScreen('diary')}>{locale === 'ky' ? 'Күндөлүккө өтүү' : locale === 'en' ? 'Open diary' : 'Открыть дневник'} →</button></section>}
        <section className="privacy-note"><span className="privacy-icon" aria-hidden="true">◇</span><div><strong>{c.privacy}</strong><p>{c.privacyText}</p></div></section>
      </>}

      {screen === 'plans' && <section className="feature-page functional-page" aria-labelledby="feature-title"><div className="feature-icon" aria-hidden="true">▤</div><p className="eyebrow">{locale === 'ky' ? 'КҮНДҮН КАДАМДАРЫ' : locale === 'en' ? 'YOUR NEXT STEPS' : 'ШАГИ ТВОЕГО ДНЯ'}</p><h2 id="feature-title">{c.plansTitle}</h2><p className="feature-subtitle">{c.plansSubtitle}</p>
        <form className="editor-card" onSubmit={saveTask}><h3>{editingTaskId ? text('edit') : c.newTask}</h3><label className="field-label">{text('title')}<input value={taskTitle} onChange={(event) => setTaskTitle(event.target.value)} maxLength={160} required placeholder={locale === 'ru' ? 'Например, повторить английский' : locale === 'ky' ? 'Мисалы, англис тилин кайталоо' : 'e.g. Review English'} /></label><div className="field-row"><label className="field-label">{text('dueDate')}<input type="date" value={taskDate} onChange={(event) => setTaskDate(event.target.value)} /></label><label className="field-label">{text('priority')}<select value={taskPriority} onChange={(event) => setTaskPriority(event.target.value as Priority)}><option value="low">{text('low')}</option><option value="medium">{text('medium')}</option><option value="high">{text('high')}</option></select></label></div><div className="form-actions"><button className="primary-action" type="submit" disabled={!repositories || busy}>{busy ? '…' : text('save')}</button>{editingTaskId && <button className="secondary-button" type="button" onClick={resetTaskForm}>{text('cancel')}</button>}</div></form>
        <div className="list-heading"><h3>{locale === 'ky' ? 'Бардык тапшырмалар' : locale === 'en' ? 'All tasks' : 'Все задачи'} <span>{tasks.length}</span></h3></div>{tasks.length === 0 ? <EmptyState text={c.noTasks} /> : <div className="record-list">{[...tasks].sort((a, b) => Number(a.status === 'completed') - Number(b.status === 'completed') || b.updatedAt.localeCompare(a.updatedAt)).map((task) => <TaskCard key={task.id} task={task} onToggle={toggleTask} onEdit={(item) => { setEditingTaskId(item.id); setTaskTitle(item.title); setTaskDate(item.dueDate ?? ''); setTaskPriority(item.priority); }} onDelete={removeTask} c={c} locale={locale} />)}</div>}
      </section>}

      {screen === 'notes' && <section className="feature-page functional-page" aria-labelledby="feature-title"><div className="feature-icon" aria-hidden="true">✎</div><p className="eyebrow">{locale === 'ky' ? 'ОЙЛОР ЖАНА ИДЕЯЛАР' : locale === 'en' ? 'THOUGHTS AND IDEAS' : 'МЫСЛИ И ИДЕИ'}</p><h2 id="feature-title">{c.notesTitle}</h2><p className="feature-subtitle">{c.notesSubtitle}</p>
        <form className="editor-card" onSubmit={saveNote}><h3>{editingNoteId ? text('edit') : c.addNote}</h3><label className="field-label">{text('title')}<input value={noteTitle} onChange={(event) => setNoteTitle(event.target.value)} maxLength={160} required placeholder={locale === 'ru' ? 'Название заметки' : locale === 'ky' ? 'Белгинин аталышы' : 'Note title'} /></label><label className="field-label">{text('description')}<textarea value={noteBody} onChange={(event) => setNoteBody(event.target.value)} rows={4} maxLength={20_000} placeholder={locale === 'ru' ? 'Запиши свою мысль…' : locale === 'ky' ? 'Оюңду жаз…' : 'Write your thought…'} /></label><label className="field-label">{text('tags')}<input value={noteTags} onChange={(event) => setNoteTags(event.target.value)} maxLength={500} placeholder={locale === 'ru' ? 'учёба, идея, важно' : 'study, idea, important'} /></label><div className="form-actions"><button className="primary-action" type="submit" disabled={!repositories || busy}>{text('save')}</button>{editingNoteId && <button className="secondary-button" type="button" onClick={() => { setEditingNoteId(null); setNoteTitle(''); setNoteBody(''); setNoteTags(''); }}>{text('cancel')}</button>}</div></form>
        <label className="search-field"><span aria-hidden="true">⌕</span><input value={noteSearch} onChange={(event) => setNoteSearch(event.target.value)} placeholder={text('search')} /></label>{filteredNotes.length === 0 ? <EmptyState text={noteSearch ? text('emptySearch') : c.noNotes} /> : <div className="record-list">{filteredNotes.map((note) => <article className="record-card note-record" key={note.id}><div className="record-topline"><span className="record-date">{new Date(note.updatedAt).toLocaleDateString(dateLocale, { day: 'numeric', month: 'short' })}</span><button className={`favorite-button${note.favorite ? ' is-favorite' : ''}`} type="button" onClick={() => void toggleFavorite(note)} aria-label={note.favorite ? text('unfavorite') : text('favorite')}>{note.favorite ? '★' : '☆'}</button></div><h3>{note.title}</h3>{note.body && <p className="record-body">{note.body}</p>}{note.tags.length > 0 && <div className="tag-list">{note.tags.map((tag) => <span className="tag-pill" key={tag}>{tag}</span>)}</div>}<RecordActions onEdit={() => editNote(note)} onDelete={() => void removeNote(note)} c={c} /></article>)}</div>}
      </section>}

      {screen === 'diary' && <section className="feature-page functional-page" aria-labelledby="feature-title"><div className="feature-icon" aria-hidden="true">☾</div><p className="eyebrow">{locale === 'ky' ? 'ӨЗҮҢӨ УБАКЫТ БӨЛ' : locale === 'en' ? 'MAKE SPACE FOR YOURSELF' : 'ВРЕМЯ ДЛЯ СЕБЯ'}</p><h2 id="feature-title">{c.diaryTitle}</h2><p className="feature-subtitle">{c.diarySubtitle}</p>
        <form className="editor-card" onSubmit={saveDiaryEntry}><h3>{editingDiaryId ? text('edit') : c.writeDiary}</h3><label className="field-label">{text('date')}<input type="date" value={diaryDate} onChange={(event) => setDiaryDate(event.target.value)} required /></label><label className="field-label">{text('diaryTitleField')}<input value={diaryTitle} onChange={(event) => setDiaryTitle(event.target.value)} maxLength={160} placeholder={locale === 'ru' ? 'Как прошёл день?' : locale === 'ky' ? 'Күнүң кандай өттү?' : 'How was your day?'} /></label><label className="field-label">{text('mood')}<select value={diaryMood} onChange={(event) => setDiaryMood(event.target.value as Mood)}><option value="great">{text('great')}</option><option value="good">{text('good')}</option><option value="okay">{text('okay')}</option><option value="low">{text('lowMood')}</option><option value="difficult">{text('difficult')}</option></select></label><label className="field-label">{text('description')}<textarea value={diaryBody} onChange={(event) => setDiaryBody(event.target.value)} rows={5} maxLength={30_000} required placeholder={locale === 'ru' ? 'Что сегодня было важным? Что ты чувствуешь?' : locale === 'ky' ? 'Бүгүн эмне маанилүү болду? Эмнени сезип жатасың?' : 'What mattered today? How are you feeling?'} /></label><AttachmentPicker files={diaryFiles} locale={locale} onChange={setDiaryFiles} /><div className="form-actions"><button className="primary-action" type="submit" disabled={!repositories || busy}>{text('addEntry')}</button>{editingDiaryId && <button className="secondary-button" type="button" onClick={() => { setEditingDiaryId(null); setDiaryTitle(''); setDiaryBody(''); setDiaryDate(localDateString()); setDiaryMood('okay'); }}>{text('cancel')}</button>}</div></form>
        <div className="list-heading"><h3>{locale === 'ky' ? 'Мурунку жазуулар' : locale === 'en' ? 'Past entries' : 'Предыдущие записи'} <span>{diary.length}</span></h3></div>{diary.length === 0 ? <EmptyState text={c.noDiary} /> : <div className="record-list">{[...diary].sort((a, b) => b.date.localeCompare(a.date) || b.updatedAt.localeCompare(a.updatedAt)).map((entry) => <article className="record-card diary-record" key={entry.id}><div className="record-topline"><span className="record-date">{new Date(`${entry.date}T12:00:00`).toLocaleDateString(dateLocale, { day: 'numeric', month: 'long', year: 'numeric' })}</span>{entry.mood && <span className={`mood-pill mood-${entry.mood}`}>{moodLabel(entry.mood)}</span>}</div><h3>{entry.title}</h3><p className="record-body">{entry.body}</p>{entry.attachmentIds?.length && repositories ? <AttachmentGallery ids={entry.attachmentIds} service={repositories.attachments} locale={locale} /> : null}<RecordActions onEdit={() => editDiaryEntry(entry)} onDelete={() => void removeDiaryEntry(entry)} c={c} /></article>)}</div>}
      </section>}

      {screen === 'more' && <section className="feature-page" aria-labelledby="feature-title"><div className="feature-icon" aria-hidden="true">✧</div><p className="eyebrow">{locale === 'ky' ? 'СЕНИН МЕЙКИНДИГИҢ' : locale === 'en' ? 'YOUR PERSONAL SPACE' : 'ТВОЁ ЛИЧНОЕ ПРОСТРАНСТВО'}</p><h2 id="feature-title">{c.moreTitle}</h2><p className="feature-subtitle">{c.moreSubtitle}</p><div className="feature-list"><button className="feature-list-item" type="button" onClick={() => setScreen('projects')}><span className="list-number">01</span><span>{locale === 'ky' ? 'Долбоорлор' : locale === 'en' ? 'Projects' : 'Проекты'}</span><span className="list-arrow">↗</span></button><button className="feature-list-item" type="button" onClick={() => setScreen('habits')}><span className="list-number">02</span><span>{locale === 'ky' ? 'Адаттар жана сериялар' : locale === 'en' ? 'Habits and streaks' : 'Привычки и серии'}</span><span className="list-arrow">↗</span></button><button className="feature-list-item" type="button" onClick={() => setScreen('calendar')}><span className="list-number">03</span><span>{locale === 'ky' ? 'Календарь' : locale === 'en' ? 'Calendar' : 'Календарь'}</span><span className="list-arrow">↗</span></button><button className="feature-list-item" type="button" onClick={() => setScreen('stats')}><span className="list-number">04</span><span>{locale === 'ky' ? 'Статистика' : locale === 'en' ? 'Statistics' : 'Статистика'}</span><span className="list-arrow">↗</span></button></div><button className="secondary-action" type="button" onClick={() => setScreen('settings')}>{text('settings')} <span aria-hidden="true">→</span></button></section>}
      {screen === 'projects' && repositories && <ProjectsPanel service={repositories.projects} projects={projects} tasks={tasks} locale={locale} onRefresh={refreshData} />}
      {screen === 'habits' && repositories && <HabitsPage service={repositories.habits} habits={habits} locale={locale} onRefresh={refreshData} />}
      {screen === 'calendar' && repositories && <CalendarPage service={repositories.calendar} tasks={tasks} diaryEntries={diary} habits={habits} habitLogs={habitLogs} locale={locale} />}
      {screen === 'stats' && repositories && <StatsPage summary={repositories.statistics.summarize({ tasks, habits, habitLogs, diaryEntries: diary })} summaries={repositories.localSummaries.summarize({ tasks, notes, diaryEntries: diary, habits, habitLogs }, now)} locale={locale} />}

      {screen === 'settings' && <section className="feature-page settings-page" aria-labelledby="settings-title"><div className="feature-icon" aria-hidden="true">⚙</div><p className="eyebrow">{locale === 'ky' ? 'ЖЕКЕ ТАНДООЛОР' : locale === 'en' ? 'PERSONAL PREFERENCES' : 'ЛИЧНЫЕ ПАРАМЕТРЫ'}</p><h2 id="settings-title">{text('settings')}</h2><p className="feature-subtitle">{locale === 'ky' ? 'Колдонмону өзүңө ылайыкташтыр.' : locale === 'en' ? 'Make the app feel like yours.' : 'Настрой приложение под себя.'}</p><label className="setting-row" htmlFor="language-select"><span><strong>{text('language')}</strong><small>{locale === 'ky' ? 'Колдонмонун тили' : locale === 'en' ? 'Interface language' : 'Язык интерфейса'}</small></span><select id="language-select" value={locale} onChange={(event) => setLocale(event.target.value as Locale)}><option value="ru">Русский</option><option value="ky">Кыргызча</option><option value="en">English</option></select></label><div className="setting-row setting-static"><span><strong>{text('offline')}</strong><small>{text('offlineText')}</small></span><span className="setting-badge">{online ? (locale === 'ky' ? 'Даярдык' : locale === 'en' ? 'Available' : 'Подготовлено') : (locale === 'ky' ? 'Офлайн' : 'Offline')}</span></div><ReminderSettings locale={locale} enabled={remindersEnabled} time={dailyReminderTime} permission={notificationPermission} onToggle={() => void toggleReminders()} onTimeChange={(time) => void changeReminderTime(time)} /><div className="security-warning"><span aria-hidden="true">!</span><p>{text('security')}</p></div><div className="editor-card security-pin-card"><h3>{text('securityPinTitle')}</h3><form className="security-form" onSubmit={(event) => void submitPinChange(event)}><label className="field-label">{text('currentPinLabel')}<input type="password" value={currentPin} onChange={(event) => setCurrentPin(event.target.value)} autoComplete="current-password" minLength={6} maxLength={128} required /></label><label className="field-label">{text('newPinLabel')}<input type="password" value={newPin} onChange={(event) => setNewPin(event.target.value)} autoComplete="new-password" minLength={6} maxLength={128} required /></label><label className="field-label">{text('confirmNewPinLabel')}<input type="password" value={confirmNewPin} onChange={(event) => setConfirmNewPin(event.target.value)} autoComplete="new-password" minLength={6} maxLength={128} required /></label><button className="primary-action" type="submit" disabled={securityBusy}>{securityBusy ? (locale === 'en' ? 'Please wait…' : locale === 'ky' ? 'Күтө тур…' : 'Подожди…') : text('changePinAction')}</button></form></div><BackupPanel locale={locale} onExport={exportBackupFile} onPreview={previewBackupFile} onRestore={restoreBackupInApp} /><button className="secondary-action security-lock-action" type="button" onClick={lockSecurity}>{locale === 'ky' ? 'Колдонмону кулпулоо' : locale === 'en' ? 'Lock app' : 'Заблокировать приложение'} <span aria-hidden="true">⌑</span></button></section>}

      <nav className="bottom-nav" aria-label={locale === 'ky' ? 'Негизги навигация' : locale === 'en' ? 'Main navigation' : 'Основная навигация'}>{navigation.map((item) => <button className={`nav-item${screen === item.id ? ' is-active' : ''}`} key={item.id} type="button" onClick={() => setScreen(item.id)} aria-current={screen === item.id ? 'page' : undefined}><span className="nav-icon" aria-hidden="true">{item.icon}</span><span>{t(locale, item.key)}</span></button>)}</nav>
    </main>
  );
}

function TaskCard({ task, onToggle, onEdit, onDelete, c, locale }: { task: Task; onToggle: (task: Task) => void | Promise<void>; onEdit: (task: Task) => void; onDelete: (task: Task) => void | Promise<void>; c: CopyText; locale: Locale }) {
  const done = task.status === 'completed';
  return <article className={`record-card task-record${done ? ' is-completed' : ''}`}><button className="task-check" type="button" onClick={() => void onToggle(task)} aria-label={done ? c.reopen : c.complete} aria-pressed={done}>{done ? '✓' : ''}</button><div className="task-content"><h3>{task.title}</h3><div className="record-meta">{task.dueDate && <span>{new Date(`${task.dueDate}T12:00:00`).toLocaleDateString(locale === 'ky' ? 'ky-KG' : locale === 'en' ? 'en-US' : 'ru-RU', { day: 'numeric', month: 'short' })}</span>}<span className={`priority-pill priority-${task.priority}`}>{task.priority === 'high' ? c.high : task.priority === 'low' ? c.low : c.medium}</span><span>{done ? c.completed : c.planned}</span></div></div><div className="record-actions compact-actions"><button type="button" onClick={() => onEdit(task)} aria-label={c.edit}>✎</button><button type="button" onClick={() => void onDelete(task)} aria-label={c.delete}>×</button></div></article>;
}
function RecordActions({ onEdit, onDelete, c }: { onEdit: () => void; onDelete: () => void; c: CopyText }) {
  return <div className="record-actions"><button type="button" onClick={onEdit}>{c.edit}</button><button type="button" onClick={onDelete}>{c.delete}</button></div>;
}
function EmptyState({ text }: { text: string }) { return <div className="empty-state"><span aria-hidden="true">✧</span><p>{text}</p></div>; }
