export async function registerServiceWorker(): Promise<void> {
  if (!('serviceWorker' in navigator)) return;
  if (import.meta.env.DEV) return;
  try {
    await navigator.serviceWorker.register('/sw.js', { scope: '/' });
  } catch (error) {
    // PWA installation is progressive enhancement: the app remains usable if registration fails.
    console.warn('Менин күнүм: offline support could not be registered.', error);
  }
}
