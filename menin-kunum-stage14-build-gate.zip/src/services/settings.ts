import type { AppSettings, Locale } from '../domain/models.ts';
import type { RecordStore } from '../storage/repositories/base.ts';

export interface StoredSettings extends AppSettings { id: 'app-settings'; }
export type SettingsPatch = Partial<Omit<StoredSettings, 'id' | 'schemaVersion'>>;
export const DEFAULT_SETTINGS: StoredSettings = {
  id: 'app-settings', locale: 'ru', autoLockMinutes: 0, hideNotificationContent: true,
  remindersEnabled: false, dailyReminderTime: '20:00', schemaVersion: 1,
};
const locales = new Set<Locale>(['ru', 'ky', 'en']);
const isTime = (value: unknown): value is string => typeof value === 'string' && /^(?:[01]\d|2[0-3]):[0-5]\d$/.test(value);

export function createSettingsService(store: RecordStore<StoredSettings>) {
  async function get(): Promise<StoredSettings> {
    const stored = await store.get('app-settings');
    if (!stored) return { ...DEFAULT_SETTINGS };
    return {
      ...DEFAULT_SETTINGS,
      ...stored,
      id: 'app-settings',
      autoLockMinutes: 0,
      hideNotificationContent: true,
      locale: locales.has(stored.locale) ? stored.locale : 'ru',
      remindersEnabled: stored.remindersEnabled === true,
      dailyReminderTime: isTime(stored.dailyReminderTime) ? stored.dailyReminderTime : DEFAULT_SETTINGS.dailyReminderTime,
      schemaVersion: 1,
    };
  }

  async function update(patch: SettingsPatch): Promise<StoredSettings> {
    if (patch.locale !== undefined && !locales.has(patch.locale)) throw new Error('Invalid locale setting.');
    if (patch.remindersEnabled !== undefined && typeof patch.remindersEnabled !== 'boolean') throw new Error('Invalid reminders setting.');
    if (patch.dailyReminderTime !== undefined && !isTime(patch.dailyReminderTime)) throw new Error('Invalid reminder time. Use HH:mm.');
    const existing = await store.get('app-settings');
    const next: StoredSettings = { ...(await get()), ...patch, id: 'app-settings', autoLockMinutes: 0, hideNotificationContent: true, schemaVersion: 1 };
    if (existing) await store.put(next); else await store.add(next);
    return next;
  }
  return { get, update };
}
