import type { RecordRepository } from '../storage/repositories/base.ts';
import { StorageError } from '../storage/errors.ts';

export interface ServiceOptions {
  createId?: () => string;
  now?: () => Date;
}

export function serviceOptions(options: ServiceOptions = {}) {
  return {
    createId: options.createId ?? (() => typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`),
    now: options.now ?? (() => new Date()),
  };
}

export function timestamp(now: () => Date): string {
  const value = now();
  if (!(value instanceof Date) || Number.isNaN(value.getTime())) {
    throw new StorageError('STORAGE_OPERATION_FAILED', 'Часы приложения вернули некорректное время.');
  }
  return value.toISOString();
}

export function requiredTitle(value: unknown): string {
  if (typeof value !== 'string' || !value.trim()) {
    throw new StorageError('STORAGE_OPERATION_FAILED', 'Название обязательно.');
  }
  return value.trim();
}

export function requiredText(value: unknown, field = 'Текст'): string {
  if (typeof value !== 'string' || !value.trim()) {
    throw new StorageError('STORAGE_OPERATION_FAILED', `${field} не может быть пустым.`);
  }
  return value.trim();
}

export function validateDate(value: unknown): string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/u.test(value)) {
    throw new StorageError('STORAGE_OPERATION_FAILED', 'Укажи корректную дату в формате ГГГГ-ММ-ДД.');
  }
  const [year, month, day] = value.split('-').map(Number);
  const parsed = new Date(Date.UTC(year, month - 1, day));
  if (parsed.getUTCFullYear() !== year || parsed.getUTCMonth() !== month - 1 || parsed.getUTCDate() !== day) {
    throw new StorageError('STORAGE_OPERATION_FAILED', 'Укажи существующую календарную дату.');
  }
  return value;
}

export async function requireRecord<T extends { id: string }>(repository: RecordRepository<T>, id: string): Promise<T> {
  const record = await repository.getById(id);
  if (!record) throw new StorageError('NOT_FOUND', 'Запись не найдена.');
  return record;
}

export function normalizeTags(tags: unknown): string[] {
  if (tags === undefined) return [];
  if (!Array.isArray(tags) || tags.some((tag) => typeof tag !== 'string')) {
    throw new StorageError('STORAGE_OPERATION_FAILED', 'Теги должны быть списком текстовых значений.');
  }
  const unique = new Map<string, string>();
  for (const tag of tags) {
    const trimmed = tag.trim();
    if (trimmed) unique.set(trimmed.toLocaleLowerCase(), trimmed);
  }
  return [...unique.values()];
}
