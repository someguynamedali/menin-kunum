import type { Locale } from '../domain/models.ts';

export type ReminderPermission = 'default' | 'granted' | 'denied' | 'unsupported';
export interface NotificationPermissionApi { permission: 'default' | 'granted' | 'denied'; requestPermission(): Promise<'default' | 'granted' | 'denied'>; }
export interface ReminderNotice { title: string; body: string; tag: string; }
interface ReminderDependencies {
  now?: () => Date;
  scheduleTimeout?: (callback: () => void, delayMs: number) => unknown;
  clearTimeout?: (timer: unknown) => void;
  notify?: (notice: ReminderNotice) => Promise<void> | void;
}
interface ScheduleOptions { enabled: boolean; permission: ReminderPermission; time: string; locale: Locale; }

export async function requestReminderPermission(api: NotificationPermissionApi | undefined = globalNotificationApi()): Promise<ReminderPermission> {
  if (!api) return 'unsupported';
  if (api.permission !== 'default') return api.permission;
  try { return await api.requestPermission(); } catch { return 'denied'; }
}

function globalNotificationApi(): NotificationPermissionApi | undefined {
  return typeof Notification === 'undefined' ? undefined : Notification;
}

function noticeFor(locale: Locale, date: Date): ReminderNotice {
  const text = locale === 'ky'
    ? { title: 'Менин күнүм', body: 'Пландарыңа жана жазууларыңа бир мүнөт бөл.' }
    : locale === 'en' ? { title: 'Menin Kunum', body: 'Take a quiet minute for your plans and reflections.' }
      : { title: 'Менин күнүм', body: 'Удели минуту своим планам и мыслям.' };
  return { ...text, tag: `menin-kunum-reminder-${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}` };
}

async function showBrowserNotification(notice: ReminderNotice): Promise<void> {
  let shown = false;
  try {
    if (typeof navigator !== 'undefined' && 'serviceWorker' in navigator && navigator.serviceWorker.controller) {
      const registration = await navigator.serviceWorker.ready;
      if (registration.showNotification) { await registration.showNotification(notice.title, { body: notice.body, tag: notice.tag, icon: '/icons/app-icon.svg', badge: '/icons/app-icon.svg' }); shown = true; }
    }
  } catch { /* Try the standard Notification API if the service worker is unavailable. */ }
  if (!shown && typeof Notification !== 'undefined') new Notification(notice.title, { body: notice.body, tag: notice.tag });
}

export function createReminderService(dependencies: ReminderDependencies = {}) {
  const now = dependencies.now ?? (() => new Date());
  const scheduleTimeout = dependencies.scheduleTimeout ?? ((callback, delay) => window.setTimeout(callback, delay));
  const clearTimeout = dependencies.clearTimeout ?? ((timer) => window.clearTimeout(timer as number));
  const notify = dependencies.notify ?? showBrowserNotification;

  function schedule(options: ScheduleOptions): () => void {
    if (!options.enabled || options.permission !== 'granted' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(options.time)) return () => undefined;
    let cancelled = false;
    let timer: unknown;
    const scheduleNext = () => {
      const current = now();
      const [hours, minutes] = options.time.split(':').map(Number);
      const target = new Date(current); target.setHours(hours, minutes, 0, 0);
      if (target.getTime() <= current.getTime()) target.setDate(target.getDate() + 1);
      const targetTime = target.getTime();
      timer = scheduleTimeout(() => {
        void (async () => {
          if (cancelled) return;
          const currentTime = now().getTime();
          if (currentTime >= targetTime && currentTime - targetTime < 15 * 60 * 1000) {
            try { await notify(noticeFor(options.locale, target)); } catch { /* A failed notification must not affect app data. */ }
          }
          if (!cancelled) scheduleNext();
        })();
      }, Math.max(0, targetTime - current.getTime()));
    };
    scheduleNext();
    return () => { cancelled = true; if (timer !== undefined) clearTimeout(timer); };
  }
  return { schedule, requestPermission: requestReminderPermission };
}
