import type { AttachmentMetadata } from '../domain/models.ts';
import { decodeBase64Url, encodeBase64Url, encryptPayload, decryptPayload, type EncryptedPayload } from '../security/crypto.ts';
import type { RecordStore } from '../storage/repositories/base.ts';

export const MAX_ATTACHMENT_SIZE_BYTES = 5 * 1024 * 1024;
export const MAX_TOTAL_ATTACHMENT_BYTES = 10 * 1024 * 1024;
export const MAX_ATTACHMENT_COUNT = 50;
export const ALLOWED_ATTACHMENT_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'text/plain', 'application/pdf'] as const;
const allowedTypes = new Set<string>(ALLOWED_ATTACHMENT_TYPES);

export interface AttachmentFileLike {
  name?: string;
  type: string;
  size: number;
  arrayBuffer(): Promise<ArrayBuffer>;
}
export interface EncryptedAttachmentRecord extends AttachmentMetadata {
  encryptedContent: EncryptedPayload;
}
export interface AttachmentBackupRecord extends AttachmentMetadata {
  contentBase64: string;
}
export interface AttachmentServiceOptions {
  createId?: () => string;
  now?: () => Date;
}

export function createAttachmentsService(
  store: RecordStore<EncryptedAttachmentRecord>,
  getDataKey: () => CryptoKey,
  options: AttachmentServiceOptions = {},
) {
  const createId = options.createId ?? (() => globalThis.crypto.randomUUID());
  const now = options.now ?? (() => new Date());
  const aadFor = (id: string) => `menin-kunum:attachment:v1:${id}`;

  async function addFile(file: AttachmentFileLike): Promise<AttachmentMetadata> {
    if (!file || typeof file.type !== 'string' || !allowedTypes.has(file.type.toLowerCase())) {
      throw new Error('Тип файла не поддерживается. Используй JPG, PNG, WebP, TXT или PDF.');
    }
    if (!Number.isSafeInteger(file.size) || file.size <= 0 || file.size > MAX_ATTACHMENT_SIZE_BYTES) {
      throw new Error('Размер вложения должен быть от 1 байта до 5 МБ.');
    }
    const existingAttachments = await store.getAll();
    if (existingAttachments.length >= MAX_ATTACHMENT_COUNT) throw new Error('В этой версии можно хранить не более 50 вложений.');
    const existingBytes = existingAttachments.reduce((total, item) => total + item.sizeBytes, 0);
    if (existingBytes + file.size > MAX_TOTAL_ATTACHMENT_BYTES) throw new Error('Общий размер вложений в этой версии ограничен 10 МБ, чтобы приложение не тормозило на телефоне.');
    const bytes = new Uint8Array(await file.arrayBuffer());
    if (bytes.byteLength !== file.size) { bytes.fill(0); throw new Error('Размер файла изменился во время чтения.'); }
    const id = createId();
    const createdAt = now().toISOString();
    try {
      const encoded = encodeBase64Url(bytes);
      const encryptedContent = await encryptPayload(encoded, getDataKey(), aadFor(id));
      await store.add({ id, mimeType: file.type.toLowerCase(), sizeBytes: bytes.byteLength, createdAt, encryptedContent });
      return { id, mimeType: file.type.toLowerCase(), sizeBytes: bytes.byteLength, createdAt };
    } finally { bytes.fill(0); }
  }

  async function readBlob(id: string): Promise<Blob> {
    const record = await store.get(id);
    if (!record) throw new Error('Вложение не найдено.');
    if (!allowedTypes.has(record.mimeType) || !Number.isSafeInteger(record.sizeBytes) || record.sizeBytes <= 0 || record.sizeBytes > MAX_ATTACHMENT_SIZE_BYTES) throw new Error('Метаданные вложения повреждены.');
    const encoded = await decryptPayload(record.encryptedContent, getDataKey(), aadFor(id));
    const bytes = decodeBase64Url(encoded);
    if (bytes.byteLength !== record.sizeBytes) { bytes.fill(0); throw new Error('Размер расшифрованного вложения не совпадает.'); }
    try { return new Blob([bytes], { type: record.mimeType }); }
    finally { bytes.fill(0); }
  }

  async function list(): Promise<AttachmentMetadata[]> {
    return (await store.getAll()).map(({ id, mimeType, sizeBytes, createdAt }) => ({ id, mimeType, sizeBytes, createdAt }));
  }

  async function remove(id: string): Promise<void> {
    const existing = await store.get(id);
    if (!existing) throw new Error('Вложение не найдено.');
    await store.delete(id);
  }

  async function exportForBackup(): Promise<AttachmentBackupRecord[]> {
    const records = await store.getAll();
    const output: AttachmentBackupRecord[] = [];
    for (const record of records) {
      const encoded = await decryptPayload(record.encryptedContent, getDataKey(), aadFor(record.id));
      const bytes = decodeBase64Url(encoded);
      try {
        if (bytes.byteLength !== record.sizeBytes) throw new Error('Размер вложения не совпадает.');
        output.push({ id: record.id, mimeType: record.mimeType, sizeBytes: record.sizeBytes, createdAt: record.createdAt, contentBase64: encoded });
      } finally { bytes.fill(0); }
    }
    return output;
  }

  return { addFile, readBlob, list, remove, exportForBackup };
}
