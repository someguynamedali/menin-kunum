import type { DiaryEntry, Mood } from '../domain/models.ts';
import type { RecordRepository } from '../storage/repositories/base.ts';
import { StorageError } from '../storage/errors.ts';
import { normalizeTags, requireRecord, requiredText, serviceOptions, timestamp, validateDate, type ServiceOptions } from './common.ts';

export type NewDiaryEntry = Pick<DiaryEntry, 'date' | 'body'> & Partial<Pick<DiaryEntry, 'title' | 'mood' | 'goodThings' | 'concerns' | 'gratitude' | 'tags' | 'attachmentIds'>>;
export type DiaryChanges = Partial<Pick<DiaryEntry, 'date' | 'title' | 'body' | 'mood' | 'goodThings' | 'concerns' | 'gratitude' | 'tags' | 'attachmentIds'>>;
const moods: Mood[] = ['great', 'good', 'okay', 'low', 'difficult'];
const normalizeStringList = (value: unknown, field: string): string[] => {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.some((item) => typeof item !== 'string')) throw new StorageError('STORAGE_OPERATION_FAILED', `${field} должен быть списком текстовых значений.`);
  return value.map((item: string) => item.trim()).filter(Boolean);
};

export function createDiaryService(repository: RecordRepository<DiaryEntry>, options: ServiceOptions = {}) {
  const deps = serviceOptions(options);
  return {
    async create(input: NewDiaryEntry): Promise<DiaryEntry> {
      const date = validateDate(input.date);
      const body = requiredText(input.body, 'Текст дневника');
      if (input.mood !== undefined && !moods.includes(input.mood)) throw new StorageError('STORAGE_OPERATION_FAILED', 'Некорректное настроение.');
      const stamp = timestamp(deps.now);
      const entry: DiaryEntry = {
        id: deps.createId(), date, title: typeof input.title === 'string' ? input.title.trim() : '', body,
        ...(input.mood ? { mood: input.mood } : {}), goodThings: normalizeStringList(input.goodThings, 'Хорошее'),
        concerns: normalizeStringList(input.concerns, 'Тревоги'), gratitude: normalizeStringList(input.gratitude, 'Благодарность'),
        tags: normalizeTags(input.tags), attachmentIds: normalizeStringList(input.attachmentIds, 'Вложения'),
        createdAt: stamp, updatedAt: stamp,
      };
      return repository.create(entry);
    },
    async update(id: string, changes: DiaryChanges): Promise<DiaryEntry> {
      const existing = await requireRecord(repository, id);
      const next: DiaryEntry = { ...existing, ...changes, id: existing.id, createdAt: existing.createdAt, updatedAt: timestamp(deps.now) };
      next.date = validateDate(next.date);
      next.title = typeof next.title === 'string' ? next.title.trim() : '';
      next.body = requiredText(next.body, 'Текст дневника');
      if (next.mood !== undefined && !moods.includes(next.mood)) throw new StorageError('STORAGE_OPERATION_FAILED', 'Некорректное настроение.');
      next.goodThings = normalizeStringList(next.goodThings, 'Хорошее');
      next.concerns = normalizeStringList(next.concerns, 'Тревоги');
      next.gratitude = normalizeStringList(next.gratitude, 'Благодарность');
      next.tags = normalizeTags(next.tags);
      next.attachmentIds = normalizeStringList(next.attachmentIds, 'Вложения');
      return repository.update(next);
    },
    async remove(id: string): Promise<void> { await repository.delete(id); },
    async list(): Promise<DiaryEntry[]> { return (await repository.list()).sort((a, b) => b.date.localeCompare(a.date) || b.updatedAt.localeCompare(a.updatedAt)); },
    async search(query: string): Promise<DiaryEntry[]> {
      const normalized = query.trim().toLocaleLowerCase();
      const all = await repository.list();
      if (!normalized) return all;
      return all.filter((entry) => `${entry.date} ${entry.title} ${entry.body} ${entry.mood ?? ''} ${entry.tags.join(' ')}`.toLocaleLowerCase().includes(normalized));
    },
  };
}
