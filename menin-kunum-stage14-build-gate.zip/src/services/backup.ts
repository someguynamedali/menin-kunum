import { decodeBase64Url, encodeBase64Url, encryptPayload, decryptPayload, randomBytes, type EncryptedPayload } from '../security/crypto.ts';
import { prepareContentRecordsForEncryption, type LegacyContentRecord } from '../security/migration.ts';
import type { StoreName } from '../storage/db.ts';

export const BACKUP_FORMAT = 'menin-kunum-encrypted-backup' as const;
export const BACKUP_VERSION = 1 as const;
const BACKUP_AAD = 'menin-kunum:backup:v1';
const DEFAULT_ITERATIONS = 600_000;
const MAX_ITERATIONS = 2_000_000;
const MIN_PRODUCTION_ITERATIONS = 300_000;
const MAX_BACKUP_BYTES = 30 * 1024 * 1024;
const MAX_PLAINTEXT_BYTES = 20 * 1024 * 1024;
const MAX_RECORDS = 100_000;
const MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024;
const BACKUP_STORE_NAMES = ['tasks', 'projects', 'notes', 'diaryEntries', 'habits', 'habitLogs', 'attachments'] as const;
export type BackupStoreName = (typeof BACKUP_STORE_NAMES)[number];
export type BackupRecord = Record<string, unknown> & { id: string };
export type BackupRecords = Record<BackupStoreName, BackupRecord[]>;
export type BackupRecordsInput = Record<BackupStoreName, unknown[]>;
export interface BackupSnapshot { schemaVersion: 1; exportedAt: string; records: BackupRecordsInput; }
export interface ValidatedBackupSnapshot extends BackupSnapshot { records: BackupRecords; }
export interface BackupCounts extends Record<BackupStoreName, number> {}
export interface BackupPreview { metadata: { format: typeof BACKUP_FORMAT; version: 1; createdAt: string; schemaVersion: 1; counts: BackupCounts }; snapshot: ValidatedBackupSnapshot; }
export interface BackupCryptoOptions { /** Test/benchmark override only. Production uses 600,000 iterations. */ iterations?: number; }
export interface BackupStorageAdapter { replaceAtomically(records: BackupRecords, dataKey: CryptoKey): Promise<void>; }

interface BackupEnvelope {
  format: typeof BACKUP_FORMAT;
  version: typeof BACKUP_VERSION;
  schemaVersion: 1;
  createdAt: string;
  kdf: { algorithm: 'PBKDF2-HMAC-SHA-256'; salt: string; iterations: number };
  payload: EncryptedPayload;
}

const allowedFields: Record<BackupStoreName, ReadonlySet<string>> = {
  tasks: new Set(['id', 'title', 'description', 'dueDate', 'dueTime', 'category', 'priority', 'status', 'recurringRule', 'estimatedMinutes', 'actualMinutes', 'dependencyIds', 'projectId', 'subtasks', 'createdAt', 'updatedAt']),
  projects: new Set(['id', 'title', 'description', 'taskIds', 'createdAt', 'updatedAt']),
  notes: new Set(['id', 'title', 'body', 'tags', 'favorite', 'createdAt', 'updatedAt']),
  diaryEntries: new Set(['id', 'date', 'title', 'body', 'mood', 'goodThings', 'concerns', 'gratitude', 'tags', 'attachmentIds', 'createdAt', 'updatedAt']),
  habits: new Set(['id', 'title', 'measure', 'targetValue', 'targetPeriod', 'reminderTime', 'createdAt', 'updatedAt']),
  habitLogs: new Set(['id', 'habitId', 'date', 'value']),
  attachments: new Set(['id', 'mimeType', 'sizeBytes', 'createdAt', 'contentBase64']),
};
const allowedMimes = new Set(['image/jpeg', 'image/png', 'image/webp', 'text/plain', 'application/pdf']);

function webCrypto(): Crypto {
  if (!globalThis.crypto?.subtle) throw new Error('Web Crypto is unavailable in this environment.');
  return globalThis.crypto;
}
function validatePassphrase(passphrase: string): void {
  if (typeof passphrase !== 'string' || passphrase.length < 12 || passphrase.length > 1024) {
    throw new Error('Пароль резервной копии должен содержать от 12 до 1024 символов.');
  }
}
async function deriveBackupKey(passphrase: string, salt: Uint8Array, iterations: number): Promise<CryptoKey> {
  validatePassphrase(passphrase);
  const passphraseBytes = new TextEncoder().encode(passphrase);
  try {
    const material = await webCrypto().subtle.importKey('raw', passphraseBytes, 'PBKDF2', false, ['deriveKey']);
    return await webCrypto().subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, material, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  } finally { passphraseBytes.fill(0); }
}
function isPlainRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value) && (Object.getPrototypeOf(value) === Object.prototype || Object.getPrototypeOf(value) === null);
}
function isStringArray(value: unknown, maxItems = 10_000, maxLength = 200): value is string[] {
  return Array.isArray(value) && value.length <= maxItems && value.every((item) => typeof item === 'string' && item.length <= maxLength);
}
function requiredString(record: Record<string, unknown>, field: string, maxLength: number, allowEmpty = true): void {
  const value = record[field];
  if (typeof value !== 'string' || value.length > maxLength || (!allowEmpty && !value.trim())) throw new Error(`Поле ${field} имеет некорректный формат.`);
}
function optionalString(record: Record<string, unknown>, field: string, maxLength: number): void {
  if (record[field] !== undefined && (typeof record[field] !== 'string' || (record[field] as string).length > maxLength)) throw new Error(`Поле ${field} имеет некорректный формат.`);
}
function validIsoDate(value: unknown): value is string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T00:00:00.000Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}
function validTimestamp(value: unknown): value is string {
  return typeof value === 'string' && value.length <= 64 && Number.isFinite(Date.parse(value));
}
function optionalNonNegativeNumber(record: Record<string, unknown>, field: string): void {
  if (record[field] !== undefined && (typeof record[field] !== 'number' || !Number.isFinite(record[field]) || record[field] < 0)) throw new Error(`Поле ${field} должно быть неотрицательным числом.`);
}
function optionalId(record: Record<string, unknown>, field: string): void {
  if (record[field] !== undefined && (typeof record[field] !== 'string' || !(record[field] as string).trim() || (record[field] as string).length > 200)) throw new Error(`Поле ${field} имеет некорректный идентификатор.`);
}
function validateRecord(storeName: BackupStoreName, record: unknown): BackupRecord {
  if (!isPlainRecord(record) || typeof record.id !== 'string' || !record.id.trim() || record.id.length > 200) throw new Error(`Некорректный идентификатор записи в ${storeName}.`);
  for (const field of Object.keys(record)) if (!allowedFields[storeName].has(field)) throw new Error(`Неизвестное поле ${field} в резервной копии (${storeName}).`);
  const requiredFields = storeName === 'notes' ? ['title', 'body', 'createdAt', 'updatedAt']
    : storeName === 'diaryEntries' ? ['date', 'title', 'body', 'createdAt', 'updatedAt']
    : storeName === 'tasks' || storeName === 'projects' || storeName === 'habits' ? ['title', 'createdAt', 'updatedAt']
    : storeName === 'habitLogs' ? ['habitId', 'date']
    : storeName === 'attachments' ? ['mimeType', 'createdAt', 'contentBase64'] : [];
  for (const field of requiredFields) if (typeof record[field] !== 'string') throw new Error(`Поле ${field} в ${storeName} должно быть текстом.`);

  if (['tasks', 'projects', 'habits', 'notes', 'diaryEntries'].includes(storeName)) {
    requiredString(record, 'title', 160, false);
    requiredString(record, 'createdAt', 64, false);
    requiredString(record, 'updatedAt', 64, false);
    if (!validTimestamp(record.createdAt) || !validTimestamp(record.updatedAt)) throw new Error(`Даты записи в ${storeName} имеют некорректный формат.`);
  }
  if (storeName === 'notes' || storeName === 'diaryEntries') {
    requiredString(record, 'body', storeName === 'notes' ? 20_000 : 30_000);
    if (!isStringArray(record.tags, 100, 100)) throw new Error(`Теги в ${storeName} имеют некорректный формат.`);
  }
  if (storeName === 'notes' && typeof record.favorite !== 'boolean') throw new Error('Флаг избранного в заметке имеет некорректный формат.');
  if (storeName === 'diaryEntries') {
    if (!validIsoDate(record.date)) throw new Error('Дата дневника имеет некорректный формат.');
    if (record.mood !== undefined && !['great', 'good', 'okay', 'low', 'difficult'].includes(String(record.mood))) throw new Error('Настроение в дневнике имеет некорректный формат.');
    for (const field of ['goodThings', 'concerns', 'gratitude']) if (record[field] !== undefined && !isStringArray(record[field], 500, 2_000)) throw new Error(`Поле ${field} в дневнике имеет некорректный формат.`);
    if (record.attachmentIds !== undefined && !isStringArray(record.attachmentIds, 50, 200)) throw new Error('Список вложений в дневнике имеет некорректный формат.');
  }
  if (storeName === 'tasks') {
    optionalString(record, 'description', 20_000); optionalString(record, 'category', 100); optionalId(record, 'projectId');
    if (record.dueDate !== undefined && record.dueDate !== '' && !validIsoDate(record.dueDate)) throw new Error('Срок задачи имеет некорректный формат.');
    if (record.dueTime !== undefined && (typeof record.dueTime !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(record.dueTime))) throw new Error('Время задачи имеет некорректный формат.');
    if (!['low', 'medium', 'high'].includes(String(record.priority)) || !['planned', 'completed', 'deferred'].includes(String(record.status)) || !isStringArray(record.dependencyIds, 10_000, 200)) throw new Error('Задача имеет некорректный формат.');
    optionalNonNegativeNumber(record, 'estimatedMinutes'); optionalNonNegativeNumber(record, 'actualMinutes');
    if (record.recurringRule !== undefined) {
      const rule = record.recurringRule;
      if (!isPlainRecord(rule) || Object.keys(rule).some((key) => key !== 'weekdays') || !Array.isArray(rule.weekdays) || rule.weekdays.length > 7 || !rule.weekdays.every((day) => Number.isInteger(day) && day >= 0 && day <= 6)) throw new Error('Повторение задачи имеет некорректный формат.');
    }
    if (record.subtasks !== undefined) {
      if (!Array.isArray(record.subtasks) || record.subtasks.length > 500) throw new Error('Подзадачи имеют некорректный формат.');
      for (const subtask of record.subtasks) {
        if (!isPlainRecord(subtask) || Object.keys(subtask).some((key) => !['id', 'parentTaskId', 'title', 'completed'].includes(key)) || typeof subtask.id !== 'string' || !subtask.id.trim() || subtask.id.length > 200 || typeof subtask.parentTaskId !== 'string' || subtask.parentTaskId !== record.id || typeof subtask.title !== 'string' || !subtask.title.trim() || subtask.title.length > 160 || typeof subtask.completed !== 'boolean') throw new Error('Подзадача имеет некорректный формат.');
      }
    }
  }
  if (storeName === 'projects') {
    optionalString(record, 'description', 20_000);
    if (!isStringArray(record.taskIds, 10_000, 200)) throw new Error('Список задач проекта имеет некорректный формат.');
  }
  if (storeName === 'habits') {
    optionalString(record, 'reminderTime', 5);
    if (record.reminderTime !== undefined && !/^([01]\d|2[0-3]):[0-5]\d$/.test(String(record.reminderTime))) throw new Error('Время напоминания привычки имеет некорректный формат.');
    if (!['checkbox', 'minutes', 'pages', 'repetitions'].includes(String(record.measure)) || !['daily', 'weekly'].includes(String(record.targetPeriod)) || typeof record.targetValue !== 'number' || !Number.isFinite(record.targetValue) || record.targetValue <= 0 || (record.measure === 'checkbox' && record.targetValue !== 1)) throw new Error('Привычка имеет некорректный формат.');
  }
  if (storeName === 'habitLogs') {
    if (typeof record.habitId !== 'string' || !record.habitId.trim() || record.habitId.length > 200 || !validIsoDate(record.date)) throw new Error('Запись прогресса привычки имеет некорректный формат.');
    if (typeof record.value !== 'number' || !Number.isFinite(record.value) || record.value < 0 || record.value > 1_000_000) throw new Error('Прогресс привычки имеет некорректный формат.');
  }
  if (storeName === 'attachments') {
    if (!allowedMimes.has(String(record.mimeType)) || typeof record.sizeBytes !== 'number' || !Number.isInteger(record.sizeBytes) || record.sizeBytes <= 0 || record.sizeBytes > MAX_ATTACHMENT_BYTES || typeof record.contentBase64 !== 'string') throw new Error('Вложение имеет неподдерживаемый тип или размер.');
    if (!validTimestamp(record.createdAt)) throw new Error('Дата вложения имеет некорректный формат.');
    if (record.contentBase64.length > Math.ceil(MAX_ATTACHMENT_BYTES * 4 / 3) + 4) throw new Error('Содержимое вложения превышает допустимый размер.');
    const bytes = decodeBase64Url(record.contentBase64);
    try { if (bytes.byteLength !== record.sizeBytes) throw new Error('Размер вложения не совпадает с содержимым.'); }
    finally { bytes.fill(0); }
  }
  return record as BackupRecord;
}

function validateBackupReferences(records: BackupRecords): void {
  const taskIds = new Set(records.tasks.map((record) => record.id));
  const projectIds = new Set(records.projects.map((record) => record.id));
  const habitIds = new Set(records.habits.map((record) => record.id));
  const attachmentIds = new Set(records.attachments.map((record) => record.id));
  const tasksById = new Map(records.tasks.map((record) => [record.id, record]));
  for (const task of records.tasks) {
    const dependencies = task.dependencyIds as string[];
    if (dependencies.includes(task.id) || dependencies.some((id) => !taskIds.has(id))) throw new Error(`Задача ${task.id} ссылается на отсутствующую или саму себя.`);
    if (task.projectId !== undefined && !projectIds.has(String(task.projectId))) throw new Error(`Задача ${task.id} ссылается на отсутствующий проект.`);
    const subtasks = (task.subtasks ?? []) as Array<Record<string, unknown>>;
    const subtaskIds = new Set<string>();
    for (const subtask of subtasks) {
      const id = String(subtask.id);
      if (subtaskIds.has(id)) throw new Error(`В задаче ${task.id} повторяется идентификатор подзадачи.`);
      subtaskIds.add(id);
    }
  }
  // Reject dependency cycles before the imported graph reaches the task UI/services.
  const visiting = new Set<string>();
  const visited = new Set<string>();
  for (const rootId of taskIds) {
    if (visited.has(rootId)) continue;
    const stack: Array<{ id: string; exiting: boolean }> = [{ id: rootId, exiting: false }];
    while (stack.length) {
      const frame = stack.pop()!;
      if (frame.exiting) {
        visiting.delete(frame.id);
        visited.add(frame.id);
        continue;
      }
      if (visited.has(frame.id)) continue;
      if (visiting.has(frame.id)) throw new Error('В резервной копии обнаружен цикл зависимостей задач.');
      visiting.add(frame.id);
      stack.push({ id: frame.id, exiting: true });
      const task = tasksById.get(frame.id)!;
      for (const dependencyId of task.dependencyIds as string[]) {
        if (visiting.has(dependencyId)) throw new Error('В резервной копии обнаружен цикл зависимостей задач.');
        if (!visited.has(dependencyId)) stack.push({ id: dependencyId, exiting: false });
      }
    }
  }
  for (const project of records.projects) {
    const ids = project.taskIds as string[];
    if (ids.some((id) => !taskIds.has(id))) throw new Error(`Проект ${project.id} ссылается на отсутствующую задачу.`);
  }
  for (const log of records.habitLogs) if (!habitIds.has(String(log.habitId))) throw new Error(`Запись прогресса ${log.id} ссылается на отсутствующую привычку.`);
  for (const entry of records.diaryEntries) {
    const ids = (entry.attachmentIds ?? []) as string[];
    if (ids.some((id) => !attachmentIds.has(id))) throw new Error(`Запись дневника ${entry.id} ссылается на отсутствующее вложение.`);
  }
}

export function validateBackupSnapshot(value: unknown): ValidatedBackupSnapshot {
  if (!isPlainRecord(value) || value.schemaVersion !== 1 || typeof value.exportedAt !== 'string' || !Number.isFinite(Date.parse(value.exportedAt)) || !isPlainRecord(value.records)) {
    throw new Error('Файл резервной копии имеет неподдерживаемую структуру.');
  }
  if (Object.keys(value).some((field) => !['schemaVersion', 'exportedAt', 'records'].includes(field))) throw new Error('В резервной копии обнаружены неизвестные поля верхнего уровня.');
  const records = value.records as Record<string, unknown>;
  for (const storeName of BACKUP_STORE_NAMES) if (!Array.isArray(records[storeName])) throw new Error(`В резервной копии отсутствует список ${storeName}.`);
  for (const storeName of Object.keys(records)) if (!BACKUP_STORE_NAMES.includes(storeName as BackupStoreName)) throw new Error(`Неизвестный раздел резервной копии: ${storeName}.`);
  let total = 0;
  const cleanRecords = {} as BackupRecords;
  for (const storeName of BACKUP_STORE_NAMES) {
    const rawRecords = records[storeName] as unknown[];
    total += rawRecords.length;
    if (total > MAX_RECORDS) throw new Error('В резервной копии слишком много записей.');
    const seen = new Set<string>();
    cleanRecords[storeName] = rawRecords.map((record) => {
      const valid = validateRecord(storeName, record);
      if (seen.has(valid.id)) throw new Error(`Повторяющийся идентификатор ${valid.id} в ${storeName}.`);
      seen.add(valid.id);
      return valid;
    });
  }
  validateBackupReferences(cleanRecords);
  return { schemaVersion: 1, exportedAt: value.exportedAt, records: cleanRecords };
}

function countsFor(records: BackupRecords): BackupCounts {
  return Object.fromEntries(BACKUP_STORE_NAMES.map((name) => [name, records[name].length])) as BackupCounts;
}

export async function exportEncryptedBackup(snapshot: BackupSnapshot, passphrase: string, options: BackupCryptoOptions = {}): Promise<string> {
  validatePassphrase(passphrase);
  const validated = validateBackupSnapshot(snapshot);
  const plaintext = JSON.stringify(validated);
  if (new TextEncoder().encode(plaintext).byteLength > MAX_PLAINTEXT_BYTES) throw new Error('Резервная копия слишком велика. Уменьши число или размер вложений.');
  const iterations = options.iterations ?? DEFAULT_ITERATIONS;
  if (!Number.isSafeInteger(iterations) || iterations < 1000 || iterations > MAX_ITERATIONS) throw new Error('Некорректные параметры защиты резервной копии.');
  const salt = randomBytes(16);
  try {
    const key = await deriveBackupKey(passphrase, salt, iterations);
    const payload = await encryptPayload(plaintext, key, BACKUP_AAD);
    const envelope: BackupEnvelope = { format: BACKUP_FORMAT, version: BACKUP_VERSION, schemaVersion: 1, createdAt: validated.exportedAt, kdf: { algorithm: 'PBKDF2-HMAC-SHA-256', salt: encodeBase64Url(salt), iterations }, payload };
    const serialized = JSON.stringify(envelope);
    if (new TextEncoder().encode(serialized).byteLength > MAX_BACKUP_BYTES) throw new Error('Зашифрованная резервная копия превышает допустимый размер.');
    return serialized;
  } finally { salt.fill(0); }
}

export async function previewEncryptedBackup(serialized: string, passphrase: string, options: BackupCryptoOptions = {}): Promise<BackupPreview> {
  validatePassphrase(passphrase);
  if (typeof serialized !== 'string' || new TextEncoder().encode(serialized).byteLength > MAX_BACKUP_BYTES) throw new Error('Файл резервной копии слишком велик или имеет некорректный формат.');
  let envelope: BackupEnvelope;
  try { envelope = JSON.parse(serialized) as BackupEnvelope; } catch { throw new Error('Не удалось прочитать файл резервной копии.'); }
  if (!isPlainRecord(envelope) || envelope.format !== BACKUP_FORMAT || envelope.version !== BACKUP_VERSION || envelope.schemaVersion !== 1 || typeof envelope.createdAt !== 'string' || !Number.isFinite(Date.parse(envelope.createdAt)) || !isPlainRecord(envelope.kdf) || envelope.kdf.algorithm !== 'PBKDF2-HMAC-SHA-256' || !isPlainRecord(envelope.payload)) {
    throw new Error('Неподдерживаемый формат или версия резервной копии.');
  }
  const iterations = envelope.kdf.iterations;
  const minimumIterations = options.iterations !== undefined ? 1000 : MIN_PRODUCTION_ITERATIONS;
  if (!Number.isSafeInteger(iterations) || iterations < minimumIterations || iterations > MAX_ITERATIONS || (options.iterations !== undefined && iterations !== options.iterations)) throw new Error('Недопустимые параметры KDF в резервной копии.');
  const salt = decodeBase64Url(envelope.kdf.salt);
  if (salt.byteLength !== 16) throw new Error('Некорректная соль резервной копии.');
  try {
    const key = await deriveBackupKey(passphrase, salt, iterations);
    const plaintext = await decryptPayload(envelope.payload, key, BACKUP_AAD);
    if (new TextEncoder().encode(plaintext).byteLength > MAX_PLAINTEXT_BYTES) throw new Error('Расшифрованная резервная копия превышает допустимый размер.');
    let parsed: unknown;
    try { parsed = JSON.parse(plaintext); } catch { throw new Error('Содержимое резервной копии повреждено.'); }
    const snapshot = validateBackupSnapshot(parsed);
    if (snapshot.exportedAt !== envelope.createdAt) throw new Error('Дата резервной копии не совпадает с содержимым.');
    return { metadata: { format: BACKUP_FORMAT, version: 1, createdAt: envelope.createdAt, schemaVersion: 1, counts: countsFor(snapshot.records) }, snapshot };
  } finally { salt.fill(0); }
}

export async function restoreEncryptedBackup(serialized: string, passphrase: string, dataKey: CryptoKey, adapter: BackupStorageAdapter, options: BackupCryptoOptions = {}): Promise<BackupPreview> {
  const preview = await previewEncryptedBackup(serialized, passphrase, options);
  await adapter.replaceAtomically(preview.snapshot.records, dataKey);
  return preview;
}

export async function restoreBackupPreview(preview: BackupPreview, dataKey: CryptoKey, adapter: BackupStorageAdapter): Promise<BackupPreview> {
  if (!isPlainRecord(preview) || !isPlainRecord(preview.metadata)
    || preview.metadata.format !== BACKUP_FORMAT
    || preview.metadata.version !== BACKUP_VERSION
    || preview.metadata.schemaVersion !== 1
    || typeof preview.metadata.createdAt !== 'string'
    || !Number.isFinite(Date.parse(preview.metadata.createdAt))
    || !isPlainRecord(preview.metadata.counts)) {
    throw new Error('Предварительный просмотр резервной копии недействителен. Проверь формат и версию.');
  }
  if (Object.keys(preview.metadata).some((field) => !['format', 'version', 'createdAt', 'schemaVersion', 'counts'].includes(field))) {
    throw new Error('В метаданных предварительного просмотра обнаружены неизвестные поля.');
  }
  const snapshot = validateBackupSnapshot(preview.snapshot);
  if (preview.metadata.createdAt !== snapshot.exportedAt) throw new Error('Дата предварительного просмотра не совпадает с содержимым резервной копии.');
  const counts = countsFor(snapshot.records);
  if (Object.keys(preview.metadata.counts).some((name) => !BACKUP_STORE_NAMES.includes(name as BackupStoreName))) {
    throw new Error('В счётчиках предварительного просмотра обнаружены неизвестные разделы.');
  }
  for (const name of BACKUP_STORE_NAMES) {
    const suppliedCount = preview.metadata.counts[name];
    if (!Number.isSafeInteger(suppliedCount) || suppliedCount !== counts[name]) {
      throw new Error('Счётчики предварительного просмотра изменены. Проверь резервную копию ещё раз.');
    }
  }
  await adapter.replaceAtomically(snapshot.records, dataKey);
  return { ...preview, metadata: { ...preview.metadata, counts }, snapshot };
}

export function createIndexedDbBackupAdapter(database: IDBDatabase): BackupStorageAdapter {
  return {
    async replaceAtomically(records, dataKey) {
      const notes = await prepareContentRecordsForEncryption(records.notes as LegacyContentRecord[], dataKey, { storeName: 'notes', publicFields: ['title', 'tags', 'favorite', 'createdAt', 'updatedAt'], encryptedFields: ['body'] });
      const diaryEntries = await prepareContentRecordsForEncryption(records.diaryEntries as LegacyContentRecord[], dataKey, { storeName: 'diaryEntries', publicFields: ['date', 'title', 'tags', 'createdAt', 'updatedAt'], encryptedFields: ['body', 'mood', 'goodThings', 'concerns', 'gratitude', 'attachmentIds'] });
      const attachments = await Promise.all(records.attachments.map(async (record) => {
        const encryptedContent = await encryptPayload(String(record.contentBase64), dataKey, `menin-kunum:attachment:v1:${record.id}`);
        return { id: record.id, mimeType: record.mimeType, sizeBytes: record.sizeBytes, createdAt: record.createdAt, encryptedContent };
      }));
      const replacements: Record<BackupStoreName, Record<string, unknown>[]> = {
        tasks: records.tasks, projects: records.projects, notes, diaryEntries, habits: records.habits, habitLogs: records.habitLogs, attachments,
      };
      await new Promise<void>((resolve, reject) => {
        let transaction: IDBTransaction;
        try { transaction = database.transaction([...BACKUP_STORE_NAMES] as StoreName[], 'readwrite'); }
        catch (error) { reject(error); return; }
        let settled = false;
        transaction.oncomplete = () => { if (!settled) { settled = true; resolve(); } };
        transaction.onerror = () => { if (!settled) { settled = true; reject(transaction.error ?? new Error('Не удалось восстановить резервную копию.')); } };
        transaction.onabort = () => { if (!settled) { settled = true; reject(transaction.error ?? new Error('Восстановление отменено; прежние данные сохранены.')); } };
        try {
          for (const name of BACKUP_STORE_NAMES) transaction.objectStore(name).clear();
          for (const name of BACKUP_STORE_NAMES) for (const record of replacements[name]) transaction.objectStore(name).put(record);
        } catch (error) {
          try { transaction.abort(); } catch { /* The transaction has already failed. */ }
          if (!settled) { settled = true; reject(error); }
        }
      });
    },
  };
}
