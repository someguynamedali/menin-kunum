import type { Habit, HabitLog, HabitMeasure } from '../domain/models.ts';
import type { RecordRepository } from '../storage/repositories/base.ts';
import { StorageError } from '../storage/errors.ts';
import { requireRecord, requiredTitle, serviceOptions, timestamp, validateDate, type ServiceOptions } from './common.ts';

export type NewHabit = Pick<Habit, 'title' | 'measure' | 'targetValue' | 'targetPeriod'> & Partial<Pick<Habit, 'reminderTime'>>;
const measures: HabitMeasure[] = ['checkbox', 'minutes', 'pages', 'repetitions'];
const validateTarget = (value: number): void => { if (!Number.isFinite(value) || value <= 0) throw new StorageError('STORAGE_OPERATION_FAILED', 'Цель должна быть положительным числом.'); };
const validateValue = (measure: HabitMeasure, value: number): void => {
  if (!Number.isFinite(value) || value < 0) throw new StorageError('STORAGE_OPERATION_FAILED', 'Прогресс должен быть неотрицательным числом.');
  if (measure === 'checkbox' && value !== 0 && value !== 1) throw new StorageError('STORAGE_OPERATION_FAILED', 'Для привычки-галочки допустимы только 0 или 1.');
}

export function createHabitService(habitRepository: RecordRepository<Habit>, logRepository: RecordRepository<HabitLog>, options: ServiceOptions = {}) {
  const deps = serviceOptions(options);
  return {
    async create(input: NewHabit): Promise<Habit> {
      const title = requiredTitle(input.title); validateTarget(input.targetValue);
      if (!measures.includes(input.measure)) throw new StorageError('STORAGE_OPERATION_FAILED', 'Некорректный способ измерения привычки.');
      if (input.measure === 'checkbox' && input.targetValue !== 1) throw new StorageError('STORAGE_OPERATION_FAILED', 'Для привычки-галочки цель должна быть равна 1.');
      if (input.targetPeriod !== 'daily' && input.targetPeriod !== 'weekly') throw new StorageError('STORAGE_OPERATION_FAILED', 'Цель должна быть дневной или недельной.');
      const stamp = timestamp(deps.now);
      return habitRepository.create({ id: deps.createId(), title, measure: input.measure, targetValue: input.targetValue, targetPeriod: input.targetPeriod, ...(input.reminderTime ? { reminderTime: input.reminderTime } : {}), createdAt: stamp, updatedAt: stamp });
    },
    async update(id: string, changes: Partial<Pick<Habit, 'title' | 'measure' | 'targetValue' | 'targetPeriod' | 'reminderTime'>>): Promise<Habit> {
      const existing = await requireRecord(habitRepository, id);
      const next: Habit = { ...existing, ...changes, id: existing.id, createdAt: existing.createdAt, updatedAt: timestamp(deps.now), title: changes.title === undefined ? existing.title : requiredTitle(changes.title), targetValue: changes.targetValue ?? existing.targetValue };
      validateTarget(next.targetValue);
      if (!measures.includes(next.measure) || (next.targetPeriod !== 'daily' && next.targetPeriod !== 'weekly')) throw new StorageError('STORAGE_OPERATION_FAILED', 'Некорректные параметры привычки.');
      if (next.measure === 'checkbox' && next.targetValue !== 1) throw new StorageError('STORAGE_OPERATION_FAILED', 'Для привычки-галочки цель должна быть равна 1.');
      return habitRepository.update(next);
    },
    async remove(id: string): Promise<void> {
      await requireRecord(habitRepository, id);
      for (const log of await logRepository.list()) if (log.habitId === id) await logRepository.delete(log.id);
      await habitRepository.delete(id);
    },
    async list(): Promise<Habit[]> { return (await habitRepository.list()).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); },
    async recordHabitProgress(habitId: string, date: string, value: number): Promise<HabitLog> {
      validateDate(date);
      const habit = await requireRecord(habitRepository, habitId);
      validateValue(habit.measure, value);
      const existing = (await logRepository.list()).find((log) => log.habitId === habitId && log.date === date);
      if (existing) return logRepository.update({ ...existing, value });
      return logRepository.create({ id: deps.createId(), habitId, date, value });
    },
    async getDailyValue(habitId: string, date: string): Promise<number> {
      validateDate(date); await requireRecord(habitRepository, habitId);
      return (await logRepository.list()).find((log) => log.habitId === habitId && log.date === date)?.value ?? 0;
    },
    async getProgress(habitId: string, date: string): Promise<{ currentValue: number; targetValue: number; percent: number; complete: boolean }> {
      validateDate(date);
      const habit = await requireRecord(habitRepository, habitId);
      let startDate = date;
      if (habit.targetPeriod === 'weekly') {
        const parsed = new Date(`${date}T12:00:00Z`);
        const weekday = (parsed.getUTCDay() + 6) % 7;
        parsed.setUTCDate(parsed.getUTCDate() - weekday);
        startDate = parsed.toISOString().slice(0, 10);
      }
      const currentValue = (await logRepository.list()).filter((log) => log.habitId === habitId && log.date >= startDate && log.date <= date).reduce((total, log) => total + log.value, 0);
      return { currentValue, targetValue: habit.targetValue, percent: Math.min(100, Math.round((currentValue / habit.targetValue) * 100)), complete: currentValue >= habit.targetValue };
    },
    async getStreak(habitId: string, throughDate: string): Promise<number> {
      validateDate(throughDate);
      const habit = await requireRecord(habitRepository, habitId);
      const logs = (await logRepository.list()).filter((log) => log.habitId === habitId);
      if (habit.targetPeriod === 'daily') {
        const byDate = new Map(logs.map((log) => [log.date, log.value]));
        let streak = 0;
        const cursor = new Date(`${throughDate}T12:00:00Z`);
        while ((byDate.get(cursor.toISOString().slice(0, 10)) ?? 0) >= habit.targetValue) {
          streak += 1; cursor.setUTCDate(cursor.getUTCDate() - 1);
        }
        return streak;
      }
      const weekStart = (value: string): Date => {
        const date = new Date(`${value}T12:00:00Z`);
        date.setUTCDate(date.getUTCDate() - ((date.getUTCDay() + 6) % 7));
        return date;
      };
      const totalForWeek = (start: Date, end: Date): number => {
        const first = start.toISOString().slice(0, 10); const last = end.toISOString().slice(0, 10);
        return logs.filter((log) => log.date >= first && log.date <= last).reduce((total, log) => total + log.value, 0);
      };
      let start = weekStart(throughDate);
      const currentEnd = new Date(`${throughDate}T12:00:00Z`);
      let streak = 0;
      if (totalForWeek(start, currentEnd) >= habit.targetValue) streak += 1;
      start.setUTCDate(start.getUTCDate() - 7);
      while (true) {
        const end = new Date(start); end.setUTCDate(end.getUTCDate() + 6);
        if (totalForWeek(start, end) < habit.targetValue) break;
        streak += 1; start.setUTCDate(start.getUTCDate() - 7);
      }
      return streak;
    },
  };
}
