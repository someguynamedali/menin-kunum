import type { DiaryEntry, Habit, HabitLog, Note, Task } from '../domain/models.ts';

export interface LocalSummaryInput { tasks: Task[]; notes: Note[]; diaryEntries: DiaryEntry[]; habits: Habit[]; habitLogs: HabitLog[]; }
export interface SummaryPeriod { startDate: string; endDate: string; tasks: number; completedTasks: number; notesUpdated: number; diaryEntries: number; habitLogs: number; moodCounts: Record<string, number>; }
export interface LocalSummaries { weekly: SummaryPeriod; monthly: SummaryPeriod; }

function dateString(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
function periodBounds(reference: Date): { weekStart: string; weekEnd: string; monthStart: string; monthEnd: string } {
  const weekStart = new Date(reference.getFullYear(), reference.getMonth(), reference.getDate());
  const daysFromMonday = (weekStart.getDay() + 6) % 7;
  weekStart.setDate(weekStart.getDate() - daysFromMonday);
  const weekEnd = new Date(weekStart); weekEnd.setDate(weekEnd.getDate() + 6);
  const monthStart = new Date(reference.getFullYear(), reference.getMonth(), 1);
  const monthEnd = new Date(reference.getFullYear(), reference.getMonth() + 1, 0);
  return { weekStart: dateString(weekStart), weekEnd: dateString(weekEnd), monthStart: dateString(monthStart), monthEnd: dateString(monthEnd) };
}
function inRange(date: string | undefined, start: string, end: string): boolean { return Boolean(date && date >= start && date <= end); }
function countPeriod(input: LocalSummaryInput, startDate: string, endDate: string): SummaryPeriod {
  const periodTasks = input.tasks.filter((task) => inRange(task.dueDate ?? task.createdAt.slice(0, 10), startDate, endDate));
  const diaryEntries = input.diaryEntries.filter((entry) => inRange(entry.date, startDate, endDate));
  const moodCounts: Record<string, number> = {};
  for (const entry of diaryEntries) if (entry.mood) moodCounts[entry.mood] = (moodCounts[entry.mood] ?? 0) + 1;
  return {
    startDate, endDate,
    tasks: periodTasks.length,
    completedTasks: periodTasks.filter((task) => task.status === 'completed').length,
    notesUpdated: input.notes.filter((note) => inRange(note.updatedAt.slice(0, 10), startDate, endDate)).length,
    diaryEntries: diaryEntries.length,
    habitLogs: input.habitLogs.filter((log) => inRange(log.date, startDate, endDate)).length,
    moodCounts,
  };
}

/** Rule-based local counts only; no text or personal data is sent to a model or server. */
export function createLocalSummariesService() {
  return {
    summarize(input: LocalSummaryInput, referenceDate = new Date()): LocalSummaries {
      const bounds = periodBounds(referenceDate);
      return {
        weekly: countPeriod(input, bounds.weekStart, bounds.weekEnd),
        monthly: countPeriod(input, bounds.monthStart, bounds.monthEnd),
      };
    },
  };
}
