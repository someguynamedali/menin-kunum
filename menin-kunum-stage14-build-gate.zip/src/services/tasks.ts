import type { Priority, Subtask, Task, TaskStatus } from '../domain/models.ts';
import type { RecordRepository } from '../storage/repositories/base.ts';
import { StorageError } from '../storage/errors.ts';
import { requireRecord, requiredTitle, serviceOptions, timestamp, validateDate, type ServiceOptions } from './common.ts';

export type NewTask = Pick<Task, 'title'> & Partial<Omit<Task, 'id' | 'title' | 'createdAt' | 'updatedAt'>>;
export type TaskChanges = Partial<Omit<Task, 'id' | 'createdAt' | 'updatedAt'>>;
const priorities: Priority[] = ['low', 'medium', 'high'];
const statuses: TaskStatus[] = ['planned', 'completed', 'deferred'];
const validateMinutes = (value: number | undefined, field: string): void => {
  if (value !== undefined && (!Number.isFinite(value) || value < 0)) throw new StorageError('STORAGE_OPERATION_FAILED', `${field} должно быть неотрицательным числом.`);
};

export function createTaskService(repository: RecordRepository<Task>, options: ServiceOptions = {}) {
  const deps = serviceOptions(options);
  const validateDependency = async (taskId: string, dependencyIds: string[]): Promise<true> => {
    const all = await repository.list();
    const byId = new Map(all.map((task) => [task.id, task]));
    const uniqueIds = [...new Set(dependencyIds)];
    if (uniqueIds.includes(taskId)) throw new StorageError('STORAGE_OPERATION_FAILED', 'Задача не может зависеть сама от себя.');
    for (const dependencyId of uniqueIds) {
      if (!byId.has(dependencyId)) throw new StorageError('NOT_FOUND', 'Зависимая задача не найдена.');
      const pending = [dependencyId]; const visited = new Set<string>();
      while (pending.length) {
        const current = pending.pop()!;
        if (current === taskId) throw new StorageError('STORAGE_OPERATION_FAILED', 'Эта зависимость создаёт цикл.');
        if (visited.has(current)) continue;
        visited.add(current); pending.push(...(byId.get(current)?.dependencyIds ?? []));
      }
    }
    return true;
  };
  const update = async (id: string, changes: TaskChanges): Promise<Task> => {
    const existing = await requireRecord(repository, id);
    const next: Task = { ...existing, ...changes, id: existing.id, createdAt: existing.createdAt, updatedAt: timestamp(deps.now) };
    next.title = requiredTitle(next.title);
    if (next.dueDate !== undefined && next.dueDate !== '') validateDate(next.dueDate);
    if (!priorities.includes(next.priority) || !statuses.includes(next.status)) throw new StorageError('STORAGE_OPERATION_FAILED', 'Некорректный приоритет или статус задачи.');
    validateMinutes(next.estimatedMinutes, 'Плановое время');
    validateMinutes(next.actualMinutes, 'Фактическое время');
    next.dependencyIds = [...new Set(next.dependencyIds ?? [])];
    await validateDependency(id, next.dependencyIds);
    if (next.recurringRule) next.recurringRule = { weekdays: [...new Set(next.recurringRule.weekdays.filter((day) => Number.isInteger(day) && day >= 0 && day <= 6))] };
    next.subtasks = (next.subtasks ?? []).map((subtask) => ({ ...subtask, title: requiredTitle(subtask.title), parentTaskId: next.id }));
    return repository.update(next);
  };
  return {
    async create(input: NewTask): Promise<Task> {
      const title = requiredTitle(input.title);
      if (input.dueDate !== undefined && input.dueDate !== '') validateDate(input.dueDate);
      if (input.priority !== undefined && !priorities.includes(input.priority)) throw new StorageError('STORAGE_OPERATION_FAILED', 'Некорректный приоритет задачи.');
      if (input.status !== undefined && !statuses.includes(input.status)) throw new StorageError('STORAGE_OPERATION_FAILED', 'Некорректный статус задачи.');
      validateMinutes(input.estimatedMinutes, 'Плановое время');
      validateMinutes(input.actualMinutes, 'Фактическое время');
      const stamp = timestamp(deps.now);
      const task: Task = {
        id: deps.createId(), title,
        ...(input.description?.trim() ? { description: input.description.trim() } : {}),
        ...(input.dueDate ? { dueDate: input.dueDate } : {}), ...(input.dueTime ? { dueTime: input.dueTime } : {}),
        ...(input.category?.trim() ? { category: input.category.trim() } : {}), ...(input.projectId ? { projectId: input.projectId } : {}),
        priority: input.priority ?? 'medium', status: input.status ?? 'planned', dependencyIds: [...new Set(input.dependencyIds ?? [])],
        subtasks: [],
        ...(input.recurringRule ? { recurringRule: { weekdays: [...new Set(input.recurringRule.weekdays.filter((day) => Number.isInteger(day) && day >= 0 && day <= 6))] } } : {}),
        ...(input.estimatedMinutes !== undefined ? { estimatedMinutes: input.estimatedMinutes } : {}), ...(input.actualMinutes !== undefined ? { actualMinutes: input.actualMinutes } : {}),
        createdAt: stamp, updatedAt: stamp,
      };
      task.subtasks = (input.subtasks ?? []).map((subtask) => ({ ...subtask, parentTaskId: task.id, title: requiredTitle(subtask.title) }));
      await validateDependency(task.id, task.dependencyIds);
      return repository.create(task);
    },
    update,
    async remove(id: string): Promise<void> {
      await requireRecord(repository, id);
      const referencing = (await repository.list()).filter((task) => task.id !== id && task.dependencyIds.includes(id));
      for (const task of referencing) await update(task.id, { dependencyIds: task.dependencyIds.filter((dependencyId) => dependencyId !== id) });
      await repository.delete(id);
    },
    async list(): Promise<Task[]> { return (await repository.list()).sort((a, b) => (a.dueDate ?? '9999-12-31').localeCompare(b.dueDate ?? '9999-12-31') || b.updatedAt.localeCompare(a.updatedAt)); },
    async search(query: string): Promise<Task[]> {
      const normalized = query.trim().toLocaleLowerCase();
      const all = await repository.list();
      if (!normalized) return all;
      return all.filter((task) => `${task.title} ${task.description ?? ''} ${task.category ?? ''}`.toLocaleLowerCase().includes(normalized));
    },
    async setStatus(id: string, status: TaskStatus): Promise<Task> { return update(id, { status }); },
    async carryForwardUnfinishedTasks(sourceDate: string, targetDate: string): Promise<Task[]> {
      validateDate(sourceDate); validateDate(targetDate);
      const unfinished = (await repository.list()).filter((task) => task.dueDate === sourceDate && task.status !== 'completed');
      const moved: Task[] = [];
      for (const task of unfinished) moved.push(await update(task.id, { dueDate: targetDate }));
      return moved;
    },
    validateDependency,
    async setTimeTracking(id: string, values: Pick<Task, 'estimatedMinutes' | 'actualMinutes'>): Promise<Task> {
      validateMinutes(values.estimatedMinutes, 'Плановое время'); validateMinutes(values.actualMinutes, 'Фактическое время');
      return update(id, values);
    },
    async addSubtask(parentTaskId: string, title: string): Promise<Subtask> {
      const parent = await requireRecord(repository, parentTaskId);
      const subtask: Subtask = { id: deps.createId(), parentTaskId, title: requiredTitle(title), completed: false };
      await update(parentTaskId, { subtasks: [...(parent.subtasks ?? []), subtask] });
      return subtask;
    },
    async setSubtaskCompleted(parentTaskId: string, subtaskId: string, completed: boolean): Promise<Task> {
      const parent = await requireRecord(repository, parentTaskId);
      if (!(parent.subtasks ?? []).some((subtask) => subtask.id === subtaskId)) throw new StorageError('NOT_FOUND', 'Подзадача не найдена.');
      return update(parentTaskId, { subtasks: (parent.subtasks ?? []).map((subtask) => subtask.id === subtaskId ? { ...subtask, completed } : subtask) });
    },
    async removeSubtask(parentTaskId: string, subtaskId: string): Promise<void> {
      const parent = await requireRecord(repository, parentTaskId);
      if (!(parent.subtasks ?? []).some((subtask) => subtask.id === subtaskId)) throw new StorageError('NOT_FOUND', 'Подзадача не найдена.');
      await update(parentTaskId, { subtasks: (parent.subtasks ?? []).filter((subtask) => subtask.id !== subtaskId) });
    },
  };
}
