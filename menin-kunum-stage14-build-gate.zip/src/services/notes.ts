import type { Note } from '../domain/models.ts';
import type { RecordRepository } from '../storage/repositories/base.ts';
import { StorageError } from '../storage/errors.ts';
import { normalizeTags, requireRecord, requiredTitle, serviceOptions, timestamp, type ServiceOptions } from './common.ts';

export type NewNote = Pick<Note, 'title'> & Partial<Pick<Note, 'body' | 'tags' | 'favorite'>>;
export type NoteChanges = Partial<Pick<Note, 'title' | 'body' | 'tags' | 'favorite'>>;

export function createNoteService(repository: RecordRepository<Note>, options: ServiceOptions = {}) {
  const deps = serviceOptions(options);
  return {
    async create(input: NewNote): Promise<Note> {
      const stamp = timestamp(deps.now);
      const note: Note = {
        id: deps.createId(), title: requiredTitle(input.title), body: input.body?.trim() ?? '',
        tags: normalizeTags(input.tags), favorite: input.favorite ?? false,
        createdAt: stamp, updatedAt: stamp,
      };
      if (typeof note.favorite !== 'boolean') throw new StorageError('STORAGE_OPERATION_FAILED', 'Статус избранного должен быть логическим значением.');
      return repository.create(note);
    },
    async update(id: string, changes: NoteChanges): Promise<Note> {
      const existing = await requireRecord(repository, id);
      const next: Note = {
        ...existing, ...changes, id: existing.id, createdAt: existing.createdAt, updatedAt: timestamp(deps.now),
        title: changes.title === undefined ? existing.title : requiredTitle(changes.title),
        body: changes.body === undefined ? existing.body : (typeof changes.body === 'string' ? changes.body.trim() : (() => { throw new StorageError('STORAGE_OPERATION_FAILED', 'Текст заметки должен быть строкой.'); })()),
        tags: changes.tags === undefined ? existing.tags : normalizeTags(changes.tags),
      };
      if (typeof next.favorite !== 'boolean') throw new StorageError('STORAGE_OPERATION_FAILED', 'Статус избранного должен быть логическим значением.');
      return repository.update(next);
    },
    async remove(id: string): Promise<void> { await repository.delete(id); },
    async list(): Promise<Note[]> { return (await repository.list()).sort((a, b) => Number(b.favorite) - Number(a.favorite) || b.updatedAt.localeCompare(a.updatedAt)); },
    async search(query: string): Promise<Note[]> {
      const normalized = query.trim().toLocaleLowerCase();
      const all = await repository.list();
      if (!normalized) return all;
      return all.filter((note) => `${note.title} ${note.body} ${note.tags.join(' ')}`.toLocaleLowerCase().includes(normalized));
    },
    async toggleFavorite(id: string): Promise<Note> {
      const existing = await requireRecord(repository, id);
      return this.update(id, { favorite: !existing.favorite });
    },
  };
}
