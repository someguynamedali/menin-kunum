import type { Project, Task } from '../domain/models.ts';
import type { RecordRepository } from '../storage/repositories/base.ts';
import { StorageError } from '../storage/errors.ts';
import { requireRecord, requiredTitle, serviceOptions, timestamp, type ServiceOptions } from './common.ts';

export function createProjectService(projectRepository: RecordRepository<Project>, taskRepository: RecordRepository<Task>, options: ServiceOptions = {}) {
  const deps = serviceOptions(options);
  return {
    async create(input: { title: string; description?: string }): Promise<Project> {
      const stamp = timestamp(deps.now);
      return projectRepository.create({ id: deps.createId(), title: requiredTitle(input.title), ...(input.description?.trim() ? { description: input.description.trim() } : {}), taskIds: [], createdAt: stamp, updatedAt: stamp });
    },
    async update(id: string, changes: { title?: string; description?: string }): Promise<Project> {
      const existing = await requireRecord(projectRepository, id);
      const next: Project = { ...existing, ...changes, id: existing.id, createdAt: existing.createdAt, updatedAt: timestamp(deps.now), title: changes.title === undefined ? existing.title : requiredTitle(changes.title), description: changes.description === undefined ? existing.description : changes.description.trim() };
      return projectRepository.update(next);
    },
    async addTask(projectId: string, taskId: string): Promise<Project> {
      const project = await requireRecord(projectRepository, projectId);
      const task = await requireRecord(taskRepository, taskId);
      if (task.projectId && task.projectId !== projectId) throw new StorageError('STORAGE_OPERATION_FAILED', 'Эта задача уже относится к другому проекту.');
      if (project.taskIds.includes(taskId)) return project;
      await taskRepository.update({ ...task, projectId, updatedAt: timestamp(deps.now) });
      return projectRepository.update({ ...project, taskIds: [...project.taskIds, taskId], updatedAt: timestamp(deps.now) });
    },
    async removeTask(projectId: string, taskId: string): Promise<Project> {
      const project = await requireRecord(projectRepository, projectId);
      if (!project.taskIds.includes(taskId)) return project;
      const task = await taskRepository.getById(taskId);
      if (task?.projectId === projectId) {
        const { projectId: _projectId, ...withoutProject } = task;
        await taskRepository.update({ ...withoutProject, updatedAt: timestamp(deps.now) });
      }
      return projectRepository.update({ ...project, taskIds: project.taskIds.filter((id) => id !== taskId), updatedAt: timestamp(deps.now) });
    },
    async remove(id: string): Promise<void> {
      const project = await requireRecord(projectRepository, id);
      for (const taskId of project.taskIds) {
        const task = await taskRepository.getById(taskId);
        if (task?.projectId === id) {
          const { projectId: _projectId, ...withoutProject } = task;
          await taskRepository.update({ ...withoutProject, updatedAt: timestamp(deps.now) });
        }
      }
      await projectRepository.delete(id);
    },
    async list(): Promise<Project[]> { return (await projectRepository.list()).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); },
  };
}
