import type { DiaryEntry, HabitLog, Task } from '../domain/models.ts';
import { validateDate } from './common.ts';

export interface CalendarItem { id: string; date: string; kind: 'task' | 'diary' | 'habit'; title: string; completed?: boolean; sourceId: string }

export function createCalendarService() {
  return {
    expandRecurringTasks(tasks: Task[], startDate: string, endDate: string): Task[] {
      validateDate(startDate); validateDate(endDate);
      if (startDate > endDate) throw new RangeError('Дата начала календаря должна быть не позже даты окончания.');
      const output: Task[] = [];
      for (const task of tasks) {
        if (!task.dueDate) continue;
        validateDate(task.dueDate);
        if (!task.recurringRule || task.status === 'completed') {
          if (task.dueDate >= startDate && task.dueDate <= endDate) output.push(task);
          continue;
        }
        const weekdays = new Set(task.recurringRule.weekdays.filter((day) => Number.isInteger(day) && day >= 0 && day <= 6));
        const cursor = new Date(`${task.dueDate}T12:00:00Z`);
        const rangeStart = new Date(`${startDate}T12:00:00Z`);
        const rangeEnd = new Date(`${endDate}T12:00:00Z`);
        if (cursor < rangeStart) cursor.setTime(rangeStart.getTime());
        for (; cursor <= rangeEnd; cursor.setUTCDate(cursor.getUTCDate() + 1)) {
          const date = cursor.toISOString().slice(0, 10);
          if (date >= task.dueDate && weekdays.has(cursor.getUTCDay())) output.push({ ...task, dueDate: date });
        }
      }
      const unique = new Map(output.map((task) => [`${task.id}:${task.dueDate}`, task]));
      return [...unique.values()].sort((a, b) => (a.dueDate ?? '').localeCompare(b.dueDate ?? ''));
    },
    getItemsForDate(input: { tasks: Task[]; diaryEntries: DiaryEntry[]; habitLogs: HabitLog[]; habits?: import('../domain/models.ts').Habit[] }, date: string): CalendarItem[] {
      validateDate(date);
      const tasks = this.expandRecurringTasks(input.tasks, date, date).map((task) => ({ id: `task:${task.id}:${task.dueDate}`, sourceId: task.id, date, kind: 'task' as const, title: task.title, completed: task.status === 'completed' }));
      const diary = input.diaryEntries.filter((entry) => entry.date === date).map((entry) => ({ id: `diary:${entry.id}`, sourceId: entry.id, date, kind: 'diary' as const, title: entry.title || 'Запись дневника' }));
      const habitNames = new Map((input.habits ?? []).map((habit) => [habit.id, habit.title]));
      const habits = input.habitLogs.filter((log) => log.date === date).map((log) => ({ id: `habit:${log.id}`, sourceId: log.habitId, date, kind: 'habit' as const, title: `${habitNames.get(log.habitId) ?? 'Привычка'}: ${log.value}` }));
      return [...tasks, ...diary, ...habits];
    },
  };
}
