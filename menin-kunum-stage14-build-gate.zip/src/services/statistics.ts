import type { DiaryEntry, Habit, HabitLog, Task } from '../domain/models.ts';

export interface StatisticsInput { tasks: Task[]; habits: Habit[]; habitLogs: HabitLog[]; diaryEntries: DiaryEntry[] }
export interface ProductivitySummary {
  totalTasks: number;
  completedTasks: number;
  completionRate: number;
  estimatedMinutes: number;
  actualMinutes: number;
  habitLogsCount: number;
  diaryEntriesCount: number;
  moodCounts: Record<string, number>;
}

export function createStatisticsService() {
  return {
    summarize(input: StatisticsInput): ProductivitySummary {
      const totalTasks = input.tasks.length;
      const completedTasks = input.tasks.filter((task) => task.status === 'completed').length;
      const moodCounts: Record<string, number> = {};
      for (const entry of input.diaryEntries) if (entry.mood) moodCounts[entry.mood] = (moodCounts[entry.mood] ?? 0) + 1;
      return {
        totalTasks, completedTasks,
        completionRate: totalTasks ? Math.round((completedTasks / totalTasks) * 100) : 0,
        estimatedMinutes: input.tasks.reduce((total, task) => total + (task.estimatedMinutes ?? 0), 0),
        actualMinutes: input.tasks.reduce((total, task) => total + (task.actualMinutes ?? 0), 0),
        habitLogsCount: input.habitLogs.length, diaryEntriesCount: input.diaryEntries.length, moodCounts,
      };
    },
  };
}
