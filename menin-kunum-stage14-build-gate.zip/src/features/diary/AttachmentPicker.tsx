import { useEffect, useState, type ChangeEvent } from 'react';
import type { Locale } from '../../domain/models.ts';

interface AttachmentPickerProps { files: File[]; locale: Locale; onChange: (files: File[]) => void; }
interface PreviewFile { file: File; url?: string; }

const copy = {
  ru: { add: 'Прикрепить файлы', hint: 'JPG, PNG, WebP, TXT или PDF · до 5 МБ на файл, всего до 10 МБ', remove: 'Убрать', selected: 'Новые вложения' },
  ky: { add: 'Файл тиркөө', hint: 'JPG, PNG, WebP, TXT же PDF · ар бири 5 МБ, жалпы 10 МБ чейин', remove: 'Алып салуу', selected: 'Жаңы тиркемелер' },
  en: { add: 'Attach files', hint: 'JPG, PNG, WebP, TXT or PDF · up to 5 MB each, 10 MB total', remove: 'Remove', selected: 'New attachments' },
} as const;

export function AttachmentPicker({ files, locale, onChange }: AttachmentPickerProps) {
  const c = copy[locale];
  const [previews, setPreviews] = useState<PreviewFile[]>([]);
  useEffect(() => {
    const next = files.map((file) => ({ file, ...(['image/jpeg', 'image/png', 'image/webp'].includes(file.type) ? { url: URL.createObjectURL(file) } : {}) }));
    setPreviews(next);
    return () => next.forEach((item) => { if (item.url) URL.revokeObjectURL(item.url); });
  }, [files]);
  const onPick = (event: ChangeEvent<HTMLInputElement>) => {
    const selected = Array.from(event.target.files ?? []);
    if (selected.length) onChange([...files, ...selected]);
    event.target.value = '';
  };
  return <div className="attachment-picker">
    <label className="attachment-pick-button">＋ {c.add}<input type="file" accept="image/jpeg,image/png,image/webp,text/plain,application/pdf" multiple onChange={onPick} /></label>
    <p className="attachment-hint">{c.hint}</p>
    {previews.length > 0 && <div className="attachment-preview-list"><h4>{c.selected}</h4>{previews.map(({ file, url }, index) => <div className="attachment-preview-item" key={`${file.name}-${file.lastModified}-${index}`}>
      {url ? <img src={url} alt={file.name} /> : <span className="attachment-file-icon" aria-hidden="true">{file.type === 'application/pdf' ? 'PDF' : 'TXT'}</span>}
      <span className="attachment-file-name"><strong>{file.name}</strong><small>{formatSize(file.size)}</small></span>
      <button type="button" className="attachment-remove" onClick={() => onChange(files.filter((_, fileIndex) => fileIndex !== index))}>{c.remove}</button>
    </div>)}</div>}
  </div>;
}

function formatSize(bytes: number): string {
  return bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

interface AttachmentReader { readBlob(id: string): Promise<Blob>; }
export function AttachmentGallery({ ids, service, locale }: { ids: string[]; service: AttachmentReader; locale: Locale }) {
  const [items, setItems] = useState<Array<{ id: string; url: string; type: string }>>([]);
  const idsKey = ids.join('|');
  useEffect(() => {
    let disposed = false;
    const urls: string[] = [];
    setItems([]);
    const requestedIds = idsKey ? idsKey.split('|') : [];
    void Promise.all(requestedIds.map(async (id) => {
      try {
        const blob = await service.readBlob(id);
        const url = URL.createObjectURL(blob); urls.push(url);
        return { id, url, type: blob.type };
      } catch { return undefined; }
    })).then((next) => {
      if (disposed) urls.forEach((url) => URL.revokeObjectURL(url));
      else setItems(next.filter((item): item is { id: string; url: string; type: string } => Boolean(item)));
    });
    return () => { disposed = true; urls.forEach((url) => URL.revokeObjectURL(url)); };
  }, [idsKey, service]);
  if (!items.length) return null;
  return <div className="saved-attachment-gallery" aria-label={locale === 'ky' ? 'Тиркемелер' : locale === 'en' ? 'Attachments' : 'Вложения'}>
    {items.map((item) => item.type.startsWith('image/')
      ? <a key={item.id} href={item.url} target="_blank" rel="noreferrer" className="saved-attachment-image"><img src={item.url} alt={locale === 'en' ? 'Diary attachment' : locale === 'ky' ? 'Күндөлүктүн тиркемеси' : 'Вложение к записи'} loading="lazy" /></a>
      : <a key={item.id} href={item.url} target="_blank" rel="noreferrer" className="saved-attachment-file">{item.type === 'application/pdf' ? 'PDF' : 'TXT'} · {locale === 'en' ? 'Open attachment' : locale === 'ky' ? 'Тиркемени ачуу' : 'Открыть вложение'}</a>)}
  </div>;
}
