import { useState } from 'react';
import type { DiaryEntry, Habit, HabitLog, Locale, Task } from '../../domain/models.ts';
import type { createCalendarService } from '../../services/calendar.ts';

type CalendarService = ReturnType<typeof createCalendarService>;
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const labels = { ru: { title: 'Календарь', subtitle: 'Задачи, дневник и привычки в одном месте.', date: 'Выбери дату', empty: 'На этот день пока ничего не запланировано.', task: 'Задача', diary: 'Дневник', habit: 'Привычка', done: 'Выполнено' }, ky: { title: 'Календарь', subtitle: 'Тапшырмалар, күндөлүк жана адаттар бир жерде.', date: 'Күндү танда', empty: 'Бул күнгө азырынча эч нерсе пландалган эмес.', task: 'Тапшырма', diary: 'Күндөлүк', habit: 'Адат', done: 'Аткарылды' }, en: { title: 'Calendar', subtitle: 'Tasks, diary entries and habits in one place.', date: 'Choose a date', empty: 'Nothing planned for this day yet.', task: 'Task', diary: 'Diary', habit: 'Habit', done: 'Completed' } } as const;

export function CalendarPage({ service, tasks, diaryEntries, habits, habitLogs, locale }: { service: CalendarService; tasks: Task[]; diaryEntries: DiaryEntry[]; habits: Habit[]; habitLogs: HabitLog[]; locale: Locale }) {
  const [date, setDate] = useState(today()); const c = labels[locale];
  const items = service.getItemsForDate({ tasks, diaryEntries, habits, habitLogs }, date);
  const typeLabel = (kind: 'task' | 'diary' | 'habit') => c[kind];
  return <section className="feature-page" aria-labelledby="calendar-title"><div className="feature-icon" aria-hidden="true">▦</div><p className="eyebrow">{locale === 'ky' ? 'КҮНДӨЛҮК ПЛАН' : locale === 'en' ? 'YOUR TIMELINE' : 'ТВОЯ ХРОНОЛОГИЯ'}</p><h2 id="calendar-title">{c.title}</h2><p className="feature-subtitle">{c.subtitle}</p><label className="field-label">{c.date}<input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></label>
    {!items.length ? <div className="empty-state"><span aria-hidden="true">✧</span><p>{c.empty}</p></div> : <div className="record-list">{items.map((item) => <article className="record-card" key={item.id}><div className="task-content"><span className="eyebrow">{typeLabel(item.kind)}</span><h3>{item.title}</h3></div>{item.completed && <span className="setting-badge">{c.done}</span>}</article>)}</div>}
  </section>;
}
