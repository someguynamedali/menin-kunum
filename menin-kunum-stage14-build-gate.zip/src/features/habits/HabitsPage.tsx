import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import type { Habit, HabitMeasure, Locale } from '../../domain/models.ts';
import type { createHabitService } from '../../services/habits.ts';

type HabitService = ReturnType<typeof createHabitService>;
const localDate = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const labels = {
  ru: { title: 'Привычки', subtitle: 'Небольшие действия, которые складываются в устойчивый ритм.', name: 'Название привычки', measure: 'Как измерять', checkbox: 'Отметка', minutes: 'Минуты', pages: 'Страницы', repetitions: 'Повторения', target: 'Цель', period: 'Период', daily: 'Каждый день', weekly: 'За неделю', add: 'Добавить привычку', progress: 'Прогресс сегодня', save: 'Записать прогресс', empty: 'Пока нет привычек. Начни с одной небольшой цели.', streak: 'дней подряд', complete: 'Цель достигнута' },
  ky: { title: 'Адаттар', subtitle: 'Кичинекей аракеттер туруктуу ыргакты түзөт.', name: 'Адаттын аталышы', measure: 'Өлчөө жолу', checkbox: 'Белги', minutes: 'Мүнөт', pages: 'Барак', repetitions: 'Кайталоо', target: 'Максат', period: 'Мезгил', daily: 'Күн сайын', weekly: 'Апта ичинде', add: 'Адат кошуу', progress: 'Бүгүнкү жүрүш', save: 'Жүрүштү жазуу', empty: 'Азырынча адат жок. Бир кичинекей максаттан башта.', streak: 'күн катары менен', complete: 'Максат аткарылды' },
  en: { title: 'Habits', subtitle: 'Small actions that build a steady rhythm.', name: 'Habit name', measure: 'Measurement', checkbox: 'Check-off', minutes: 'Minutes', pages: 'Pages', repetitions: 'Repetitions', target: 'Target', period: 'Period', daily: 'Daily', weekly: 'Weekly', add: 'Add habit', progress: 'Progress today', save: 'Record progress', empty: 'No habits yet. Start with one small goal.', streak: 'day streak', complete: 'Target reached' },
} as const;

export function HabitsPage({ service, habits, locale, onRefresh }: { service: HabitService; habits: Habit[]; locale: Locale; onRefresh: () => Promise<void> }) {
  const c = labels[locale];
  const [title, setTitle] = useState('');
  const [measure, setMeasure] = useState<HabitMeasure>('checkbox');
  const [targetValue, setTargetValue] = useState('1');
  const [targetPeriod, setTargetPeriod] = useState<'daily' | 'weekly'>('daily');
  const [values, setValues] = useState<Record<string, string>>({});
  const [progress, setProgress] = useState<Record<string, { currentValue: number; todayValue: number; targetValue: number; percent: number; complete: boolean; streak: number }>>({});
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    void Promise.all(habits.map(async (habit) => ({ habitId: habit.id, progress: await service.getProgress(habit.id, localDate()), todayValue: await service.getDailyValue(habit.id, localDate()), streak: await service.getStreak(habit.id, localDate()) })))
      .then((items) => { if (!cancelled) setProgress(Object.fromEntries(items.map((item) => [item.habitId, { ...item.progress, todayValue: item.todayValue, streak: item.streak }]))); })
      .catch(() => { if (!cancelled) setError(locale === 'ky' ? 'Маалыматты окуу мүмкүн болгон жок.' : locale === 'en' ? 'Could not load habit progress.' : 'Не удалось загрузить прогресс привычек.'); });
    return () => { cancelled = true; };
  }, [habits, service, locale]);

  const create = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setError('');
    try { await service.create({ title, measure, targetValue: Number(targetValue), targetPeriod }); setTitle(''); await onRefresh(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Не удалось создать привычку.'); }
  };
  const record = async (habit: Habit) => {
    setError('');
    try { const value = habit.measure === 'checkbox' ? (progress[habit.id]?.todayValue ? 0 : 1) : Number(values[habit.id] ?? '1'); await service.recordHabitProgress(habit.id, localDate(), value); await onRefresh(); }
    catch (cause) { setError(cause instanceof Error ? cause.message : 'Не удалось записать прогресс.'); }
  };

  return <section className="feature-page" aria-labelledby="habits-title"><div className="feature-icon" aria-hidden="true">✦</div><p className="eyebrow">{locale === 'ky' ? 'КҮНДӨЛҮК ЫРГАК' : locale === 'en' ? 'DAILY RHYTHM' : 'ЕЖЕДНЕВНЫЙ РИТМ'}</p><h2 id="habits-title">{c.title}</h2><p className="feature-subtitle">{c.subtitle}</p>
    <form className="record-form" onSubmit={create}><label className="field-label">{c.name}<input value={title} onChange={(e) => setTitle(e.target.value)} required maxLength={120} /></label><div className="form-grid"><label className="field-label">{c.measure}<select value={measure} onChange={(e) => { const next = e.target.value as HabitMeasure; setMeasure(next); if (next === 'checkbox') setTargetValue('1'); }}><option value="checkbox">{c.checkbox}</option><option value="minutes">{c.minutes}</option><option value="pages">{c.pages}</option><option value="repetitions">{c.repetitions}</option></select></label><label className="field-label">{c.target}<input type="number" min={measure === 'checkbox' ? 1 : 0.1} step={measure === 'checkbox' ? 1 : 'any'} value={targetValue} onChange={(e) => setTargetValue(e.target.value)} required /></label></div><label className="field-label">{c.period}<select value={targetPeriod} onChange={(e) => setTargetPeriod(e.target.value as 'daily' | 'weekly')}><option value="daily">{c.daily}</option><option value="weekly">{c.weekly}</option></select></label><button className="primary-action" type="submit">{c.add}</button></form>
    {error && <p className="inline-error" role="alert">{error}</p>}<div className="list-heading"><h3>{c.progress}<span>{habits.length}</span></h3></div>
    {!habits.length ? <div className="empty-state"><span aria-hidden="true">✧</span><p>{c.empty}</p></div> : <div className="record-list">{habits.map((habit) => { const p = progress[habit.id]; return <article className="record-card" key={habit.id}><div className="task-content"><h3>{habit.title}</h3><p className="record-body">{p ? `${p.currentValue} / ${p.targetValue} · ${p.percent}%` : '…'}{p?.streak ? ` · ${p.streak} ${c.streak}` : ''}</p><div className="progress-track"><span style={{ width: `${p?.percent ?? 0}%` }} /></div></div>{habit.measure !== 'checkbox' && <input className="progress-input" aria-label={c.progress} type="number" min="0" step="any" value={values[habit.id] ?? '1'} onChange={(e) => setValues((old) => ({ ...old, [habit.id]: e.target.value }))} />}<button className="secondary-button" type="button" onClick={() => void record(habit)}>{p?.complete && habit.measure === 'checkbox' ? c.complete : c.save}</button></article>; })}</div>}
  </section>;
}
