import type { Locale } from '../../domain/models.ts';

interface Props {
  locale: Locale;
  enabled: boolean;
  time: string;
  permission: 'default' | 'granted' | 'denied' | 'unsupported';
  onToggle: () => void;
  onTimeChange: (time: string) => void;
}
const copy = {
  ru: { title: 'Ежедневное напоминание', hint: 'Нейтральное уведомление без названий задач и личных записей. Срабатывает, пока приложение открыто; фоновые напоминания не гарантируются.', time: 'Время', enable: 'Включить напоминания', disable: 'Отключить напоминания', unsupported: 'Уведомления не поддерживаются этим браузером.', denied: 'Разрешение на уведомления отключено в настройках браузера.', granted: 'Разрешение получено.', default: 'Разрешение будет запрошено при включении.' },
  ky: { title: 'Күнүмдүк эскертме', hint: 'Тапшырмалардын аталыштарын жана жеке жазууларды көрсөтпөгөн билдирүү. Колдонмо ачык кезде иштейт; фондогу эскертмелер кепилденбейт.', time: 'Убакыт', enable: 'Эскертмелерди күйгүзүү', disable: 'Эскертмелерди өчүрүү', unsupported: 'Бул браузер билдирмелерди колдобойт.', denied: 'Браузердин жөндөөлөрүндө уруксат өчүрүлгөн.', granted: 'Уруксат берилди.', default: 'Күйгүзгөндө уруксат суралат.' },
  en: { title: 'Daily reminder', hint: 'A neutral notification with no task titles or personal entry content. It fires while the app is open; background reminders are not guaranteed.', time: 'Time', enable: 'Enable reminders', disable: 'Disable reminders', unsupported: 'Notifications are not supported by this browser.', denied: 'Notification permission is disabled in browser settings.', granted: 'Permission granted.', default: 'Permission will be requested when enabled.' },
} as const;
export function ReminderSettings({ locale, enabled, time, permission, onToggle, onTimeChange }: Props) {
  const c = copy[locale];
  return <div className="editor-card reminder-settings">
    <h3>{c.title}</h3><p>{c.hint}</p>
    <label className="field-label">{c.time}<input type="time" value={time} onChange={(event) => onTimeChange(event.target.value)} /></label>
    <button className={enabled ? 'secondary-button backup-button' : 'primary-action backup-button'} type="button" disabled={permission === 'unsupported' && !enabled} onClick={onToggle}>{enabled ? c.disable : c.enable}</button>
    <p className="reminder-permission" role="status">{c[permission]}</p>
  </div>;
}
