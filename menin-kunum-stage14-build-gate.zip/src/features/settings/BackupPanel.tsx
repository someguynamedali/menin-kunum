import { useState } from 'react';
import type { Locale } from '../../domain/models.ts';
import type { BackupPreview } from '../../services/backup.ts';

interface Props {
  locale: Locale;
  onExport: (passphrase: string) => Promise<string>;
  onPreview: (serialized: string, passphrase: string) => Promise<BackupPreview>;
  onRestore: (preview: BackupPreview) => Promise<void>;
}
const copy = {
  ru: { title: 'Резервная копия', exportTitle: 'Создать зашифрованную копию', exportText: 'Копия содержит задачи, проекты, привычки, заметки, дневник и вложения. Пароль не сохраняется в приложении.', pass: 'Пароль копии (не менее 12 символов)', confirmPass: 'Повтори пароль копии', export: 'Скачать резервную копию', exportDone: 'Зашифрованная копия скачана.', restoreTitle: 'Восстановить из копии', file: 'Файл резервной копии', restorePass: 'Пароль резервной копии', previewAction: 'Проверить файл', previewReady: 'Файл проверен. До подтверждения текущие данные не меняются.', restoreAction: 'Заменить данные данными из копии', restored: 'Данные восстановлены.', counts: 'Содержимое копии', confirmReplace: 'ВНИМАНИЕ: будут заменены все текущие задачи, проекты, заметки, дневник, привычки, прогресс и вложения. PIN и ключ защиты останутся прежними. Продолжить?', mismatch: 'Пароли не совпадают.', short: 'Пароль должен содержать не менее 12 символов.', size: 'Файл не должен превышать 30 МБ.', busy: 'Выполняется…', error: 'Не удалось обработать резервную копию.', show: 'Показать пароль' },
  ky: { title: 'Камдык көчүрмө', exportTitle: 'Шифрленген көчүрмө түзүү', exportText: 'Көчүрмөгө тапшырмалар, долбоорлор, адаттар, белгилер, күндөлүк жана тиркемелер кирет. Пароль колдонмодо сакталбайт.', pass: 'Көчүрмөнүн паролу (кеминде 12 белги)', confirmPass: 'Паролду кайтала', export: 'Көчүрмөнү жүктөө', exportDone: 'Шифрленген көчүрмө жүктөлдү.', restoreTitle: 'Көчүрмөдөн калыбына келтирүү', file: 'Камдык көчүрмөнүн файлы', restorePass: 'Камдык көчүрмөнүн паролу', previewAction: 'Файлды текшерүү', previewReady: 'Файл текшерилди. Ырастамайынча маалымат өзгөрбөйт.', restoreAction: 'Маалыматты көчүрмөдөгүлөр менен алмаштыруу', restored: 'Маалымат калыбына келтирилди.', counts: 'Көчүрмөнүн мазмуну', confirmReplace: 'ЭСКЕРТҮҮ: учурдагы тапшырмалар, долбоорлор, белгилер, күндөлүк, адаттар, прогресс жана тиркемелер алмаштырылат. PIN жана коргоо ачкычы өзгөрбөйт. Улантасыңбы?', mismatch: 'Паролдор дал келген жок.', short: 'Пароль кеминде 12 белгиден турушу керек.', size: 'Файл 30 МБдан ашпашы керек.', busy: 'Аткарылууда…', error: 'Көчүрмөнү иштетүү мүмкүн болгон жок.', show: 'Паролду көрсөтүү' },
  en: { title: 'Backup', exportTitle: 'Create an encrypted backup', exportText: 'The backup includes tasks, projects, habits, notes, diary entries and attachments. The passphrase is never saved by the app.', pass: 'Backup passphrase (at least 12 characters)', confirmPass: 'Confirm backup passphrase', export: 'Download encrypted backup', exportDone: 'Encrypted backup downloaded.', restoreTitle: 'Restore from backup', file: 'Backup file', restorePass: 'Backup passphrase', previewAction: 'Validate file', previewReady: 'File validated. Current data stays unchanged until you confirm.', restoreAction: 'Replace data with this backup', restored: 'Data restored.', counts: 'Backup contents', confirmReplace: 'WARNING: all current tasks, projects, notes, diary entries, habits, progress and attachments will be replaced. Your PIN and protection key remain unchanged. Continue?', mismatch: 'Passphrases do not match.', short: 'Passphrase must contain at least 12 characters.', size: 'File must not exceed 30 MB.', busy: 'Working…', error: 'Could not process the backup.', show: 'Show passphrase' },
} as const;
const storeNames: Record<Locale, Record<string, string>> = {
  ru: { tasks: 'Задачи', projects: 'Проекты', notes: 'Заметки', diaryEntries: 'Дневник', habits: 'Привычки', habitLogs: 'Прогресс привычек', attachments: 'Вложения' },
  ky: { tasks: 'Тапшырмалар', projects: 'Долбоорлор', notes: 'Белгилер', diaryEntries: 'Күндөлүк', habits: 'Адаттар', habitLogs: 'Адаттардын прогресси', attachments: 'Тиркемелер' },
  en: { tasks: 'Tasks', projects: 'Projects', notes: 'Notes', diaryEntries: 'Diary', habits: 'Habits', habitLogs: 'Habit progress', attachments: 'Attachments' },
};

export function BackupPanel({ locale, onExport, onPreview, onRestore }: Props) {
  const c = copy[locale];
  const [exportPass, setExportPass] = useState(''); const [confirmExportPass, setConfirmExportPass] = useState('');
  const [restorePass, setRestorePass] = useState(''); const [file, setFile] = useState<File | null>(null);
  const [serialized, setSerialized] = useState(''); const [preview, setPreview] = useState<BackupPreview | null>(null);
  const [busy, setBusy] = useState(false); const [error, setError] = useState(''); const [status, setStatus] = useState(''); const [showPass, setShowPass] = useState(false);
  const exportBackup = async () => {
    setError(''); setStatus('');
    if (exportPass.length < 12) { setError(c.short); return; }
    if (exportPass !== confirmExportPass) { setError(c.mismatch); return; }
    setBusy(true);
    try {
      const contents = await onExport(exportPass); const blob = new Blob([contents], { type: 'application/json' });
      const url = URL.createObjectURL(blob); const link = document.createElement('a');
      link.href = url; link.download = `menin-kunum-backup-${new Date().toISOString().slice(0, 10)}.mkbackup`;
      document.body.append(link); link.click(); link.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      setStatus(c.exportDone); setExportPass(''); setConfirmExportPass('');
    } catch (cause) { setError(cause instanceof Error ? cause.message : c.error); }
    finally { setBusy(false); }
  };
  const validateFile = async () => {
    setError(''); setStatus(''); setPreview(null); setSerialized('');
    if (!file) { setError(c.error); return; }
    if (file.size > 30 * 1024 * 1024) { setError(c.size); return; }
    if (restorePass.length < 12) { setError(c.short); return; }
    setBusy(true);
    try { const contents = await file.text(); const next = await onPreview(contents, restorePass); setSerialized(contents); setPreview(next); setStatus(c.previewReady); }
    catch (cause) { setError(cause instanceof Error ? cause.message : c.error); }
    finally { setBusy(false); }
  };
  const restore = async () => {
    if (!preview || !serialized || !window.confirm(c.confirmReplace)) return;
    setBusy(true); setError(''); setStatus('');
    try { await onRestore(preview); setStatus(c.restored); setPreview(null); setSerialized(''); setFile(null); setRestorePass(''); }
    catch (cause) { setError(cause instanceof Error ? cause.message : c.error); }
    finally { setBusy(false); }
  };
  return <section className="backup-panel" aria-labelledby="backup-panel-title">
    <h3 id="backup-panel-title">{c.title}</h3>
    <div className="backup-section"><h4>{c.exportTitle}</h4><p>{c.exportText}</p>
      <label className="field-label">{c.pass}<input type={showPass ? 'text' : 'password'} value={exportPass} onChange={(event) => setExportPass(event.target.value)} autoComplete="new-password" minLength={12} maxLength={1024} /></label>
      <label className="field-label">{c.confirmPass}<input type={showPass ? 'text' : 'password'} value={confirmExportPass} onChange={(event) => setConfirmExportPass(event.target.value)} autoComplete="new-password" minLength={12} maxLength={1024} /></label>
      <label className="backup-show-pass"><input type="checkbox" checked={showPass} onChange={(event) => setShowPass(event.target.checked)} /> {c.show}</label>
      <button className="primary-action backup-button" type="button" disabled={busy} onClick={() => void exportBackup()}>{busy ? c.busy : c.export}</button>
    </div>
    <div className="backup-section"><h4>{c.restoreTitle}</h4>
      <label className="field-label">{c.file}<input type="file" accept=".mkbackup,.json,application/json" onChange={(event) => { setFile(event.target.files?.[0] ?? null); setPreview(null); setSerialized(''); setStatus(''); setError(''); }} /></label>
      <label className="field-label">{c.restorePass}<input type="password" value={restorePass} onChange={(event) => { setRestorePass(event.target.value); setPreview(null); setSerialized(''); setStatus(''); }} autoComplete="current-password" minLength={12} maxLength={1024} /></label>
      <button className="secondary-button backup-button" type="button" disabled={busy || !file} onClick={() => void validateFile()}>{busy ? c.busy : c.previewAction}</button>
      {preview && <div className="backup-preview"><strong>{c.counts}</strong><ul>{(Object.entries(preview.metadata.counts) as Array<[string, number]>).map(([name, count]) => <li key={name}><span>{storeNames[locale][name] ?? name}</span><b>{count}</b></li>)}</ul><button className="primary-action backup-button" type="button" disabled={busy} onClick={() => void restore()}>{busy ? c.busy : c.restoreAction}</button></div>}
    </div>
    {error && <div className="inline-error backup-message" role="alert">{error}</div>}{status && <div className="inline-notice backup-message" role="status">{status}</div>}
  </section>;
}
