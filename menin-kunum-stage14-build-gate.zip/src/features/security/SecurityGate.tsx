import { useState, type FormEvent } from 'react';
import type { Locale } from '../../domain/models.ts';

export type SecurityGateMode = 'loading' | 'setup' | 'recovery-code' | 'unlock' | 'migration' | 'error';
interface SecurityGateProps {
  mode: SecurityGateMode; locale: Locale; error: string; busy: boolean; recoveryCode?: string;
  onSetup: (pin: string) => Promise<void>; onConfirmRecoverySaved: () => Promise<void>;
  onUnlock: (pin: string) => Promise<void>; onRecover: (code: string, newPin: string) => Promise<void>;
  onRetryMigration: () => Promise<void>;
}

const messages = {
  ru: { eyebrow: 'ЛИЧНОЕ ПРОСТРАНСТВО', title: 'Менин күнүм', loading: 'Открываем защищённое хранилище…', setupTitle: 'Создай PIN-код', setupText: 'Он защищает содержимое заметок и дневника на этом устройстве. Используй не менее 6 символов.', pin: 'PIN-код', confirmPin: 'Повтори PIN-код', create: 'Создать защиту', unlockTitle: 'С возвращением', unlockText: 'Введи PIN-код, чтобы открыть локальные записи.', unlock: 'Разблокировать', forgot: 'Восстановить доступ', recoveryTitle: 'Код восстановления', recoveryText: 'Сохрани этот код вне телефона. Он показывается только сейчас. Если потеряешь и код, и PIN, записи нельзя будет восстановить.', copied: 'Код скопирован', copy: 'Скопировать код', saved: 'Я сохранил код', savedHint: 'Лучше записать его на бумаге или сохранить в надёжном месте вне этого приложения.', recoverTitle: 'Восстановление доступа', recoveryCode: 'Код восстановления', newPin: 'Новый PIN-код', recover: 'Восстановить и задать PIN', back: 'Назад ко входу', migrationTitle: 'Защищаем существующие записи', migrationText: 'Приложение шифрует содержимое старых заметок и дневника. Не закрывай приложение, пока процесс не завершится.', retry: 'Повторить безопасную миграцию', errorTitle: 'Не удалось открыть защиту', reload: 'Перезагрузить приложение', mismatch: 'PIN-коды не совпадают.', pinShort: 'PIN-код должен содержать не менее 6 символов.', busy: 'Подожди…', warningTitle: 'Важно', warning: 'Названия, даты и теги заметок и дневника остаются открытыми для поиска. Шифруется только их содержимое; задачи, проекты и привычки в этой версии не шифруются. Это не защищает данные, если устройство или браузер уже скомпрометированы.' },
  ky: { eyebrow: 'ЖЕКЕ МЕЙКИНДИК', title: 'Менин күнүм', loading: 'Корголгон сактагыч ачылууда…', setupTitle: 'PIN-код түз', setupText: 'Ал бул түзмөктөгү белгилердин жана күндөлүктүн мазмунун коргойт. Кеминде 6 белги колдон.', pin: 'PIN-код', confirmPin: 'PIN-кодду кайтала', create: 'Коргоону түзүү', unlockTitle: 'Кайра келгениңе кубанычтабыз', unlockText: 'Жергиликтүү жазууларды ачуу үчүн PIN-кодду киргиз.', unlock: 'Кулпусун ачуу', forgot: 'Кирүүнү калыбына келтирүү', recoveryTitle: 'Калыбына келтирүү коду', recoveryText: 'Бул кодду телефондон тышкары сакта. Ал бир гана жолу көрсөтүлөт. Кодду да, PIN-кодду да жоготсоң, жазууларды калыбына келтирүү мүмкүн эмес.', copied: 'Код көчүрүлдү', copy: 'Кодду көчүрүү', saved: 'Кодду сактадым', savedHint: 'Кагазга жазып же бул колдонмодон тышкары ишенимдүү жерде сакта.', recoverTitle: 'Кирүүнү калыбына келтирүү', recoveryCode: 'Калыбына келтирүү коду', newPin: 'Жаңы PIN-код', recover: 'Калыбына келтирип PIN түз', back: 'Кирүүгө кайтуу', migrationTitle: 'Мурунку жазуулар корголууда', migrationText: 'Колдонмо эски белгилердин жана күндөлүктүн мазмунун шифрлейт. Процесс бүткөнгө чейин колдонмону жаппа.', retry: 'Коопсуз миграцияны кайталоо', errorTitle: 'Коргоону ачуу мүмкүн болгон жок', reload: 'Колдонмону кайра жүктөө', mismatch: 'PIN-коддор дал келген жок.', pinShort: 'PIN-код кеминде 6 белгиден турушу керек.', busy: 'Күтө тур…', warningTitle: 'Маанилүү', warning: 'Белгилердин жана күндөлүктүн аталыштары, даталары жана тегдери издөө үчүн ачык калат. Алардын мазмуну гана шифрленет; тапшырмалар, долбоорлор жана адаттар бул нускада шифрленбейт. Түзмөк же браузер бузулса, бул коргоо жетишсиз.' },
  en: { eyebrow: 'YOUR PRIVATE SPACE', title: 'Menin Kunum', loading: 'Opening secure local storage…', setupTitle: 'Create a PIN', setupText: 'It protects note and diary contents on this device. Use at least 6 characters.', pin: 'PIN', confirmPin: 'Confirm PIN', create: 'Set up protection', unlockTitle: 'Welcome back', unlockText: 'Enter your PIN to open local entries.', unlock: 'Unlock', forgot: 'Recover access', recoveryTitle: 'Recovery code', recoveryText: 'Keep this code somewhere outside your phone. It is shown only now. If both the code and PIN are lost, entries cannot be recovered.', copied: 'Code copied', copy: 'Copy code', saved: 'I saved the code', savedHint: 'Write it down or store it somewhere safe outside this app.', recoverTitle: 'Recover access', recoveryCode: 'Recovery code', newPin: 'New PIN', recover: 'Recover and set PIN', back: 'Back to unlock', migrationTitle: 'Protecting existing entries', migrationText: 'The app is encrypting existing note and diary contents. Keep the app open until this finishes.', retry: 'Retry safe migration', errorTitle: 'Could not open protection', reload: 'Reload app', mismatch: 'PINs do not match.', pinShort: 'PIN must contain at least 6 characters.', busy: 'Please wait…', warningTitle: 'Important', warning: 'Note and diary titles, dates and tags remain visible for search. Only their contents are encrypted; tasks, projects and habits are not encrypted in this version. This does not protect data if the device or browser is already compromised.' },
} as const;

export function SecurityGate(props: SecurityGateProps) {
  const { mode, locale, error, busy, recoveryCode, onSetup, onConfirmRecoverySaved, onUnlock, onRecover, onRetryMigration } = props;
  const c = messages[locale];
  const [pin, setPin] = useState(''); const [confirmPin, setConfirmPin] = useState('');
  const [code, setCode] = useState(''); const [newPin, setNewPin] = useState('');
  const [recovering, setRecovering] = useState(false); const [recoverySaved, setRecoverySaved] = useState(false);
  const [localError, setLocalError] = useState(''); const [copied, setCopied] = useState(false);
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); setLocalError('');
    if (mode === 'setup') {
      if (pin.length < 6) { setLocalError(c.pinShort); return; }
      if (pin !== confirmPin) { setLocalError(c.mismatch); return; }
      await onSetup(pin); setPin(''); setConfirmPin(''); return;
    }
    if (recovering) {
      if (newPin.length < 6) { setLocalError(c.pinShort); return; }
      if (newPin !== confirmPin) { setLocalError(c.mismatch); return; }
      await onRecover(code.trim(), newPin); setCode(''); setNewPin(''); setConfirmPin(''); return;
    }
    await onUnlock(pin); setPin('');
  };
  const copyRecoveryCode = async () => {
    if (!recoveryCode) return;
    try { await navigator.clipboard.writeText(recoveryCode); setCopied(true); } catch { setCopied(false); }
  };
  return <main className="security-gate"><div className="security-gate-card">
    <div className="security-brand-mark" aria-hidden="true">м</div><p className="eyebrow">{c.eyebrow}</p><h1>{c.title}</h1>
    {mode === 'loading' && <p className="security-description" role="status">{c.loading}</p>}
    {mode === 'setup' && <><h2>{c.setupTitle}</h2><p className="security-description">{c.setupText}</p><form className="security-form" onSubmit={(event) => void submit(event)}>
      <label className="field-label">{c.pin}<input type="password" value={pin} onChange={(event) => setPin(event.target.value)} autoComplete="new-password" minLength={6} maxLength={128} required autoFocus /></label>
      <label className="field-label">{c.confirmPin}<input type="password" value={confirmPin} onChange={(event) => setConfirmPin(event.target.value)} autoComplete="new-password" minLength={6} maxLength={128} required /></label>
      <button className="primary-action security-submit" type="submit" disabled={busy}>{busy ? c.busy : c.create}</button></form></>}
    {mode === 'recovery-code' && <><h2>{c.recoveryTitle}</h2><p className="security-description">{c.recoveryText}</p><div className="recovery-code-box" aria-label={c.recoveryTitle}>{recoveryCode}</div>
      <button className="secondary-button recovery-copy" type="button" onClick={() => void copyRecoveryCode()}>{copied ? c.copied : c.copy}</button><p className="security-hint">{c.savedHint}</p>
      <label className="recovery-confirm"><input type="checkbox" checked={recoverySaved} onChange={(event) => setRecoverySaved(event.target.checked)} /><span>{c.saved}</span></label>
      <button className="primary-action security-submit" type="button" disabled={busy || !recoverySaved} onClick={() => void onConfirmRecoverySaved()}>{busy ? c.busy : c.saved}</button></>}
    {mode === 'unlock' && <><h2>{recovering ? c.recoverTitle : c.unlockTitle}</h2><p className="security-description">{c.unlockText}</p><form className="security-form" onSubmit={(event) => void submit(event)}>
      {recovering ? <><label className="field-label">{c.recoveryCode}<textarea value={code} onChange={(event) => setCode(event.target.value)} rows={3} autoComplete="off" required /></label><label className="field-label">{c.newPin}<input type="password" value={newPin} onChange={(event) => setNewPin(event.target.value)} autoComplete="new-password" minLength={6} maxLength={128} required /></label><label className="field-label">{c.confirmPin}<input type="password" value={confirmPin} onChange={(event) => setConfirmPin(event.target.value)} autoComplete="new-password" minLength={6} maxLength={128} required /></label></> : <label className="field-label">{c.pin}<input type="password" value={pin} onChange={(event) => setPin(event.target.value)} autoComplete="current-password" minLength={6} maxLength={128} required autoFocus /></label>}
      <button className="primary-action security-submit" type="submit" disabled={busy}>{busy ? c.busy : recovering ? c.recover : c.unlock}</button></form>
      <button className="text-action security-switch" type="button" onClick={() => { setRecovering(!recovering); setLocalError(''); setCode(''); setNewPin(''); setConfirmPin(''); setPin(''); }}>{recovering ? c.back : c.forgot}</button></>}
    {mode === 'migration' && <><h2>{c.migrationTitle}</h2><p className="security-description">{c.migrationText}</p>{busy && <div className="security-progress" role="status"><span /></div>}{!busy && <button className="primary-action security-submit" type="button" onClick={() => void onRetryMigration()}>{c.retry}</button>}</>}
    {mode === 'error' && <><h2>{c.errorTitle}</h2><button className="primary-action security-submit" type="button" onClick={() => window.location.reload()}>{c.reload}</button></>}
    {(localError || error) && <div className="inline-error security-error" role="alert">{localError || error}</div>}
    <aside className="security-gate-warning"><strong>{c.warningTitle}</strong><p>{c.warning}</p></aside>
  </div></main>;
}
