export type ValidationResult<T> =
  | { valid: true; value: T }
  | { valid: false; error: 'required' | 'invalid_date' };

export function validateRequiredTitle(value: string): ValidationResult<string> {
  const trimmed = value.trim();
  if (!trimmed) return { valid: false, error: 'required' };
  return { valid: true, value: trimmed };
}

export function validateIsoDate(value: string): ValidationResult<string> {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return { valid: false, error: 'invalid_date' };
  const [year, month, day] = value.split('-').map(Number);
  const date = new Date(Date.UTC(year, month - 1, day));
  const valid = date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  return valid ? { valid: true, value } : { valid: false, error: 'invalid_date' };
}
