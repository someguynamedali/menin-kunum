export type Locale = 'ru' | 'ky' | 'en';
export type TaskStatus = 'planned' | 'completed' | 'deferred';
export type Priority = 'low' | 'medium' | 'high';
export type Mood = 'great' | 'good' | 'okay' | 'low' | 'difficult';
export type HabitMeasure = 'checkbox' | 'minutes' | 'pages' | 'repetitions';

export interface Task {
  id: string;
  title: string;
  description?: string;
  dueDate?: string;
  dueTime?: string;
  category?: string;
  priority: Priority;
  status: TaskStatus;
  recurringRule?: { weekdays: number[] };
  estimatedMinutes?: number;
  actualMinutes?: number;
  dependencyIds: string[];
  projectId?: string;
  subtasks?: Subtask[];
  createdAt: string;
  updatedAt: string;
}

export interface Project {
  id: string;
  title: string;
  description?: string;
  taskIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Subtask {
  id: string;
  parentTaskId: string;
  title: string;
  completed: boolean;
}

export interface Note {
  id: string;
  title: string;
  body: string;
  tags: string[];
  favorite: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DiaryEntry {
  id: string;
  date: string;
  title: string;
  body: string;
  mood?: Mood;
  goodThings: string[];
  concerns: string[];
  gratitude: string[];
  tags: string[];
  attachmentIds: string[];
  createdAt: string;
  updatedAt: string;
}

export interface Habit {
  id: string;
  title: string;
  measure: HabitMeasure;
  targetValue: number;
  targetPeriod: 'daily' | 'weekly';
  reminderTime?: string;
  createdAt: string;
  updatedAt: string;
}

export interface HabitLog {
  id: string;
  habitId: string;
  date: string;
  value: number;
}

export interface AttachmentMetadata {
  id: string;
  mimeType: string;
  sizeBytes: number;
  createdAt: string;
}

export interface AppSettings {
  locale: Locale;
  autoLockMinutes: number;
  hideNotificationContent: boolean;
  remindersEnabled: boolean;
  dailyReminderTime?: string;
  schemaVersion: number;
}
